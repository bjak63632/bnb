<?php 

require 'PHPMailerAutoload.php';
require_once __DIR__ . '/../vendor/autoload.php'; 

function contactMail($subject, $body, $Email, $name) {
    $mail = new PHPMailer;

    // SMTP configuration
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->Port = 587;
    $mail->SMTPAuth = true;
    $mail->SMTPSecure = 'tls'; 

    // Replace with your actual Gmail address and app password
    $mail->Username = '002ericanthony@gmail.com';
    $mail->Password = 'zdlecvwkbktwvduk';

    // Sender and recipient
    $senderEmail = '002ericanthony@gmail.com'; // Use your Gmail as sender
    $mail->setFrom($senderEmail, '  إميراترست | EmiraTrust');
    $mail->addAddress($senderEmail); // You receive the contact form message
    $mail->addReplyTo($Email, $name); // Reply goes to the person who filled the form

    // Email content
    $mail->isHTML(true);
    $mail->Subject = htmlspecialchars($subject);
    $mail->Body = "
        <h3>Contact Form Message</h3>
        <p><strong>From:</strong> " . htmlspecialchars($name) . "</p>
        <p><strong>Email:</strong> " . htmlspecialchars($Email) . "</p>
        <p><strong>Message:</strong><br>" . nl2br(htmlspecialchars($body)) . "</p>
    ";

    if (!$mail->send()) {
        return "fail";
    } else {
        return "success";
    }
}
?>
