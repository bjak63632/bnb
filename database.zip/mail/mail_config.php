<?php 

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require_once __DIR__ . '/../vendor/autoload.php'; // Adjust path if needed

function sendOtp($customerMail, $otp, $name){

    $mail = new PHPMailer(true); // Enable exceptions for better error handling

    try {
        // SMTP Settings
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->Port = 587;
        $mail->SMTPAuth = true;
        $mail->SMTPSecure = 'tls';

        // Gmail SMTP credentials
        $mail->Username = '002ericanthony@gmail.com';
        $mail->Password = 'zdle cvwk bktw vduk'; // App password

        // Email setup
        $mail->setFrom('002ericanthony@gmail.com', '  إميراترست | EmiraTrust');
        $mail->addAddress($customerMail);
        $mail->addReplyTo('002ericanthony@gmail.com');

        $mail->isHTML(true);
        $mail->Subject = "Email Verification";

        // Load and replace HTML template
        $content = file_get_contents('../mail/otpMail.php');
        $swap_var = array(
            "{Name}" => $name,
            "{otp}" => $otp
        );

        foreach($swap_var as $key => $value){
            $content = str_replace($key, $value, $content);
        }

        $mail->Body = $content;

        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log("Mailer Error: " . $mail->ErrorInfo);
        return false;
    }
}
?>
