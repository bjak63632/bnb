<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require_once __DIR__ . '/../vendor/autoload.php'; // Use Composer's autoloader

function debitMoneyMail($customerMail, $name, $amount, $totalAmount, $date, $AccountNo) {
    $mail = new PHPMailer(true);
    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = '002ericanthony@gmail.com';
        $mail->Password = 'zdlecvwkbktwvduk';
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;

        // Recipients
        $mail->setFrom('002ericanthony@gmail.com', '  إميراترست | EmiraTrust');
        $mail->addAddress($customerMail);
        $mail->addReplyTo('002ericanthony@gmail.com', '  إميراترست | EmiraTrust');

        // Content
        $mail->isHTML(true);
        $mail->Subject = "Your Account '$AccountNo' has been debited";

        $content = file_get_contents('../mail/DebitMailTemp.php');

        // Replace variables
        $swap_var = [
            "{Name}" => $name,
            "{AccountNo}" => $AccountNo,
            "{Amount}" => $amount,
            "{Date}" => $date,
            "{totalAmount}" => $totalAmount
        ];

        foreach ($swap_var as $key => $value) {
            $content = str_replace($key, $value, $content);
        }

        $mail->Body = $content;

        $mail->send();
        // echo "Debit email sent successfully!";
    } catch (Exception $e) {
        echo "Debit Mailer Error: {$mail->ErrorInfo}";
    }
}

function creditMoneyMail($customerMail, $name, $amount, $totalAmount, $date, $AccountNo) {
    $mail = new PHPMailer(true);
    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = '002ericanthony@gmail.com';
        $mail->Password = 'zdlecvwkbktwvduk';
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;

        // Recipients
        $mail->setFrom('002ericanthony@gmail.com', '  إميراترست | EmiraTrust');
        $mail->addAddress($customerMail);
        $mail->addReplyTo('002ericanthony@gmail.com', '  إميراترست | EmiraTrust');

        // Content
        $mail->isHTML(true);
        $mail->Subject = "Your Account '$AccountNo' has been credited";

        $content = file_get_contents('../mail/CreditMailTemp.php');

        // Replace variables
        $swap_var = [
            "{Name}" => $name,
            "{AccountNo}" => $AccountNo,
            "{Amount}" => $amount,
            "{Date}" => $date,
            "{totalAmount}" => $totalAmount
        ];

        foreach ($swap_var as $key => $value) {
            $content = str_replace($key, $value, $content);
        }

        $mail->Body = $content;

        $mail->send();
        // echo "Credit email sent successfully!";
    } catch (Exception $e) {
        echo "Credit Mailer Error: {$mail->ErrorInfo}";
    }
}
?>
