-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 16, 2025 at 01:19 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `skybank`
--

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

CREATE TABLE `accounts` (
  `id` int(11) NOT NULL,
  `AccountNo` varchar(12) NOT NULL,
  `Balance` decimal(15,2) NOT NULL,
  `SavingBalance` decimal(15,2) NOT NULL,
  `SavingTarget` decimal(15,2) NOT NULL,
  `AccountType` text NOT NULL,
  `State` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `accounts`
--

INSERT INTO `accounts` (`id`, `AccountNo`, `Balance`, `SavingBalance`, `SavingTarget`, `AccountType`, `State`) VALUES
(1, '516250910270', 0.00, 0.00, 0.00, '', 0),
(2, '516250922510', 17833.00, 0.00, 0.00, '', 0),
(3, '516251152280', 2500.00, 0.00, 0.00, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `achwire_transfers`
--

CREATE TABLE `achwire_transfers` (
  `id` int(11) NOT NULL,
  `sender_name` varchar(100) NOT NULL,
  `sender_account_number` varchar(30) NOT NULL,
  `routing_number` varchar(20) NOT NULL,
  `bank_name` varchar(100) DEFAULT 'SkyBank',
  `account_type` enum('Savings','Checkings') NOT NULL,
  `recipient_name` varchar(255) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `street_name` varchar(100) NOT NULL,
  `street_number` varchar(20) NOT NULL,
  `apartment` varchar(50) NOT NULL,
  `floor` varchar(20) NOT NULL,
  `postal_code` varchar(20) NOT NULL,
  `country` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `province` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `recipient_account_number` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `achwire_transfers_org`
--

CREATE TABLE `achwire_transfers_org` (
  `id` int(11) NOT NULL,
  `sender_name` varchar(255) DEFAULT NULL,
  `sender_account_number` varchar(50) DEFAULT NULL,
  `routing_number` varchar(50) DEFAULT NULL,
  `bank_name` varchar(255) DEFAULT NULL,
  `account_type` varchar(50) DEFAULT NULL,
  `street_name` varchar(255) DEFAULT NULL,
  `street_number` varchar(50) DEFAULT NULL,
  `apartment` varchar(50) DEFAULT NULL,
  `floor` varchar(50) DEFAULT NULL,
  `postal_code` varchar(50) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `province` varchar(100) DEFAULT NULL,
  `organization_name` varchar(255) DEFAULT NULL,
  `recipient_account_number` varchar(50) DEFAULT NULL,
  `amount` double DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cards`
--

CREATE TABLE `cards` (
  `srNo` int(11) NOT NULL,
  `AccountNo` varchar(12) NOT NULL,
  `Name` varchar(80) NOT NULL,
  `CardNo` varchar(16) NOT NULL,
  `cvv` int(3) NOT NULL,
  `IssuedDate` varchar(20) NOT NULL,
  `ExpiryDate` varchar(20) NOT NULL,
  `Status` varchar(12) NOT NULL,
  `Verified` varchar(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `customer_detail`
--

CREATE TABLE `customer_detail` (
  `C_No` int(11) NOT NULL,
  `Account_No` varchar(12) NOT NULL,
  `C_First_Name` text NOT NULL,
  `C_Last_Name` text NOT NULL,
  `Gender` text NOT NULL,
  `Street_name` text NOT NULL,
  `Postal_code` int(11) NOT NULL,
  `Country` text NOT NULL,
  `City` text NOT NULL,
  `Province` text NOT NULL,
  `C_Birth_Date` date NOT NULL,
  `C_Adhar_No` varchar(12) NOT NULL,
  `C_Pan_No` varchar(20) NOT NULL,
  `C_Mobile_No` varchar(16) NOT NULL,
  `C_Email` varchar(200) NOT NULL,
  `C_Pincode` varchar(8) NOT NULL,
  `C_Adhar_Doc` varchar(500) NOT NULL,
  `C_Pan_Doc` varchar(500) NOT NULL,
  `Create_Date` date NOT NULL DEFAULT current_timestamp(),
  `ProfileColor` varchar(100) NOT NULL,
  `ProfileImage` varchar(400) NOT NULL,
  `Bio` varchar(100) NOT NULL,
  `Account_Type` enum('Excellency','Elite','Premier','Private','savings','checking') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customer_detail`
--

INSERT INTO `customer_detail` (`C_No`, `Account_No`, `C_First_Name`, `C_Last_Name`, `Gender`, `Street_name`, `Postal_code`, `Country`, `City`, `Province`, `C_Birth_Date`, `C_Adhar_No`, `C_Pan_No`, `C_Mobile_No`, `C_Email`, `C_Pincode`, `C_Adhar_Doc`, `C_Pan_Doc`, `Create_Date`, `ProfileColor`, `ProfileImage`, `Bio`, `Account_Type`) VALUES
(1, '516250910270', 'Admin', 'Reed', 'Not Available', 'Illiana Marks', 4, 'Kenya', 'Nairobi', 'Westlands', '1982-06-14', '8018775', 'HYGTR5555F', '0755432817', 'benardilukol37@gmail.com', '111111', 'customer_data/Adhar_doc/favicon05162025091027.png', 'customer_data/Pan_doc/favicon05162025091027.png', '2025-05-16', '#77b3d5', '../customer_data/Profile_Img/Admin.jpg', '', 'savings'),
(2, '516250922510', 'Penelope', 'Fox', 'Male', 'Clio Mclean', 5, 'Martinique', 'Labore sunt ipsam i', 'Deserunt et fugiat m', '1971-07-15', '1398762', 'YHTYR7645Q', '0754666281', 'otungoclint@gmail.com', '112233', 'customer_data/Adhar_doc/105162025092251.jpg', 'customer_data/Pan_doc/105162025092251.jpg', '2025-05-16', '#605d5f', '../customer_data/Profile_Img/1user11.jpg', 'The purpose of our lives is to be happy and joyful', 'Excellency'),
(3, '516251152280', 'Stacey', 'Herman', 'Not Available', 'Violet Wong', 3, 'Mongolia', 'Ex sunt sunt ab con', 'Laudantium officia ', '1999-02-20', '9469991', 'HYTGR6555V', '0755432817', 'otungoc@gmail.com', '567888', 'customer_data/Adhar_doc/105162025115228.jpg', 'customer_data/Pan_doc/105162025115228.jpg', '2025-05-16', '#44663c', '', '', 'Excellency');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `ID` int(11) NOT NULL,
  `AccountNo` varchar(12) NOT NULL,
  `Username` varchar(30) NOT NULL,
  `Password` varchar(40) NOT NULL,
  `Status` varchar(20) NOT NULL,
  `State` int(11) NOT NULL,
  `otp_code` varchar(10) DEFAULT NULL,
  `is_verified` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`ID`, `AccountNo`, `Username`, `Password`, `Status`, `State`, `otp_code`, `is_verified`) VALUES
(1, '516250910270', 'admin11', '0a6d86b2a06175d78b592745708681c4', 'Super', 1, NULL, 0),
(2, '516250922510', 'user11', 'e20f517179e9cd52ae29dae43c121b95', 'Active', 0, NULL, 0),
(3, '516251152280', 'user12', 'e20f517179e9cd52ae29dae43c121b95', 'Active', 0, NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE `transaction` (
  `id` int(11) NOT NULL,
  `AccountNo` varchar(12) NOT NULL,
  `FAccountNo` varchar(225) NOT NULL,
  `Name` text NOT NULL,
  `Amount` varchar(100) NOT NULL,
  `Debit` varchar(100) NOT NULL,
  `Credit` varchar(100) NOT NULL,
  `Date` date NOT NULL DEFAULT current_timestamp(),
  `Status` text NOT NULL,
  `ProfileColor` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transaction`
--

INSERT INTO `transaction` (`id`, `AccountNo`, `FAccountNo`, `Name`, `Amount`, `Debit`, `Credit`, `Date`, `Status`, `ProfileColor`) VALUES
(1, '516250922510', 'Cash Deposit', 'SKY BANK', '20333', '0.0', '20333', '2025-05-16', 'Credited', 'blue'),
(2, '516251152280', '516250922510', 'Penelope Fox', '1200', '0.0', '1200', '2025-05-16', 'Credited', '#605d5f'),
(3, '516250922510', '516251152280', 'Stacey Herman', '-1200', '1200', '0.0', '2025-05-16', 'Debited', '#44663c'),
(4, '516251152280', '516250922510', 'Penelope Fox', '200', '0.0', '200', '2025-05-16', 'Credited', '#605d5f'),
(5, '516250922510', '516251152280', 'Stacey Herman', '-200', '200', '0.0', '2025-05-16', 'Debited', '#44663c'),
(6, '516251152280', '516250922510', 'Penelope Fox', '100', '0.0', '100', '2025-05-16', 'Credited', '#605d5f'),
(7, '516250922510', '516251152280', 'Stacey Herman', '-100', '100', '0.0', '2025-05-16', 'Debited', '#44663c'),
(8, '516251152280', '516250922510', 'Penelope Fox', '1000', '0.0', '1000', '2025-05-16', 'Credited', '#605d5f'),
(9, '516250922510', '516251152280', 'Stacey Herman', '-1000', '1000', '0.0', '2025-05-16', 'Debited', '#44663c');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wire_transfers`
--

CREATE TABLE `wire_transfers` (
  `id` int(11) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  `sender_name` varchar(255) DEFAULT NULL,
  `sender_account_number` varchar(50) DEFAULT NULL,
  `sender_address` varchar(255) DEFAULT NULL,
  `sender_city` varchar(100) DEFAULT NULL,
  `sender_country` varchar(100) DEFAULT NULL,
  `currency` varchar(10) DEFAULT NULL,
  `amount` decimal(15,2) DEFAULT NULL,
  `beneficiary_swift_code` varchar(50) DEFAULT NULL,
  `beneficiary_bank_name` varchar(255) DEFAULT NULL,
  `beneficiary_bank_address` varchar(255) DEFAULT NULL,
  `beneficiary_bank_city` varchar(100) DEFAULT NULL,
  `beneficiary_bank_country` varchar(100) DEFAULT NULL,
  `beneficiary_account_number` varchar(50) DEFAULT NULL,
  `beneficiary_name` varchar(255) DEFAULT NULL,
  `beneficiary_address` varchar(255) DEFAULT NULL,
  `beneficiary_city` varchar(100) DEFAULT NULL,
  `beneficiary_country` varchar(100) DEFAULT NULL,
  `purpose` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD UNIQUE KEY `AccountNo` (`AccountNo`);

--
-- Indexes for table `achwire_transfers`
--
ALTER TABLE `achwire_transfers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `achwire_transfers_org`
--
ALTER TABLE `achwire_transfers_org`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cards`
--
ALTER TABLE `cards`
  ADD PRIMARY KEY (`srNo`),
  ADD UNIQUE KEY `AccountNo` (`AccountNo`),
  ADD UNIQUE KEY `CardNo` (`CardNo`);

--
-- Indexes for table `customer_detail`
--
ALTER TABLE `customer_detail`
  ADD PRIMARY KEY (`C_No`),
  ADD UNIQUE KEY `Account_No` (`Account_No`),
  ADD UNIQUE KEY `C_Pan_No` (`C_Pan_No`),
  ADD UNIQUE KEY `C_Adhar_No` (`C_Adhar_No`),
  ADD UNIQUE KEY `C_Email` (`C_Email`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`AccountNo`),
  ADD UNIQUE KEY `Unique` (`ID`),
  ADD UNIQUE KEY `AccountNo` (`AccountNo`),
  ADD UNIQUE KEY `Username` (`Username`);

--
-- Indexes for table `transaction`
--
ALTER TABLE `transaction`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wire_transfers`
--
ALTER TABLE `wire_transfers`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accounts`
--
ALTER TABLE `accounts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `achwire_transfers`
--
ALTER TABLE `achwire_transfers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `achwire_transfers_org`
--
ALTER TABLE `achwire_transfers_org`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cards`
--
ALTER TABLE `cards`
  MODIFY `srNo` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `customer_detail`
--
ALTER TABLE `customer_detail`
  MODIFY `C_No` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `transaction`
--
ALTER TABLE `transaction`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wire_transfers`
--
ALTER TABLE `wire_transfers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
