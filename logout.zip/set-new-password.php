<?php
include 'connection.php';
session_start();

if (!isset($_SESSION['accountNo']) || !isset($_SESSION['username'])) {
    header("Location: ../user/forgotPassword.php?error=Session expired. Please try again.");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $newPassword = $_POST['password'];
    $confirmPassword = $_POST['confirm_password'];

    if (empty($newPassword) || empty($confirmPassword)) {
        $error = "Both fields are required.";
    } elseif ($newPassword !== $confirmPassword) {
        $error = "Passwords do not match.";
    } else {
        $hashedPassword = md5($newPassword);
        $accountNo = $_SESSION['accountNo'];

        $updateQuery = "UPDATE login SET Password = '$hashedPassword' WHERE AccountNo = '$accountNo'";
        if (mysqli_query($conn, $updateQuery)) {
            session_unset();
            session_destroy();
            header("Location: ../user/login.php?success=Password updated successfully.");
            exit();
        } else {
            $error = "Failed to update password. Please try again.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Reset Password -   إميراترست | EmiraTrust</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
</head>
<body class="bg-light">
    <div class="container mt-5">
        <div class="col-md-6 offset-md-3">
            <h4 class="mb-4">Set New Password</h4>
            <?php if (isset($error)) echo "<div class='alert alert-danger'>$error</div>"; ?>
            <form method="POST">
                <div class="form-group">
                    <label for="password">New Password</label>
                    <input type="password" name="password" id="password" class="form-control" required minlength="6">
                </div>
                <div class="form-group">
                    <label for="confirm_password">Confirm New Password</label>
                    <input type="password" name="confirm_password" id="confirm_password" class="form-control" required minlength="6">
                </div>
                <button type="submit" class="btn btn-primary" style="background: #8a2208">Update Password</button>
            </form>
            <p class="text-center mt-3">
                            <a href="login.php" style="color: #8a2208">Back to Login</a>
                        </p>
        </div>
    </div>
</body>
</html>
