<?php
session_start();
include "connection.php";
include '../mail/mail_config.php';
// checking Submit button is clicked or not by isset function
if (isset($_POST['submit'])) {


    // ----------------------------------------- Basic Detail Section -----------------------------------------

    
    $Account_Status = "Inactive";
    $Balance = "0.0";

    // Storing Form values in variable
    $First_Name = $_POST['FirstName'];
    $Last_Name = $_POST['LastName'];
    $Street_Name = $_POST['StreetName'];
    $Postal_Code = $_POST['PostalCode'];
    $Country = $_POST['Country'];
    $City = $_POST['City'];
    $Province = $_POST['Province'];
    $Birth_Date = $_POST['BirthDate'];
    $Mobile_Number = $_POST['MobileNumber'];
    $Pan_Number = $_POST['PanNumber'];
    $Adhar_Number = $_POST['AdharNumber'];
    $Account_Number = date('ndyHisL');
    $account_type = $_POST['account_type'];
    $Residency_Status = $_POST['Residency_Status'];
    $Currency_Preference = $_POST['Currency_Preference'];
    $sourceWealthPath = '';
    $bankStatementPath = '';
   

    if(strlen($Account_Number)>12){
        $Account_Number = substr($Account_Number,0,-1);
    }

    $Email = $_POST['email'];
    $Pincode = $_POST['pincode'];



    //  Error Variables

    $First_Name_error =  $Last_Name_error = $Street_Name_error = $Postal_Code_error = null;
    $Birth_Date_error = $Mobile_Number_error =  $Pan_Number_error = $Adhar_Number_error = null;
    $Email_error = $Pincode_error = $Country_error = $City_error = $Province_error =  null;

    // Validate Name of customer
    /* 
            1] Preg_match_all(): This function check any number is avaible in string or not
            2] !\d+! : passing this regular expression in above function which conatin numeric data pattern
            3] Varible : this parameter contains string to be check
            4] logic explain: if() ant numeric value found in string and it is == 1 
        
     */

    if (preg_match_all('!\d+!', $First_Name) == 1) {
        $First_Name_error = "* Numeric value not allowed in First Name";
    }
    if (preg_match_all('!\d+!', $Last_Name) == 1) {
        $Last_Name_error = "* Numeric value not allowed in Last Name";
    }
    if (preg_match_all('!\d+!', $Street_Name) == 1) {
        $Street_Name_error = "* Numeric value not allowed in Street's Name";
    }
    if (!preg_match('/^\d+$/', $Postal_Code)) {
        $Postal_Code_error = "* Postal Code must contain digits only";
    }    
    if (preg_match_all('!\d+!', $Country) == 1) {
        $Country_error = "* Numeric value not allowed in Country's Name";
    }
    if (preg_match_all('!\d+!', $City) == 1) {
        $City_error = "* Numeric value not allowed in City's Name";
    }
    if (preg_match_all('!\d+!', $Province) == 1) {
        $Province_error = "* Numeric value not allowed in Province's Name";
    }


    // ********************************* Tax Number Validation *********************************************

    if ($Pan_Number != null) {
        // Regular Expression to validate pan number
        $regex = '/^.+$/';

        // if pan number not match with above pattern
        if (!preg_match_all($regex, $Pan_Number)) {
            $Pan_Number_error = "* INVALID TAX ID NUMBER";
        } else {
            $Pan_Number = mysqli_real_escape_string($conn, $_POST['PanNumber']);
            $query =  $query = "SELECT * FROM customer_detail WHERE C_Pan_No = '" . $Pan_Number . "'";

            $result =  mysqli_query($conn, $query);

            if (mysqli_num_rows($result) > 0) {
                $Pan_Number_error = "* Tax ID already exists";   if ($Pan_Number != null) {
        // Regular Expression to validate pan number
        $regex = '/^.+$/';

        // if pan number not match with above pattern
        if (!preg_match_all($regex, $Pan_Number)) {
            $Pan_Number_error = "* INVALID TAX ID NUMBER";
        } else {
            $Pan_Number = mysqli_real_escape_string($conn, $_POST['PanNumber']);
            $query =  $query = "SELECT * FROM customer_detail WHERE C_Pan_No = '" . $Pan_Number . "'";

            $result =  mysqli_query($conn, $query);

            if (mysqli_num_rows($result) > 0) {
                $Pan_Number_error = "* Tax ID already exists";
            }
        }
    } else {
        $Pan_Number_error = "* Please Enter Tax Id";
    }

            }
        }
    } else {
        $Pan_Number_error = "* Please Enter Tax Id";
    }



    // ********************************** Birth Date Validation *********************************************

    $today = new DateTime();
    $diff = $today->diff(new datetime($Birth_Date));
    $age = $diff->y;

    if ($age < 18) {

        $Birth_Date_error = "* You Are Not Eligible to Open Online Account.";
    }

    if (!is_numeric($Mobile_Number) || is_null($Mobile_Number) || !preg_match('/^[0-9]{10}+$/', $Mobile_Number)) {
        $Mobile_Number_error = "Invalid Mobile Number";
    }


    // **************************************** Adhar Validation *******************************************************
    if (!is_numeric($Adhar_Number) || is_null($Adhar_Number) ) {
        $Adhar_Number_error = "Invalid National ID Number";
    
    
    } else {

        // Adhar Number Exist in database or not validation 

        $Adhar_Number = mysqli_real_escape_string($conn, $_POST['AdharNumber']);
        $query1 = "SELECT * FROM customer_detail WHERE C_Adhar_No = '" . $Adhar_Number . "'";

        $result1 =  mysqli_query($conn, $query1);

        if (mysqli_num_rows($result1) > 0) {
            $Adhar_Number_error = "* National ID Number already exists";
        }
    }

    // ************************************************** Email Validation *********************************************


    if (!empty($Email)) {
        if (!preg_match('/^([a-z0-9\+_\-]+)(\.[a-z0-9\+_\-]+)*@([a-z0-9\-]+\.)+[a-z]{2,6}$/ix', $Email)) {
            $Email_error = "* Invalid Email ID";
        } else {
            $Email = mysqli_real_escape_string($conn, $_POST['email']);
            $query2 = "SELECT * FROM customer_detail WHERE C_Email = '" . $Email . "'";

            $result2 =  mysqli_query($conn, $query2);

            if (mysqli_num_rows($result2) > 0) {
                $Email_error = "* Email Already Exist";
            }
        }
    } else {
        $Email_error = "* Enter Your Email";
    }


    // ************************************************** Picode Validation *********************************************


   





    // ++++++++++++++++++++++++++++++++++++++++++++++ Basic Detail Ends Here +++++++++++++++++++++++++++++++++++++++++




    // -------------------------------------------- USERNAME AND PASSWORD VERIFICATION -------------------------------


    $Username = $_POST['Username'];
    $Password  = $_POST['Password'];
    $ConfirmPass = $_POST['ConfirmPass'];

    $UsernameError =  $PasswordError  = $ConfirmPassError = false;

    if (!empty($Username)) {
        if (!preg_match_all('/^[A-Za-z]{1}[A-Za-z0-9]{5,31}$/', $Username)) {

            $UsernameError = "* Please Enter Valid Username";
        } else {
            $UsernameError = false;

            $Username = mysqli_real_escape_string($conn, $_POST['Username']);
            $query3 = "SELECT * FROM login WHERE Username = '" . $Username . "'";

            $result3 =  mysqli_query($conn, $query3);

            if (mysqli_num_rows($result3) > 0) {
                $UsernameError = "* Username Already Exist";
            }
        }
    } else {
        $UsernameError = "* Username Cannot Empty";
    }

    // ----------------------------------------- Password Verification ---------------------------------------------
    if (!empty($Password)) {
        if (!preg_match_all('/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?!.* )(?=.*[^a-zA-Z0-9]).{8,16}$/m', $Password)) {
            $PasswordError  = "* Password must contain Minimum eight characters, at least one none letter, one lowercase letter, one number and one special character";
        } else {
            $hashPass = md5($Password);
            $PasswordError = false;
        }
    } else {
        $PasswordError = "Password Cannot be empty";
    }

    if (!empty($ConfirmPass)) {

        if ($ConfirmPass != $Password) {
            $ConfirmPassError = "Please Enter same Password";
        } else {
            $ConfirmPassError = false;
            unset($_SESSION['otp']);
            header('Location: ../user/login.php');
        }
    } else {
        $ConfirmPassError = "Please Confirm Password";
    }

    // --------------------------------------------------- Random Color Hex Generator for Profile ----------------------- 

    $hex = '#';

    //Create a loop.
    foreach (array('r', 'g', 'b') as $color) {
        //Random number between 0 and 255.
        $val = mt_rand(0, 255);
        //Convert the random number into a Hex value.
        $dechex = dechex($val);
        //Pad with a 0 if length is less than 2.
        if (strlen($dechex) < 2) {
            $dechex = "0" . $dechex;
        }
        //Concatenate
        $hex .= $dechex;
    }

    //Print out our random hex color.
    // echo $hex;

    // ----------------------------------------- KYC Document Upload Section -----------------------------------------


    // Storing Form values in variable

    // Pan Card Variable

    $Pan_Files = $_FILES['PanCardUp'];
    $Pan_fileName = $Pan_Files['name'];
    $Pan_fileName = preg_replace('/\s/', '_', $Pan_fileName); // replacing space with underscore
    $Pan_fileType = $Pan_Files['type'];
    $Pan_fileError = $Pan_Files['error'];
    $Pan_fileTempName = $Pan_Files['tmp_name'];
    $Pan_fileSize = $Pan_Files['size'];
    $Pan_Up_error = false;

    // Adhar Card Variable
    $Adhar_Files = $_FILES['AdharCardUp'];
    $Adhar_fileName = $Adhar_Files['name'];
    $Adhar_fileName = preg_replace('/\s/', '_', $Adhar_fileName); // replacing space with underscore
    $Adhar_fileType = $Adhar_Files['type'];
    $Adhar_fileError = $Adhar_Files['error'];
    $Adhar_fileTempName = $Adhar_Files['tmp_name'];
    $Adhar_fileSize = $Adhar_Files['size'];
    $Adhar_Up_error = false;

    // Array storing file extention global version
    $Valid_Extention = array('png', 'jpg', 'jpeg');



    // ************************************ Validating Pan Card Document **********************************************

    // use built in function ( pathinfo() ) to seprate file name and store them in seprate variable

    $Pan_file_extention = pathinfo($Pan_fileName, PATHINFO_EXTENSION);
    $Pan_fileName = pathinfo($Pan_fileName, PATHINFO_FILENAME);

    $Adhar_file_extention = pathinfo($Adhar_fileName, PATHINFO_EXTENSION);
    $Adhar_fileName = pathinfo($Adhar_fileName, PATHINFO_FILENAME);

    // Generating unique name with date and time 
    $Pan_Unique_Name = $Pan_fileName . date('mjYHis') . "." . $Pan_file_extention;
    $Adhar_Unique_Name = $Adhar_fileName . date('mjYHis') . "." . $Adhar_file_extention;


    // Validating Pan Card


    if (!empty($Pan_fileName) && !empty($Adhar_fileName)) {

        // Setting file size condition
        if ($Pan_fileSize <= 2000000 && $Adhar_fileSize <= 2000000) {

            // checking file extention
            if (in_array($Pan_file_extention, $Valid_Extention) && in_array($Adhar_file_extention, $Valid_Extention)) {

                // Pancard Destination Variable
                $Pan_destinationFile = 'customer_data/Pan_doc/' . $Pan_Unique_Name;


                // Adharcard Destination Variable
                $Adhar_destinationFile = 'customer_data/Adhar_doc/' . $Adhar_Unique_Name;





                // Validating All Error Are values are null or not means checking any error in form or not
                if ($First_Name_error == null && $Last_Name_error == null && $Father_Name_error == null && $Mother_Name_error == null && $Birth_Date_error == null && $Pan_Number_error == null && $Adhar_Number_error == null && $Mobile_Number_error == null && $Pan_Up_error == false && $Adhar_Up_error == false && $Email_error == null && $Pincode_error == null && $UsernameError == false && $PasswordError == false && $ConfirmPassError == false) {


                    // Uploading Document to server
                    $Adhar_Upload = move_uploaded_file($Adhar_fileTempName, $Adhar_destinationFile);
                    $Pan_Upload = move_uploaded_file($Pan_fileTempName, $Pan_destinationFile);

                    if (isset($_FILES['Source_Of_Wealth_Doc']) && $_FILES['Source_Of_Wealth_Doc']['error'] === 0) {
                        $sourceWealthPath = 'customer_data/source_doc/' . basename($_FILES['Source_Of_Wealth_Doc']['name']);
                        move_uploaded_file($_FILES['Source_Of_Wealth_Doc']['tmp_name'], $sourceWealthPath);
                    }

                    // Upload Bank Statement (optional)
                    if (isset($_FILES['Bank_Statement_Doc']) && $_FILES['Bank_Statement_Doc']['error'] === 0) {
                        $bankStatementPath = 'customer_data/Bank_doc/' . basename($_FILES['Bank_Statement_Doc']['name']);
                        move_uploaded_file($_FILES['Bank_Statement_Doc']['tmp_name'], $bankStatementPath);
                    }

                    // Pan And Adhar is upload or not
                    if ($Pan_Upload && $Adhar_Upload) {

                        try {
                            $Upload_query = "INSERT INTO customer_detail(
                                Account_No, C_First_Name, C_Last_Name, Street_name, Postal_code, Country, City, Province, 
                                C_Birth_Date, C_Adhar_No, C_Pan_No, C_Mobile_No, C_Email, C_Pincode, 
                                C_Adhar_Doc, C_Pan_Doc, ProfileColor, Gender, ProfileImage, Bio, Account_Type, Residency_Status, Currency_Preference, Source_Of_Wealth_Doc, Bank_Statement_Doc
                            ) VALUES(
                                '$Account_Number', '$First_Name', '$Last_Name', '$Street_Name', '$Postal_Code', '$Country', '$City', '$Province', 
                                '$Birth_Date', '$Adhar_Number', '$Pan_Number', '$Mobile_Number', '$Email', '$Pincode', 
                                '$Adhar_destinationFile', '$Pan_destinationFile', '$hex', 'Not Available', '', '', '$account_type','$Residency_Status','$Currency_Preference','$sourceWealthPath','$bankStatementPath'
                            )";
                            
                            // sql query for login table
                            $login_query = "INSERT INTO login(AccountNo, Username, Password, Status, State) 
                                            VALUES('$Account_Number', '$Username', '$hashPass', '$Account_Status', '0')";
                            
                            // sql query for Accounts table
                            $account_query = "INSERT INTO accounts(AccountNo, Balance, AccountType, SavingBalance, SavingTarget, State, Currency_Preference) 
                                              VALUES('$Account_Number', '$Balance', '$Account_Type', '0.0', '', '0','$Currency_Preference')";
                            
                            // query execution
                            mysqli_query($conn, $Upload_query) or die(mysqli_error($conn));
                            mysqli_query($conn, $login_query) or die(mysqli_error($conn));
                            mysqli_query($conn, $account_query) or die(mysqli_error($conn));
                            
                            require '../mail/congraMail.php';
                            sendMessage($Email, $First_Name);
                            
                        } catch (Exception $e) {
                            echo 'Message: ' . $e->getMessage();
                        }
                    }
                }
            } else {
                $Pan_Up_error = 'invalid file extention';
                $Adhar_Up_error = 'invalid file extention';
                echo ('invalid file extention');
            }
        } else {
            echo "File is too large";
            $Pan_Up_error = 'File is too large';
            $Adhar_Up_error = 'File is too large';
        }
    } else {
        echo " Please Give name to file";
        $Pan_Up_error = 'Please Give name to file';
        $Adhar_Up_error = 'Please Give name to file';
    }
}

?>

<!DOCTYPE html>
<html>

<head>

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Create Account   إميراترست | EmiraTrust</title>

    <!-- Favicons -->
    <link href="../assets/img/favicon-32x32.png" rel="icon">
    <link href="../assets/img/apple-icon-180x180.png" rel="apple-touch-icon">

    <!-- Bootstrap CSS -->
    <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">

    <!-- Project CSS -->
    <link rel="stylesheet" href="../assets/css/createAccount.css">


    <!-- Javascrip -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="../assets/js/createAc.js"></script>


</head>

<body>



    <form id="regForm" action="<?php htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST" enctype="multipart/form-data">
        <h1 class="mb-3" style="color: #8a2208" ><b>Register</b></h1>

        <!-- Tab 1 -->

        <div class="tab mb-3">
            <h3 class="mb-3 stepHead">Step 1/3</h3>
            <p class="SubAction">Personal Detail:</p>
            <div class="row g-2 mb-3">
                <div class="col-md">
                    <div class="form-floating">
                        <input type="text" name="FirstName" class="form-control" id="FirstName" placeholder="First Name">
                        <label for="floatingInputGrid">First Name</label>

                        <span id="FnameError" style="color: red;"><?php if (isset($_POST['submit'])) {
                                                                        echo $First_Name_error;
                                                                    } ?></span>
                    </div>
                </div>
                <div class="col-md">
                    <div class="col-md">
                        <div class="form-floating">

                            <input type="text" name="LastName" class="form-control" id="Lname" placeholder="Last Name">
                            <label for="floatingInputGrid">Last Name</label>

                            <span id="LnameError" style="color: red;"><?php if (isset($_POST['submit'])) {
                                                                            echo $Last_Name_error;
                                                                        } ?></span>

                        </div>
                    </div>
                </div>
            </div>
            <div class="row g-2 mb-3">
                <div class="col-md">
                    <div class="col-md">
                        <div class="form-floating">

                            <input type="text" name="StreetName" class="form-control" id="SName" placeholder="Street Name">
                            <label for="floatingInputGrid">Street Name</label>
                            <span id="StreetNameError" style="color: red;"><?php if (isset($_POST['submit'])) {
                                                                            echo $Street_Name_error;
                                                                        } ?></span>
                        </div>
                    </div>
                </div>
                <div class="col-md">
                    <div class="col-md">
                        <div class="form-floating">

                            <input type="text" name="PostalCode" class="form-control" id="PCode" placeholder="Postal Code">
                            <label for="floatingInputGrid">Postal Code</label>
                            <span id="PostalError" style="color: red;"><?php if (isset($_POST['submit'])) {
                                                                            echo $Postal_Code_error;
                                                                        } ?></span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row g-2 mb-3">
            <div class="col-md">
                    <div class="form-floating">
                        <select name="Country" class="form-select" id="Country">
                        <option value="" disabled selected>Select your country</option>
                            <option value="Afghanistan">Afghanistan</option>
                            <option value="Albania">Albania</option>
                            <option value="Algeria">Algeria</option>
                            <option value="American Samoa">American Samoa</option>
                            <option value="Andorra">Andorra</option>
                            <option value="Angola">Angola</option>
                            <option value="Anguilla">Anguilla</option>
                            <option value="Antarctica">Antarctica</option>
                            <option value="Antigua and Barbuda">Antigua and Barbuda</option>
                            <option value="Argentina">Argentina</option>
                            <option value="Armenia">Armenia</option>
                            <option value="Aruba">Aruba</option>
                            <option value="Australia">Australia</option>
                            <option value="Austria">Austria</option>
                            <option value="Azerbaijan">Azerbaijan</option>
                            <option value="Bahamas">Bahamas</option>
                            <option value="Bahrain">Bahrain</option>
                            <option value="Bangladesh">Bangladesh</option>
                            <option value="Barbados">Barbados</option>
                            <option value="Belarus">Belarus</option>
                            <option value="Belgium">Belgium</option>
                            <option value="Belize">Belize</option>
                            <option value="Benin">Benin</option>
                            <option value="Bermuda">Bermuda</option>
                            <option value="Bhutan">Bhutan</option>
                            <option value="Bolivia">Bolivia</option>
                            <option value="Bosnia and Herzegovina">Bosnia and Herzegovina</option>
                            <option value="Botswana">Botswana</option>
                            <option value="Bouvet Island">Bouvet Island</option>
                            <option value="Brazil">Brazil</option>
                            <option value="British Indian Ocean Territory">British Indian Ocean Territory</option>
                            <option value="Brunei Darussalam">Brunei Darussalam</option>
                            <option value="Bulgaria">Bulgaria</option>
                            <option value="Burkina Faso">Burkina Faso</option>
                            <option value="Burundi">Burundi</option>
                            <option value="Cabo Verde">Cabo Verde</option>
                            <option value="Cambodia">Cambodia</option>
                            <option value="Cameroon">Cameroon</option>
                            <option value="Canada">Canada</option>
                            <option value="Cayman Islands">Cayman Islands</option>
                            <option value="Central African Republic">Central African Republic</option>
                            <option value="Chad">Chad</option>
                            <option value="Chile">Chile</option>
                            <option value="China">China</option>
                            <option value="Christmas Island">Christmas Island</option>
                            <option value="Cocos (Keeling) Islands">Cocos (Keeling) Islands</option>
                            <option value="Colombia">Colombia</option>
                            <option value="Comoros">Comoros</option>
                            <option value="Congo">Congo</option>
                            <option value="Congo, Democratic Republic of the">Congo, Democratic Republic of the</option>
                            <option value="Cook Islands">Cook Islands</option>
                            <option value="Costa Rica">Costa Rica</option>
                            <option value="Croatia">Croatia</option>
                            <option value="Cuba">Cuba</option>
                            <option value="Cyprus">Cyprus</option>
                            <option value="Czech Republic">Czech Republic</option>
                            <option value="Denmark">Denmark</option>
                            <option value="Djibouti">Djibouti</option>
                            <option value="Dominica">Dominica</option>
                            <option value="Dominican Republic">Dominican Republic</option>
                            <option value="Ecuador">Ecuador</option>
                            <option value="Egypt">Egypt</option>
                            <option value="El Salvador">El Salvador</option>
                            <option value="Equatorial Guinea">Equatorial Guinea</option>
                            <option value="Eritrea">Eritrea</option>
                            <option value="Estonia">Estonia</option>
                            <option value="Eswatini">Eswatini</option>
                            <option value="Ethiopia">Ethiopia</option>
                            <option value="Falkland Islands (Malvinas)">Falkland Islands (Malvinas)</option>
                            <option value="Faroe Islands">Faroe Islands</option>
                            <option value="Fiji">Fiji</option>
                            <option value="Finland">Finland</option>
                            <option value="France">France</option>
                            <option value="French Guiana">French Guiana</option>
                            <option value="French Polynesia">French Polynesia</option>
                            <option value="Gabon">Gabon</option>
                            <option value="Gambia">Gambia</option>
                            <option value="Georgia">Georgia</option>
                            <option value="Germany">Germany</option>
                            <option value="Ghana">Ghana</option>
                            <option value="Gibraltar">Gibraltar</option>
                            <option value="Greece">Greece</option>
                            <option value="Greenland">Greenland</option>
                            <option value="Grenada">Grenada</option>
                            <option value="Guadeloupe">Guadeloupe</option>
                            <option value="Guam">Guam</option>
                            <option value="Guatemala">Guatemala</option>
                            <option value="Guernsey">Guernsey</option>
                            <option value="Guinea">Guinea</option>
                            <option value="Guinea-Bissau">Guinea-Bissau</option>
                            <option value="Guyana">Guyana</option>
                            <option value="Haiti">Haiti</option>
                            <option value="Honduras">Honduras</option>
                            <option value="Hong Kong">Hong Kong</option>
                            <option value="Hungary">Hungary</option>
                            <option value="Iceland">Iceland</option>
                            <option value="India">India</option>
                            <option value="Indonesia">Indonesia</option>
                            <option value="Iran">Iran</option>
                            <option value="Iraq">Iraq</option>
                            <option value="Ireland">Ireland</option>
                            <option value="Isle of Man">Isle of Man</option>
                            <option value="Israel">Israel</option>
                            <option value="Italy">Italy</option>
                            <option value="Jamaica">Jamaica</option>
                            <option value="Japan">Japan</option>
                            <option value="Jersey">Jersey</option>
                            <option value="Jordan">Jordan</option>
                            <option value="Kazakhstan">Kazakhstan</option>
                            <option value="Kenya">Kenya</option>
                            <option value="Kiribati">Kiribati</option>
                            <option value="Kuwait">Kuwait</option>
                            <option value="Kyrgyzstan">Kyrgyzstan</option>
                            <option value="Laos">Laos</option>
                            <option value="Latvia">Latvia</option>
                            <option value="Lebanon">Lebanon</option>
                            <option value="Lesotho">Lesotho</option>
                            <option value="Liberia">Liberia</option>
                            <option value="Libya">Libya</option>
                            <option value="Liechtenstein">Liechtenstein</option>
                            <option value="Lithuania">Lithuania</option>
                            <option value="Luxembourg">Luxembourg</option>
                            <option value="Macau">Macau</option>
                            <option value="Madagascar">Madagascar</option>
                            <option value="Malawi">Malawi</option>
                            <option value="Malaysia">Malaysia</option>
                            <option value="Maldives">Maldives</option>
                            <option value="Mali">Mali</option>
                            <option value="Malta">Malta</option>
                            <option value="Marshall Islands">Marshall Islands</option>
                            <option value="Martinique">Martinique</option>
                            <option value="Mauritania">Mauritania</option>
                            <option value="Mauritius">Mauritius</option>
                            <option value="Mexico">Mexico</option>
                            <option value="Micronesia">Micronesia</option>
                            <option value="Moldova">Moldova</option>
                            <option value="Monaco">Monaco</option>
                            <option value="Mongolia">Mongolia</option>
                            <option value="Montenegro">Montenegro</option>
                            <option value="Morocco">Morocco</option>
                            <option value="Mozambique">Mozambique</option>
                            <option value="Myanmar">Myanmar</option>
                            <option value="Namibia">Namibia</option>
                            <option value="Nauru">Nauru</option>
                            <option value="Nepal">Nepal</option>
                            <option value="Netherlands">Netherlands</option>
                            <option value="New Zealand">New Zealand</option>
                            <option value="Nicaragua">Nicaragua</option>
                            <option value="Niger">Niger</option>
                            <option value="Nigeria">Nigeria</option>
                            <option value="North Korea">North Korea</option>
                            <option value="North Macedonia">North Macedonia</option>
                            <option value="Norway">Norway</option>
                            <option value="Oman">Oman</option>
                            <option value="Pakistan">Pakistan</option>
                            <option value="Palau">Palau</option>
                            <option value="Panama">Panama</option>
                            <option value="Papua New Guinea">Papua New Guinea</option>
                            <option value="Paraguay">Paraguay</option>
                            <option value="Peru">Peru</option>
                            <option value="Philippines">Philippines</option>
                            <option value="Poland">Poland</option>
                            <option value="Portugal">Portugal</option>
                            <option value="Puerto Rico">Puerto Rico</option>
                            <option value="Qatar">Qatar</option>
                            <option value="Romania">Romania</option>
                            <option value="Russia">Russia</option>
                            <option value="Rwanda">Rwanda</option>
                            <option value="Saint Kitts and Nevis">Saint Kitts and Nevis</option>
                            <option value="Saint Lucia">Saint Lucia</option>
                            <option value="Saint Vincent and the Grenadines">Saint Vincent and the Grenadines</option>
                            <option value="Samoa">Samoa</option>
                            <option value="San Marino">San Marino</option>
                            <option value="Saudi Arabia">Saudi Arabia</option>
                            <option value="Senegal">Senegal</option>
                            <option value="Serbia">Serbia</option>
                            <option value="Seychelles">Seychelles</option>
                            <option value="Sierra Leone">Sierra Leone</option>
                            <option value="Singapore">Singapore</option>
                            <option value="Slovakia">Slovakia</option>
                            <option value="Slovenia">Slovenia</option>
                            <option value="Solomon Islands">Solomon Islands</option>
                            <option value="Somalia">Somalia</option>
                            <option value="South Africa">South Africa</option>
                            <option value="South Korea">South Korea</option>
                            <option value="South Sudan">South Sudan</option>
                            <option value="Spain">Spain</option>
                            <option value="Sri Lanka">Sri Lanka</option>
                            <option value="Sudan">Sudan</option>
                            <option value="Suriname">Suriname</option>
                            <option value="Sweden">Sweden</option>
                            <option value="Switzerland">Switzerland</option>
                            <option value="Syria">Syria</option>
                            <option value="Taiwan">Taiwan</option>
                            <option value="Tajikistan">Tajikistan</option>
                            <option value="Tanzania">Tanzania</option>
                            <option value="Thailand">Thailand</option>
                            <option value="Togo">Togo</option>
                            <option value="Tonga">Tonga</option>
                            <option value="Trinidad and Tobago">Trinidad and Tobago</option>
                            <option value="Tunisia">Tunisia</option>
                            <option value="Turkey">Turkey</option>
                            <option value="Turkmenistan">Turkmenistan</option>
                            <option value="Tuvalu">Tuvalu</option>
                            <option value="Uganda">Uganda</option>
                            <option value="Ukraine">Ukraine</option>
                            <option value="United Arab Emirates">United Arab Emirates</option>
                            <option value="United Kingdom">United Kingdom</option>
                            <option value="United States">United States</option>
                            <option value="Uruguay">Uruguay</option>
                            <option value="Uzbekistan">Uzbekistan</option>
                            <option value="Vanuatu">Vanuatu</option>
                            <option value="Vatican City">Vatican City</option>
                            <option value="Venezuela">Venezuela</option>
                            <option value="Vietnam">Vietnam</option>
                            <option value="Yemen">Yemen</option>
                            <option value="Zambia">Zambia</option>
                            <option value="Zimbabwe">Zimbabwe</option>

                        </select>
                        <label for="Country">Country</label>
                        <span id="CountryNameError" style="color: red;">
                            <?php if (isset($_POST['submit'])) echo $Country_error; ?>
                        </span>
                    </div>
                </div>

                <div class="col-md">
                    <div class="col-md">
                        <div class="form-floating">

                            <input type="text" name="City" class="form-control" id="City" placeholder="City">
                            <label for="floatingInputGrid">City</label>
                            <span id="CityNameError" style="color: red;"><?php if (isset($_POST['submit'])) {
                                                                            echo $City_error;
                                                                        } ?></span>
                        </div>
                    </div>
                </div>
                <div class="col-md">
                    <div class="col-md">
                        <div class="form-floating">

                            <input type="text" name="Province" class="form-control" id="Province" placeholder="Province">
                            <label for="floatingInputGrid">Province/State</label>
                            <span id="ProviceNameError" style="color: red;"><?php if (isset($_POST['submit'])) {
                                                                            echo $Province_error;
                                                                        } ?></span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row g-2 mb-3">
                <div class="col-md">
                    <div class="col-md">
                        <div class="form-floating">
                            <input type="date" name="BirthDate" class="form-control" id="BirthDate" placeholder="Birth Date">
                            <label for="floatingInputGrid">Birth Date</label>
                            <span id="AgeError" style="color: red;"><?php if (isset($_POST['submit'])) {
                                                                        echo $Birth_Date_error;
                                                                    } ?></span>
                        </div>
                    </div>
                </div>
                <div class="col-md">
                    <div class="col-md">
                        <div class="form-floating">
                            <input name="MobileNumber" class="form-control" type="tel" id="MobileNo" pattern="[0-9]{10,16}" placeholder="Mobile Number" onkeypress="return isNumber(event)">
                            <label for="floatingInputGrid">Mobile Number</label>
                            <span id="MobileNoError" style="color: red;"><?php if (isset($_POST['submit'])) {
                                                                                echo $Mobile_Number_error;
                                                                            } ?></span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row g-2 mb-3">
                <div class="col-md">
                    <div class="col-md">
                        <div class="form-floating">
                            <input type="text" name="PanNumber" class="form-control" id="PanNo" placeholder="Pan Number">
                            <label for="floatingInputGrid">SSN Number/Tax No</label>
                            <span id="PanError" style="color: red;"><?php if (isset($_POST['submit'])) {
                                                                        echo $Pan_Number_error;
                                                                    } ?></span>
                        </div>
                    </div>
                </div>
                <div class="col-md">
                    <div class="col-md">
                        <div class="form-floating">
                            <input name="AdharNumber" class="form-control" type="text" id="AdharNo"  placeholder="National ID Number" onkeypress="return isNumber(event)">
                            <label for="floatingInputGrid">National ID/Passport/Driving License</label>
                            <span id="AdharError" style="color: red;"><?php if (isset($_POST['submit'])) {
                                                                            echo $Adhar_Number_error;
                                                                        } ?></span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row g-2 mb-3">
                <div class="col-md">
                    <div class="col-md">
                        <div class="form-floating">
                            <input type="email" name="email" class="form-control" id="email" placeholder="Email Address">
                            <label for="floatingInputGrid">Email Address</label>
                            <span id="EmailError" style="color: red;"><?php if (isset($_POST['submit'])) {
                                                                            echo $Email_error;
                                                                        } ?></span>
                        </div>
                    </div>
                </div>
                <div class="col-md">
                    <div class="col-md">
                        <div class="form-floating">
                            <input name="pincode" class="form-control" type="tel" id="pincode" pattern="[0-9]{1,8}" placeholder="Pin Code" onkeypress="return isNumber(event)">
                            <label for="floatingInputGrid">Pin Code/ Zip Code</label>
                            <span id="PincodeError" style="color: red;"><?php if (isset($_POST['submit'])) {
                                                                            echo $Pincode_error;
                                                                        } ?></span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row g-2 mb-3">
                        <div class="col-md">
                            <div class="form-floating">
                                <select class="form-select" id="residency" name="Residency_Status" required>
                                    <option value="" selected disabled>Select Residency</option>
                                    <option value="Resident">Resident</option>
                                    <option value="Non Resident">Non Resident</option>
                                </select>
                                <label for="residency">Residency Status</label>
                            </div>
                        </div>

                        <div class="col-md" id="currencyDiv">
                            <div class="form-floating">
                                <select class="form-select" id="currency" name="Currency_Preference" required>
                                    <option value="" selected disabled>Select Currency</option>
                                    <option value="UAE">AED</option>
                                    <option value="USD">USD</option>
                                </select>
                                <label for="currency">Preferred Currency</label>
                            </div>
                        </div>
                    </div>

                    <div class="row g-2 mb-3" id="sourceWealthDiv" style="display: none;">
                        <div class="col-md">
                            <div class="form-floating">
                                <input type="file" class="form-control" id="sourceWealth" name="Source_Of_Wealth_Doc">
                                <label for="sourceWealth">Upload Detail of Source of Wealth</label>
                            </div>
                        </div>
                    </div>

                    <div class="row g-2 mb-3" id="bankStatementDiv" style="display: none;">
                        <div class="col-md">
                            <div class="form-floating">
                                <input type="file" class="form-control" id="bankStatement" name="Bank_Statement_Doc">
                                <label for="bankStatement">Upload Bank Statement(6 months)</label>
                            </div>
                        </div>
                    </div>


        </div>

        <!-- Tab 2 -->

        <div class="tab mb-3" id="KycTab">
            <h3 class="mb-3 stepHead">Step 2/3</h3>
            <p class="SubAction">Upload KYC Document (National ID)</p>

            <div class="form-group mb-3">
                <label for="exampleFormControlFile1">Front ID:</label>
                <input type="file" name="PanCardUp" class="form-control-file" id="PANCardUp" size="30" accept="image/jpg,image/png,image/jpeg,image/gif">
                <span id="PanUPError" style="color: red;"><?php if (isset($_POST['submit'])) {
                                                                echo $Pan_Up_error;
                                                            } ?></span>
            </div>
            <div class="form-groupmb-3">
                <label for="exampleFormControlFile1">Back ID:</label>
                <input type="file" name="AdharCardUp" class="form-control-file" id="AdharCardUp" size="30" accept="image/jpg,image/png,image/jpeg,image/gif">
                <span id="AdharUpError" style="color: red;"><?php if (isset($_POST['submit'])) {
                                                                echo $Adhar_Up_error;
                                                            } ?></span>
            </div>

            <p class="SubAction">Select Account Type</p>
            <div class="col-md">
                <div class="col-md">
                    <div class="form-floating">
                        <select name="account_type" class="form-control" id="account_type">
                            <option value="Excellency">Excellency</option>
                            <option value="Elite">Elite</option>
                            <option value="Premier">Premier</option>
                            <option value="Signature">Signature Class </option>
                            <option value="savings">Savings</option>
                            <option value="checking">Checking</option>
                        </select>
                        <label for="account_type">Account Type</label>
                        <span id="AccountTypeError" style="color: red;"><?php if (isset($_POST['submit'])) { 
                            echo $AccountType_error;
                        } ?></span>
                    </div>
                </div>
            </div>


            <span id="mailsendError"></span>
        </div>     
       

        

        <div class="tab">
            <h3 class="mb-3 stepHead">Step 3/3</h3>
            <p class="SubAction">Create Username and Password</p>

            <div class="col-md mb-3">
                <div class="col-md">
                    <div class="form-floating">
                        <input type="text" class="form-control" name="Username" id="Username" placeholder="Create Username">
                        <label for="floatingInputGrid">Create Username</label>

                        <span style="color: red;" id="UsernameError" name="UsernameError"><?php if (isset($_POST['submit'])) {
                                                                                                echo $UsernameError;
                                                                                            } ?></span>
                    </div>
                </div>
            </div>
            <div class="col-md mb-3">
                <div class="col-md">
                    <div class="form-floating">
                        <input class="form-control" type="password" name="Password" id="Password" placeholder="Enter Password" data-toggle="tooltip" data-placement="top" title="Enter Password with atleast 8 charater long with 1 Capital 1 small 1 number and 1 special charater">
                        <label for="floatingInputGrid">Enter Password</label>

                        <span style="color: red;" id="PasswordError" name="PasswordError"><?php if (isset($_POST['submit'])) {
                                                                                                echo $PasswordError;
                                                                                            } ?></span>
                    </div>
                </div>
            </div>
            <div class="col-md mb-3">
                <div class="col-md">
                    <div class="form-floating">
                        <input class="form-control" type="password" name="ConfirmPass" id="ConfirmPass" placeholder="Confirm Password">
                        <label for="floatingInputGrid">Confirm Password</label>

                        <span style="color: red;" id="ConfirmPassError" name="ConfirmPassError"><?php if (isset($_POST['submit'])) {
                                                                                                    echo $ConfirmPassError;
                                                                                                } ?></span>
                    </div>
                </div>
            </div>
        </div>

        </div>
        <div style="overflow:auto;">
            <div style="float:right;">
                <button type="button" id="prevBtn" class="CustomButton" onclick="nextPrev(-1)">Previous</button>
                <button type="button" id="nextBtn" class="CustomButton" onclick="nextPrev(1)">Next</button>
                <input type="submit" name="submit" id="submitBtn" class="CustomButton" style="display: none;">
            </div>
        </div>
        <!-- Circles which indicates the steps of the form: -->
        <div style="text-align:center;margin-top:40px;">
            <span class="step"></span>
            <span class="step"></span>
            <span class="step"></span>
            
         <p class="login-card-footer-text">Already a member? <a href="../user/login.php" class="text-reset">Log in</a></p>
                            <nav class="login-card-footer-nav">
                                <a href="../terms.html">Terms of use.</a>
                                <a href="../privacypolicy.html">Privacy policy</a>
                            </nav>
    </form>
   


    <script src="../assets/js/createAccount.js"></script>

    <!-- Vendor JS Files -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js" integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.6.0/dist/umd/popper.min.js" integrity="sha384-KsvD1yqQ1/1+IA7gi3P0tyJcT3vR+NdBTt13hSJ2lnve8agRGXTTyNaBYmCR/Nwi" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.min.js" integrity="sha384-nsg8ua9HAw1y0W1btsyWgBklPnCUAFLuTMS2G72MMONqmOymq585AcH49TLBQObG" crossorigin="anonymous"></script>
    <script>
    const residencySelect = document.getElementById("residency");
    const sourceWealthDiv = document.getElementById("sourceWealthDiv");
    const bankStatementDiv = document.getElementById("bankStatementDiv");
    const sourceWealth = document.getElementById("sourceWealth");
    const bankStatement = document.getElementById("bankStatement");

    residencySelect.addEventListener("change", function () {
        const value = this.value;

        if (value === "Non Resident") {
            sourceWealthDiv.style.display = "block";
            bankStatementDiv.style.display = "block";

            sourceWealth.required = true;
            bankStatement.required = true;

            sourceWealth.disabled = false;
            bankStatement.disabled = false;
        } else {
            sourceWealthDiv.style.display = "none";
            bankStatementDiv.style.display = "none";

            sourceWealth.required = false;
            bankStatement.required = false;

            sourceWealth.disabled = true; //
            bankStatement.disabled = true;

            sourceWealth.value = ''; // Clear files
            bankStatement.value = '';
        }
    });
</script>






</body>

</html>