<?php
include 'connection.php';
session_start();

// Check if session data exists
if (!isset($_SESSION['accountNo'])) {
    header("Location: login.php?error=Session expired. Please login again.");
    exit();
}

$accountNo = $_SESSION['accountNo'];

if (isset($_POST['verify'])) {
    $enteredOtp = mysqli_real_escape_string($conn, $_POST['otp']);

    $query = "SELECT Username, otp_code, is_verified, State, Status FROM login WHERE AccountNo = '$accountNo'";
    $result = mysqli_query($conn, $query);

    if ($row = mysqli_fetch_assoc($result)) {
        $storedOtp = $row['otp_code'];
        $username = $row['Username'];
        $state = $row['State'];
        $status = $row['Status'];
    

        if ($enteredOtp == $storedOtp) {
            // Update verification status permanently
            $updateQuery = "UPDATE login SET is_verified = 1 WHERE AccountNo = '$accountNo'";
            mysqli_query($conn, $updateQuery);

            // Set session data
            $_SESSION['username'] = $username;
            $_SESSION['state'] = $state;
            $_SESSION['status'] = $status;

            // Redirect based on role
            if ($state == 0) {
                header("Location: ../user/UserData/Dashboard.php");
                exit();
            } elseif ($state == 1 && $status === "Super") {
                header("Location: ../admin/Dashboard.php");
                exit();
            } else {
                header("Location: login.php?error=Account not activated.");
                exit();
            }
        } else {
            $error = "Invalid OTP. Please try again.";
        }
    } else {
        $error = "Account not found.";
    }
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Verify OTP -   إميراترست | EmiraTrust</title>
    <link rel="stylesheet" href="../assets/css/login.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
</head>

<body>
    <main class="d-flex align-items-center min-vh-100 py-3">
        <div class="container">
            <div class="card login-card">
                <div class="card-body">
                    <div class="brand-wrapper text-center">
                        <img src="../assets/img/Logo.svg" alt="logo" class="logo mb-2"  width="55">
                    </div>
                     <p  style="color: #8a2208">We need to check if you meet our criteria.OTP will be sent to your registered Email address on inbox or spam onced you are verified inorder complete registration process. It usually takes up to 5 working days.<br>Thank you for showing interest on our services.</p>
                    <form method="POST" action="">
                        <?php if (isset($error)) { ?>
                            <div class="alert alert-danger"><?php echo $error; ?></div>
                        <?php } ?>
                        <div class="form-group">
                            <label for="otp" style="color: #8a2208"><b>Enter OTP sent to your Email to Complete registration process</b></label>
                            <input type="text" class="form-control" name="otp" id="otp" required>
                        </div>
                        <button type="submit" name="verify" class="btn btn-primary btn-block"style="background: #8a2208">Verify OTP</button>
                        <p class="text-center mt-3">
                            <a href="login.php" style="color: #8a2208">Back to Login</a>
                        </p>
                    </form>
                </div>
            </div>
        </div>
    </main>
</body>

</html>
