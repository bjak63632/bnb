<?php
include('database_connection.php'); // Include your DB connection file
session_start();
$username = $_SESSION['username'];

// Assuming the user is logged in and their ID is stored in $_SESSION['user_id'

// Function to check if the user has uploaded a profile picture
function hasProfilePicture($username) {
    global $pdo;
    $query = "SELECT ProfileImage FROM customer_detail WHERE username = ?";
    $stmt = $pdo->prepare($query);
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();
    
    return !empty($username['ProfilImage']); 
    // Return true if profile picture exists, false otherwise
}

// Check if user has uploaded profile picture
if (!hasProfilePicture($user_id)) {
    // If no profile picture, prevent transaction and show message
    echo "<script>
            alert('You must upload a profile picture to make transactions. Please complete your registration.');
            window.location.href = 'profile.php'; // Redirect to profile page
          </script>";
    exit; // Stop further execution
}

// If profile picture exists, proceed with the transaction logic
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Process the transaction (add your transaction code here)
    $amount = $_POST['amount'];
    $transaction_type = $_POST['transaction_type'];

    // Example transaction logic
    $query = "INSERT INTO transactions (user_id, amount, type) VALUES (?, ?, ?)";
    $stmt = $pdo->prepare($query);
    $stmt->execute([$user_id, $amount, $transaction_type]);

    echo "<script>
            alert('Transaction successfully processed!');
            window.location.href = 'Dashboard.php'; // Redirect to dashboard or appropriate page
          </script>";
    exit;
}
?>
