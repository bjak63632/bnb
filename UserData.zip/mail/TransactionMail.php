<?php 

require 'PHPMailerAutoload.php';
require 'class.smtp.php';
require __DIR__ . '/../../vendor/autoload.php';


function sendMail($templatePath, $subject, $customerMail, $name, $amount, $totalAmount, $date, $AccountNo) {
    $mail = new PHPMailer;
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->Port = 587;
    $mail->SMTPAuth = true;
    $mail->SMTPSecure = 'tls';

    // Use environment variables or config files for better security
    $mail->Username = '002ericanthony@gmail.com';
    $mail->Password = 'zdlecvwkbktwvduk';

    $content = file_get_contents($templatePath);
    $mail->setFrom('002ericanthony@gmail.com', '  إميراترست | EmiraTrust');
    $mail->addAddress($customerMail);
    $mail->addReplyTo('002ericanthony@gmail.com');

    $mail->isHTML(true);
    $mail->Subject = $subject;

    $swap_var = [
        '{Name}'        => $name,
        '{AccountNo}'   => $AccountNo,
        '{Amount}'      => $amount,
        '{Date}'        => $date,
        '{totalAmount}' => $totalAmount
    ];

    foreach ($swap_var as $key => $value) {
        $content = str_replace($key, htmlspecialchars($value), $content);
    }

    $mail->Body = $content;

    if (!$mail->send()) {
        error_log("Mailer Error: " . $mail->ErrorInfo);
        return false;
    }

    return true;
}

function debitMoneyMail($customerMail, $name, $amount, $totalAmount, $date, $AccountNo) {
    $subject = "Your Account '$AccountNo' has been debited";
    return sendMail('../mail/DebitMailTemp.php', $subject, $customerMail, $name, $amount, $totalAmount, $date, $AccountNo);
}

function creditMoneyMail($customerMail, $name, $amount, $totalAmount, $date, $AccountNo) {
    $subject = "Your Account '$AccountNo' has been credited";
    return sendMail('../mail/CreditMailTemp.php', $subject, $customerMail, $name, $amount, $totalAmount, $date, $AccountNo);
}
?>
