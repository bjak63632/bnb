<?php
header('Content-Type: application/json');
ini_set('display_errors', 0);
error_reporting(E_ALL);
include "../connection.php";
session_start();

$AcNo = $_SESSION['AccountNo'];

if (isset($_POST['action']) && $_POST['action'] === 'ach_wire_transfer') {
    $sender_name = $_POST['sender_name'];
    $sender_account_number = $_POST['sender_account_number'];
    $routing_number = $_POST['routingNumber'];
    $bank_name = $_POST['bankName'];
    $account_type = $_POST['account_type'];
    $street_name = $_POST['streetname'];
    $street_number = $_POST['streetnumber'];
    $apartment = $_POST['apartment'];
    $floor = $_POST['floor'];
    $postal_code = $_POST['postal_code'];
    $country = $_POST['country'];
    $city = $_POST['city'];
    $province = $_POST['province'];
    $recipient_name = $_POST['recipient_name'];
    $amount = floatval($_POST['amount']);
    $recipient_account_number = $_POST['recipient_account_number'];
    $currency = $_POST['currency']; // ✅ pulled from frontend POST data

    // Fetch sender info
    $stmt = $conn->prepare("
        SELECT * FROM customer_detail 
        JOIN login ON customer_detail.Account_No = login.AccountNo 
        JOIN accounts ON accounts.AccountNo = login.AccountNo 
        WHERE customer_detail.Account_No = ?
    ");
    $stmt->bind_param("s", $sender_account_number);
    $stmt->execute();
    $senderResult = $stmt->get_result();

    if ($senderResult->num_rows === 0) {
        echo json_encode(["status" => "error", "message" => "Sender account not found"]);
        exit;
    }

    $sender = $senderResult->fetch_assoc();
    $SBalance = $sender['Balance'];
    $SStatus = $sender['Status'];
    $SProColor = $sender['ProfileColor'];
    $ProfileImage = trim($sender['ProfileImage']);

    // 🔐 Profile image check
    if (empty($ProfileImage)) {
        echo json_encode([
            "status" => "error",
            "message" => "Please upload your profile picture before making a wire transfer."
        ]);
        exit;
    }

    if ($SStatus !== "Active") {
        echo json_encode(["status" => "error", "message" => "Sender account is not active"]);
        exit;
    }

   // Define minimum limits per currency
$minLimits = [
    'USD' => 1500000,
    'AED' => 5500000, // You can adjust this manually
];

if (!isset($minLimits[$currency])) {
    echo json_encode(["status" => "error", "message" => "Unsupported currency for transfer."]);
    exit;
}

$minTransferLimit = $minLimits[$currency];

if ($amount < $minTransferLimit) {
    echo json_encode([
        "status" => "error",
        "message" => "Transaction failed. The transfer amount must be at least $minTransferLimit $currency."
    ]);
    exit;
}


    if ($SBalance < $amount) {
        echo json_encode(["status" => "error", "message" => "Transaction failed. Not sufficient balance!"]);
        exit;
    }

    mysqli_begin_transaction($conn);
    try {
        $stmt = $conn->prepare("
            INSERT INTO achwire_transfers (
                sender_name, sender_account_number, routing_number, bank_name, account_type,
                street_name, street_number, apartment, floor, postal_code, country, city, province,
                recipient_name, amount, recipient_account_number
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->bind_param("sssssssssssssssd",
            $sender_name, $sender_account_number, $routing_number, $bank_name, $account_type,
            $street_name, $street_number, $apartment, $floor, $postal_code, $country, $city, $province,
            $recipient_name, $recipient_account_number, $amount
        );
        $stmt->execute();

        // Update balance
        $newBalance = $SBalance - $amount;
        $stmt = $conn->prepare("UPDATE accounts SET Balance = ? WHERE AccountNo = ?");
        $stmt->bind_param("ds", $newBalance, $sender_account_number);
        $stmt->execute();

        // Transaction record
        $debitAmount = '-' . $amount;
        $stmt = $conn->prepare("
            INSERT INTO transaction (AccountNo, FAccountNo, Name, Amount, Status, ProfileColor, Credit, Debit)
            VALUES (?, ?, ?, ?, 'Pending', ?, '0.0', ?)
        ");
        $stmt->bind_param("sssssd", $sender_account_number, $recipient_account_number, $recipient_name, $debitAmount, $SProColor, $amount);
        $stmt->execute();

        mysqli_commit($conn);
        echo json_encode(["status" => "success", "message" => "ACH wire transfer submitted successfully"]);
        exit;
    } catch (Exception $e) {
        mysqli_rollback($conn);
        echo json_encode(["status" => "error", "message" => "Transaction failed. Please try again."]);
        exit;
    }
} else {
    echo json_encode(["status" => "error", "message" => "Invalid request"]);
    exit;
}
?>
