<?php
include "../connection.php";

session_start();

if (!isset($_SESSION['username'])) {
    header("Location: ../login.php");
}
$username = $_SESSION['username'];
// $query = "SELECT * FROM customer_detail JOIN login ON customer_detail.Account_No = login.AccountNo WHERE login.Username = '$username'";
// $result = mysqli_query($conn, $query);

// if (mysqli_num_rows($result) > 0) {

//     while ($row = mysqli_fetch_assoc($result)) {



//     }
//   }

?>
<!doctype html>
<html lang="en">


    <meta charset="UTF-8">
    <link rel="icon" type="image/png" href="favicon.png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Press+Start+2P&amp;display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        /* General Reset */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        html, body {
           font-family: Arial, sans-serif;
            background: radial-gradient(circle, #1a1a2e, #16213e);
            background-size: cover; /* Ensure full coverage */
            color: white;
            overflow-x: hidden;
            position: relative;
            margin: 0;
            padding: 0;
            min-height: 100vh; /* Ensure full height coverage */
        }

        .about {
            padding: 36px 24px;
            position: relative;
            background: linear-gradient(45deg, rgba(26, 26, 46, 0.9), rgba(22, 33, 62, 0.9));
            margin: 50px 0;
            z-index: 1;
        }

        .about-content {
            max-width: 1200px;
            margin: 0 auto;
            text-align: center;
        }

        .about-title {
            font-size: 2.5rem;
            color: #00ffcc;
            margin-bottom: 30px;
            text-transform: none;
            text-shadow: 0 0 20px rgba(0, 255, 204, 0.5);
            animation: titlePulse 2s infinite;
        }

        .about-description {
            font-size: 1rem;
            line-height: 1.8;
            margin-bottom: 30px;
            color: #fff;
            text-shadow: 0 0 10px rgba(0, 255, 204, 0.3);
        }

        .highlight {
            color: #ff7eb3;
            text-shadow: 0 0 10px rgba(255, 126, 179, 0.5);
        }

        /* Stats Grid */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 30px;
            margin-top: 60px;
            padding: 20px;
        }

        .stat-item {
            background: rgba(0, 255, 204, 0.1);
            padding: 30px 20px;
            border-radius: 15px;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            animation: breathe 4s infinite ease-in-out;
        }

        .stat-item:hover {
            transform: translateY(-10px);
            box-shadow: 0 0 30px rgba(0, 255, 204, 0.2);
        }

        .stat-value {
            font-size: 2.5rem;
            color: #00ffcc;
            margin-bottom: 15px;
            text-shadow: 0 0 10px rgba(0, 255, 204, 0.5);
        }

        .stat-label {
            color: #ff7eb3;
            font-size: 0.9rem;
        }

        /* Animated Background */
        .background-effects {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            z-index: 0;
        }

        .symbol {
            position: absolute;
            color: rgba(0, 255, 204, 0.2);
            font-size: 94px;
            animation: float 3s infinite ease-in-out;
        }

        @keyframes float {

            0%,
            100% {
                transform: translateY(0);
            }

            50% {
                transform: translateY(-20px);
            }
        }

        /* Terminal Banner */
        .terminal-banner {
            background: #000;
            color: #00ff00;
            padding: 10px 0;
            white-space: nowrap;
            overflow: hidden;
            position: fixed;
            /* Change from relative to fixed */
            top: 0;
            /* Ensures it stays at the top of the screen */
            left: 0;
            width: 100%;
            /* Makes it span the full width of the screen */
            z-index: 9999;
            /* Ensures it stays above other content */
            font-family: 'Press Start 2P', cursive;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
            /* Optional: Adds a shadow to separate it from the header */
        }

        .terminal-content {
            display: inline-block;
            animation: slide 15s linear infinite;
            padding-right: 50px;
        }

        @keyframes slide {
            0% {
                transform: translateX(100%);
            }

            100% {
                transform: translateX(-100%);
            }
        }

        /* Header */
        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px 20px; /* Reduced padding */
            background: rgba(17, 17, 17, 0.9);
            position: sticky;
            top: 30px;
            z-index: 100;
            width: 100%;
            box-sizing: border-box; /* Important for padding */
            max-width: 100vw; /* Ensure header doesn't exceed viewport */
        }

        .header-left {
            flex: 1;
        }

        .header-center {
            flex: 2;
            display: flex;
            justify-content: center;
        }

        .header-right {
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: flex-end;
            gap: 20px;
        }

        .logo {
            font-size: 1.2rem;
            text-shadow: 0 0 10px #00ffcc;
            animation: glow 2s infinite alternate;
        }

        @keyframes glow {
            0% {
                text-shadow: 0 0 10px var(--glow-color, #00ffcc);
            }

            50% {
                text-shadow: 0 0 20px var(--glow-color, #00ffcc), 0 0 30px var(--glow-color, #00ffcc);
            }

            100% {
                text-shadow: 0 0 10px var(--glow-color, #00ffcc);
            }
        }

        .nav-links {
            display: flex;
            gap: 20px;
        }

        .nav-links a {
            color: white;
            text-decoration: none;
            position: relative;
        }

        .nav-links a::after {
            content: '';
            position: absolute;
            bottom: -5px;
            left: 0;
            width: 100%;
            height: 2px;
            background: #ff7eb3;
            transform: scaleX(0);
            transition: transform 0.3s ease;
        }

        .nav-links a:hover::after {
            transform: scaleX(1);
        }

        .image-navigation {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 20px;
            margin-bottom: 20px;
        }

        .nav-button {
            background: linear-gradient(90deg, #ff7eb3, #ff758c);
            border: none;
            color: white;
            padding: 10px 15px;
            border-radius: 50%;
            cursor: pointer;
            font-family: 'Press Start 2P', cursive;
            font-size: 14px;
            transition: transform 0.2s ease;
        }

        .nav-button:hover {
            transform: scale(1.1);
        }

        .chadmas-title {
            text-align: center;
            /* Center the text */
            font-size: 1.5rem;
            /* Slightly larger font */
            color: #ffffff;
            /* White text */
            margin-bottom: 20px;
            /* Space below the line */
            font-weight: bold;
            /* Bold to emphasize Chad vibes */
            animation: glow 1.5s infinite;
            /* Glowing effect */
            text-shadow: 0 0 15px #00FFCC;
            /* Chad glow */
        }

        @keyframes glow {
            0% {
                text-shadow: 0 0 5px #00FFCC, 0 0 10px #00FFCC, 0 0 20px #00FFCC;
            }

            50% {
                text-shadow: 0 0 10px #00FFCC, 0 0 20px #00FFCC, 0 0 40px #00FFCC;
            }

            100% {
                text-shadow: 0 0 5px #00FFCC, 0 0 10px #00FFCC, 0 0 20px #00FFCC;
            }
        }

        /* Hero Section */
        .hero {
            text-align: center;
            padding: 60px 20px;
            position: relative;
            z-index: 1;
        }

        .hero h1 {
            font-size: 3rem;
            text-shadow: 0 0 20px #00ffcc;
            margin-bottom: 20px;
            animation: titlePulse 2s infinite;
            word-wrap: break-word;
            max-width: 100%;
            padding: 0 10px;
        }

        @keyframes titlePulse {

            0%,
            100% {
                transform: scale(1);
            }

            50% {
                transform: scale(1.05);
            }
        }

        .hero p {
            margin-bottom: 30px;
            font-size: 1.2rem;
            color: #ff7eb3;
        }

        .hero p2 {
            margin-bottom: 30px;
            font-size: 1rem;
            color: #ffffff;
            animation: glow 1.5s infinite;
        }

        .perks p2 {
            text-align: center;
            margin-bottom: 30px;
            font-size: 1rem;
            color: #ffffff;
            animation: glow 1.5s infinite;
        }

        .mint-button {
            background: linear-gradient(90deg, #ff7eb3, #ff758c);
            padding: 20px 50px;
            border: none;
            color: white;
            font-family: Arial, sans-serif;
            cursor: pointer;
            position: relative;
            overflow: hidden;
            transition: all 0.3s ease;
            border-radius: 25px;
        }

        .mint-button::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: rgba(255, 255, 255, 0.2);
            transform: rotate(45deg);
            animation: shine 3s infinite;
        }

        .mint-button:disabled {
            opacity: 0.7;
            cursor: not-allowed;
            pointer-events: none;
        }

        .mint-button.minting {
            background: linear-gradient(90deg, #ff7eb3, #ff758c);
            animation: mintingPulse 1.5s infinite;
        }

        @keyframes mintingPulse {

            0%,
            100% {
                opacity: 1;
            }

            50% {
                opacity: 0.7;
            }
        }

        .mint-hint {
            color: #00ffcc;
            font-size: 0.8rem;
            font-family: Arial, sans-serif;
            margin: 15px 0;
            text-align: center;
            position: relative;
            text-shadow:
                0 0 5px rgba(0, 255, 204, 0.8),
                0 0 10px rgba(0, 255, 204, 0.5);
            animation: hintGlow 2s infinite alternate;
        }

        @keyframes hintGlow {
            from {
                text-shadow: 0 0 5px rgba(0, 255, 204, 0.8),
                    0 0 10px rgba(0, 255, 204, 0.5);
            }

            to {
                text-shadow: 0 0 10px rgba(0, 255, 204, 0.8),
                    0 0 20px rgba(0, 255, 204, 0.5),
                    0 0 30px rgba(0, 255, 204, 0.3);
            }
        }

        .bonus-info {
            color: white;
            text-shadow: 0 0 10px var(--glow-color, #00ffcc);
            font-size: 1rem;
            margin: 15px 0;
            text-align: center;
            animation: glow 1.5s infinite;
        }

        @keyframes bonusPulse {

            0%,
            100% {
                transform: scale(1);
            }

            50% {
                transform: scale(1.05);
            }
        }

        /* Gallery */
        .gallery {
            padding: 50px 20px;
            text-align: center;
            margin-top: 20px;
        }

        .gallery h2 {
            margin-bottom: 40px;
            color: #00ffcc;
        }

        .gallery-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 30px;
            padding: 0 20px;
        }

        .gallery-item {
            position: relative;
            transform-style: preserve-3d;
            animation: breathe 4s infinite ease-in-out;
        }

        @keyframes breathe {

            0%,
            100% {
                transform: scale(1) translateY(0);
            }

            50% {
                transform: scale(1.05) translateY(-10px);
            }
        }

        .gallery-item img {
            width: 100%;
            height: auto;
            border-radius: 15px;
            transition: transform 0.3s ease;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
        }

        .gallery-item:hover img {
            transform: scale(1.1);
            box-shadow: 0 0 30px rgba(255, 117, 140, 0.8);
        }

        .amount-selector {
            display: flex;
            align-items: center;
            gap: 10px;
            margin: 20px 0;
        }

        .amount-btn {
            background: linear-gradient(90deg, #ff7eb3, #ff758c);
            border: none;
            color: white;
            width: 40px;
            height: 40px;
            border-radius: 8px;
            font-size: 20px;
            cursor: pointer;
           font-family: Arial, sans-serif;
            transition: transform 0.2s ease;
        }

        .amount-btn:hover {
            transform: scale(1.1);
        }

        #mintAmount {
            background: rgba(255, 126, 179, 0.1);
            border: 2px solid #ff7eb3;
            color: white;
            padding: 10px;
            width: 80px;
            text-align: center;
            font-family: Arial, sans-serif;
            font-size: 16px;
            border-radius: 8px;
        }

        /*GPT */

        .featured-image {
            position: relative;
            width: 100%;
            padding-bottom: 100%;
            overflow: visible;
            border-radius: 25px;
            box-shadow: 0 0 30px rgba(0, 255, 204, 0.2);
            background:#8a2208;
        }

        /* Modify the glow effect to be always visible */
        .featured-image::before {
            content: '';
            position: absolute;
            top: -10px;
            left: -10px;
            right: -10px;
            bottom: -10px;
            background: linear-gradient(45deg, #ff7eb3, #00ffcc);
            border-radius: 20px;
            z-index: -1;
            opacity: 1; /* Changed from 0 to 1 */
            animation: musicGlow 2s infinite; /* Always animate */
        }

        /* Remove the music-playing class condition since we want it always glowing */
        .featured-image.music-playing::before {
            opacity: 1;
            animation: musicGlow 2s infinite;
        }

        @keyframes musicGlow {
            0% {
                transform: scale(1);
                filter: blur(10px);
            }

            50% {
                transform: scale(1.05);
                filter: blur(15px);
            }

            100% {
                transform: scale(1);
                filter: blur(10px);
            }
        }

        .featured-image img {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            object-fit: cover;
            opacity: 0;
            transition: opacity 1s ease-in-out;
            border-radius: 25px;
            /* Added to match container */
        }

        .featured-image img.active {
            opacity: 1;
            z-index: 2;
        }

        .featured-image img.next {
            opacity: 0;
            z-index: 1;
        }

        /* Fade Out Animation */
        .featured-image img.fade-out {
            opacity: 0;
            z-index: 2;
        }

        /* Container Styles */
        .mint-container {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 40px;
            max-width: 1000px;
            /* Reduced from 1200px */
            margin: 40px auto;
            padding: 20px;
            align-items: center;
            background:#8a2208;
            border-radius: 20px;
            backdrop-filter: blur(10px);
        }

        @media (max-width: 768px) {
            .image-navigation {
                gap: 10px;
            }

            .nav-button {
                padding: 8px 12px;
                font-size: 12px;
            }

        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .mint-container {
                grid-template-columns: 1fr;
                gap: 20px;
            }

            .featured-image {
                padding-bottom: 100%;
            }
        }

        .mint-action {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 20px;
        }

        .mint-button {
            width: 100%;
            max-width: 300px;
            padding: 25px 40px;
            font-size: 1.2rem;
        }

        .mint-details {
            text-align: center;
            color: #ff7eb3;
            margin-top: 20px;
        }

        .mint-details p {
            margin: 10px 0;
            font-size: 1rem;
        }


        /* Footer */
        footer {
            background: rgba(17, 17, 17, 0.9);
            text-align: center;
            padding: 20px;
            margin-top: 50px;
        }

        footer a {
            color: #00ffcc;
            text-decoration: none;
            margin: 0 10px;
        }

        footer a:hover {
            text-shadow: 0 0 10px #00ffcc;
        }

        .music-player {
            margin-left: 15px;
        }

        .wallet-button {
            background: rgba(0, 255, 204, 0.1);
            border: 1px solid #00ffcc;
            border-radius: 20px;
            padding: 8px 16px;
            color: #00ffcc;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s ease;
        }

        .wallet-button:hover {
            background: rgba(0, 255, 204, 0.2);
            box-shadow: 0 0 10px rgba(0, 255, 204, 0.3);
        }

        .music-text {
            color: #ff7eb3;
            font-size: 0.6rem;
            font-family: Arial, sans-serif;
            text-transform: none;
            animation: textPulse 2s infinite;
            white-space: nowrap;
        }

        @keyframes textPulse {

            0%,
            100% {
                opacity: 1;
            }

            50% {
                opacity: 0.7;
            }
        }

        .music-toggle {
            width: 40px;
            height: 40px;
            background: none;
            border: 2px solid #ff7eb3;
            border-radius: 50%;
            position: relative;
            cursor: pointer;
            overflow: hidden;
            transition: all 0.3s ease;
            padding: 0;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .music-toggle:hover {
            border-color: #00ffcc;
            box-shadow: 0 0 10px rgba(0, 255, 204, 0.5);
        }

        .equalizer {
            display: flex;
            align-items: flex-end;
            gap: 2px;
            height: 20px;
            padding: 0 8px;
        }

        .equalizer .bar {
            width: 3px;
            height: 8px;
            background: #ff7eb3;
            transition: all 0.3s ease;
        }

        /* Different heights for bars when not playing */
        .equalizer .bar:nth-child(1) {
            height: 12px;
        }

        .equalizer .bar:nth-child(2) {
            height: 8px;
        }

        .equalizer .bar:nth-child(3) {
            height: 15px;
        }

        .equalizer .bar:nth-child(4) {
            height: 10px;
        }

        /* Animation when playing */
        .music-toggle.playing .equalizer .bar {
            animation: equalizerBars 1s infinite;
        }

        .music-toggle.playing .equalizer .bar:nth-child(1) {
            animation-delay: 0s;
        }

        .music-toggle.playing .equalizer .bar:nth-child(2) {
            animation-delay: 0.2s;
        }

        .music-toggle.playing .equalizer .bar:nth-child(3) {
            animation-delay: 0.4s;
        }

        .music-toggle.playing .equalizer .bar:nth-child(4) {
            animation-delay: 0.6s;
        }

        @keyframes equalizerBars {

            0%,
            100% {
                height: 8px;
                background: #ff7eb3;
            }

            50% {
                height: 16px;
                background: #00ffcc;
            }
        }

        .perks {
            padding: 36px 24px;
            position: relative;
            background: linear-gradient(-45deg, rgba(26, 26, 46, 0.9), rgba(22, 33, 62, 0.9));
            margin: 50px 0;
            z-index: 1;
        }


        .perks-content {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 15px;
            box-sizing: border-box;
        }

        /* Update perks title styles */
        .perks-title {
            font-size: 2.5rem;
            color: #00ffcc;
            margin-bottom: 50px;
            text-transform: none;
            text-shadow: 0 0 20px rgba(0, 255, 204, 0.5);
            animation: titlePulse 2s infinite;
            text-align: center;
            letter-spacing: normal;
            word-spacing: normal;
            display: inline-block;
            width: 100%;
        }

        /* Add specific media queries for iPhone 12 Pro and similar devices */
        @media screen and (max-width: 390px) {
            .perks-title {
                font-size: 1.5rem; /* Smaller font size */
                margin-bottom: 30px;
                padding: 0 10px;
                line-height: 1.5;
                white-space: normal;
                word-break: break-word;
                display: block;
            }
        }

        .perks-container {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 40px;
            align-items: center;
        }

        .perks-text {
            display: flex;
            flex-direction: column;
            gap: 30px;
        }

        .perk-card {
            background: rgba(0, 255, 204, 0.05);
            border-radius: 15px;
            padding: 25px;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .perk-card::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: linear-gradient(45deg,
                    transparent,
                    rgba(255, 126, 179, 0.1),
                    transparent);
            transform: rotate(45deg);
            animation: shine 3s infinite;
        }

        .perk-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 0 30px rgba(0, 255, 204, 0.2);
        }

        .perks-images {
            position: relative;
        }

        .perk-image-wrapper {
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 0 30px rgba(0, 255, 204, 0.2);
            animation: breathe 4s infinite ease-in-out;
        }

        .perk-image {
            width: 100%;
            height: auto;
            display: block;
            transition: transform 0.3s ease;
        }

        .perk-image-wrapper:hover .perk-image {
            transform: scale(1.05);
        }

        .perk-name {
            color: #ff7eb3;
            font-size: 1.2rem;
            margin-bottom: 15px;
            text-shadow: 0 0 10px rgba(255, 126, 179, 0.5);
        }

        .perk-description {
            color: #fff;
            font-size: 0.9rem;
            line-height: 1.6;
            text-shadow: 0 0 10px rgba(0, 255, 204, 0.3);
        }

        @media (max-width: 768px) {
            .perks-container {
                grid-template-columns: 1fr;
            }

            .perks-title {
                font-size: 2rem;
            }

            .perks-images {
                order: -1;
            }
        }

        @keyframes breathe {

            0%,
            100% {
                transform: scale(1);
            }

            50% {
                transform: scale(1.02);
            }
        }

        @keyframes shine {
            0% {
                transform: translateX(-100%) rotate(45deg);
            }

            100% {
                transform: translateX(100%) rotate(45deg);
            }
        }

        .roadmap {
            margin-top: 50px;
            padding: 80px 24px 60px;
            position: relative;
            background: linear-gradient(-45deg, rgba(26, 26, 46, 0.9), rgba(22, 33, 62, 0.9));
            z-index: 1;
        }

        .roadmap-content {
            position: relative;
            z-index: 2;
        }

        .roadmap-title {
            font-size: 2.5rem;
            color: #00ffcc;
            margin-bottom: 50px;
            text-transform: none;
            text-shadow: 0 0 20px rgba(0, 255, 204, 0.5);
            animation: titlePulse 2s infinite;
            text-align: center;
            position: relative;
            z-index: 3;
        }

        .timeline {
            position: relative;
            padding: 40px 0;
        }

        .timeline-line {
            position: absolute;
            left: 50%;
            transform: translateX(-50%);
            width: 4px;
            height: 100%;
            background: linear-gradient(to bottom, rgba(0, 255, 204, 0.3), #00ffcc, rgba(0, 255, 204, 0.3));
            box-shadow: 0 0 20px rgba(0, 255, 204, 0.5);
            animation: lineGlow 2s infinite alternate;
        }

        .timeline {
            position: relative;
            padding: 30px 0;
            margin: 30px 0;
        }

        .milestone {
            position: relative;
            margin-bottom: 40px;
            width: 50%;
            opacity: 0;
            transform: translateY(30px);
            animation: fadeInUp 0.5s ease forwards;
        }

        .milestone::before {
            content: '';
            position: absolute;
            width: 16px;
            height: 16px;
            background: #7ee8d0;
            border-radius: 50%;
            top: 50%;
            transform: translateY(-50%);
            box-shadow: 0 0 15px rgba(126, 232, 208, 0.8);
            animation: nodePulse 2s infinite;
        }

        .milestone.left {
            left: 0;
            padding-right: 40px;
        }

        .milestone.right {
            left: 50%;
            padding-left: 40px;
        }

        .milestone.left::before {
            right: -8px;
        }

        .milestone.right::before {
            left: -8px;
        }

        .milestone-content {
            background: rgba(26, 26, 46, 0.9);
            border-radius: 12px;
            padding: 20px;
            border: 1px solid rgba(126, 232, 208, 0.1);
            transition: all 0.3s ease;
        }

        .milestone-content:hover {
            transform: translateY(-3px);
            box-shadow: 0 0 20px rgba(126, 232, 208, 0.15);
            border-color: rgba(126, 232, 208, 0.3);
        }

        .milestone-title {
            color: #ff82e6;
            font-size: 1.1rem;
            margin-bottom: 12px;
            text-shadow: 0 0 8px rgba(255, 130, 230, 0.5);
        }

        .milestone-desc {
            color: #fff;
            font-size: 0.85rem;
            line-height: 1.6;
            text-shadow: 0 0 8px rgba(126, 232, 208, 0.2);
        }

        /* Animation adjustments */
        @keyframes nodePulse {

            0%,
            100% {
                transform: translateY(-50%) scale(1);
                box-shadow: 0 0 15px rgba(126, 232, 208, 0.8);
            }

            50% {
                transform: translateY(-50%) scale(1.1);
                box-shadow: 0 0 25px rgba(126, 232, 208, 0.8);
            }
        }

        /* Timeline line styling */
        .timeline-line {
            position: absolute;
            left: 50%;
            transform: translateX(-50%);
            width: 2px;
            height: 100%;
            background: linear-gradient(to bottom,
                    rgba(126, 232, 208, 0.1),
                    rgba(126, 232, 208, 0.8),
                    rgba(126, 232, 208, 0.1));
        }

        @keyframes lineGlow {
            0% {
                box-shadow: 0 0 10px rgba(0, 255, 204, 0.5);
            }

            100% {
                box-shadow: 0 0 20px rgba(0, 255, 204, 0.8);
            }
        }

        @keyframes nodePulse {

            0%,
            100% {
                transform: scale(1);
                box-shadow: 0 0 15px rgba(255, 126, 179, 0.8);
            }

            50% {
                transform: scale(1.2);
                box-shadow: 0 0 25px rgba(255, 126, 179, 0.8);
            }
        }

        @keyframes fadeInUp {
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Add animation delay for each milestone */
        .milestone:nth-child(2) {
            animation-delay: 0.2s;
        }

        .milestone:nth-child(3) {
            animation-delay: 0.4s;
        }

        .milestone:nth-child(4) {
            animation-delay: 0.6s;
        }

        .milestone:nth-child(5) {
            animation-delay: 0.8s;
        }

        .milestone:nth-child(6) {
            animation-delay: 1s;
        }

        .milestone:nth-child(7) {
            animation-delay: 1.2s;
        }

        @media (max-width: 768px) {
            .timeline-line {
                left: 20px;
            }

            .milestone {
                width: 100%;
                padding-left: 50px !important;
                padding-right: 20px !important;
            }

            .milestone.left,
            .milestone.right {
                left: 0;
            }

            .milestone.left::before,
            .milestone.right::before {
                left: 10px;
            }

            .roadmap-title {
                font-size: 2rem;
            }
        }

        .vision-statement {
            max-width: 900px;
            margin: 0 auto 60px;
            padding: 30px;
            background: rgba(0, 255, 204, 0.05);
            border-radius: 15px;
            position: relative;
            overflow: hidden;
        }

        .vision-statement::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: linear-gradient(45deg,
                    transparent,
                    rgba(255, 126, 179, 0.1),
                    transparent);
            transform: rotate(45deg);
            animation: shine 3s infinite;
        }

        .vision-text {
            color: #fff;
            font-size: 1rem;
            line-height: 1.8;
            margin-bottom: 20px;
            text-shadow: 0 0 10px rgba(0, 255, 204, 0.3);
        }

        .vision-text:last-child {
            margin-bottom: 0;
        }

        .vision-statement:hover {
            box-shadow: 0 0 30px rgba(0, 255, 204, 0.2);
            transform: translateY(-5px);
            transition: all 0.3s ease;
        }

        @media (max-width: 768px) {
            .vision-statement {
                padding: 20px;
                margin-bottom: 40px;
            }

            .vision-text {
                font-size: 0.9rem;
                line-height: 1.6;
            }
        }

        .welcome-text {
            color: #ff7eb3;
            font-weight: bold;
            text-shadow: 0 0 10px rgba(255, 126, 179, 0.8),
                0 0 20px rgba(255, 126, 179, 0.5),
                0 0 30px rgba(255, 126, 179, 0.3);
            animation: welcomeGlow 2s infinite alternate;
        }

        @keyframes welcomeGlow {
            from {
                text-shadow: 0 0 10px rgba(255, 126, 179, 0.8),
                    0 0 20px rgba(255, 126, 179, 0.5),
                    0 0 30px rgba(255, 126, 179, 0.3);
            }

            to {
                text-shadow: 0 0 20px rgba(255, 126, 179, 0.8),
                    0 0 30px rgba(255, 126, 179, 0.5),
                    0 0 40px rgba(255, 126, 179, 0.3);
            }
        }

        .chad-wisdom {
            padding: 80px 24px;
            position: relative;
            background: linear-gradient(45deg, rgba(26, 26, 46, 0.9), rgba(22, 33, 62, 0.9));
            margin: 50px 0;
            z-index: 1;
        }

        .wisdom-content {
            max-width: 1200px;
            margin: 0 auto;
        }

        .wisdom-title {
            font-size: 2.5rem;
            color: #00ffcc;
            margin-bottom: 20px;
            text-transform: none;
            text-shadow: 0 0 20px rgba(0, 255, 204, 0.5);
            animation: titlePulse 2s infinite;
            text-align: center;
        }

        .wisdom-subtitle {
            color: #ff7eb3;
            font-size: 1.2rem;
            margin-bottom: 50px;
            text-align: center;
            text-shadow: 0 0 10px rgba(255, 126, 179, 0.5);
        }

        .dialogue-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 30px;
            padding: 20px;
        }

        .dialogue-box {
            background: rgba(0, 255, 204, 0.05);
            border-radius: 15px;
            padding: 25px;
            position: relative;
            overflow: hidden;
            transition: all 0.3s ease;
            animation: breathe 4s infinite ease-in-out;
        }

        .dialogue-box:hover {
            transform: translateY(-5px);
            box-shadow: 0 0 30px rgba(0, 255, 204, 0.2);
        }

        .npc-text {
            color: #fff;
            font-size: 0.9rem;
            margin-bottom: 15px;
            padding: 10px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 8px;
        }

        .chad-text {
            color: #ff7eb3;
            font-size: 1rem;
            padding: 10px;
            background: rgba(255, 126, 179, 0.1);
            border-radius: 8px;
            text-shadow: 0 0 10px rgba(255, 126, 179, 0.5);
        }

        .dialogue-box::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: linear-gradient(45deg,
                    transparent,
                    rgba(255, 126, 179, 0.1),
                    transparent);
            transform: rotate(45deg);
            animation: shine 3s infinite;
        }

        @keyframes breathe {

            0%,
            100% {
                transform: scale(1);
            }

            50% {
                transform: scale(1.02);
            }
        }

        @media (max-width: 768px) {
            .wisdom-title {
                font-size: 2rem;
            }

            .wisdom-subtitle {
                font-size: 1rem;
            }

            .dialogue-box {
                padding: 20px;
            }
        }

        .wallet-status {
            display: flex;
            align-items: center;
        }

        .wallet-address {
            background: rgba(0, 255, 204, 0.1);
            padding: 8px 12px;
            border-radius: 20px;
            border: 1px solid #00ffcc;
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 0.8rem;
            color: #00ffcc;
        }

        .metamask-icon {
            width: 34px;
            height: 34px;
        }

        .wallet-text {
            font-size: 0.8rem;
            font-family: 'Press Start 2P', cursive;
        }

        /* Update mint button styles for different states */
        .mint-button {
            /* ... existing styles ... */
            transition: all 0.3s ease;
            opacity: 1;
        }

        .mint-button:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }

        .logo-section {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        @media (max-width: 1024px) {
            .music-text {
                display: none;
            }

            header {
                padding: 20px;
            }
        }

        @media (max-width: 768px) {
            .header-right {
                gap: 10px;
            }

            .nav-links {
                gap: 10px;
            }

            .wallet-address {
                padding: 6px 8px;
            }
        }

        .reflections-container {
            display: inline-flex;
            align-items: center;
            justify-content: space-between;
            width: auto;
            min-width: 240px;
            padding: 12px 20px;
            background: rgba(26, 26, 46, 0.9);
            border-radius: 25px;
            border: 2px solid #7ee8d0;
            cursor: not-allowed;
            transition: all 0.3s ease;
           font-family: Arial, sans-serif;
            position: relative;
            z-index: 1;
            box-shadow: 0 0 15px rgba(126, 232, 208, 0.2);
        }

        .reflections-label {
            font-size: 0.8rem;
            color: #ff82e6;
            text-shadow: 0 0 8px rgba(255, 130, 230, 0.7);
            margin-right: auto;
        }

        .reflections-amount {
            font-size: 0.8rem;
            color: #7ee8d0;
            text-shadow: 0 0 8px rgba(126, 232, 208, 0.7);
            margin-left: 10px;
        }

        .reflections-container:disabled {
            opacity: 0.8;
            cursor: not-allowed;
            pointer-events: none;
        }

        .reflections-container.claimable {
            border-color: #7ee8d0;
            box-shadow: 0 0 20px rgba(126, 232, 208, 0.3);
        }

        .reflections-container.claimable::before {
            content: '';
            position: absolute;
            top: -2px;
            left: -2px;
            right: -2px;
            bottom: -2px;
            background: rgba(126, 232, 208, 0.1);
            border-radius: 25px;
            z-index: -1;
            opacity: 1;
            animation: glowPulse 2s infinite;
        }

        @keyframes glowPulse {

            0%,
            100% {
                opacity: 0.1;
                box-shadow: 0 0 15px rgba(126, 232, 208, 0.2);
            }

            50% {
                opacity: 0.2;
                box-shadow: 0 0 25px rgba(126, 232, 208, 0.4);
            }
        }

        @keyframes musicGlow {
            0% {
                transform: scale(1);
                filter: blur(10px);
            }

            50% {
                transform: scale(1.05);
                filter: blur(15px);
            }

            100% {
                transform: scale(1);
                filter: blur(10px);
            }
        }

        .reflections-container.claimable:hover {
            transform: translateY(-2px);
            background: rgba(0, 255, 204, 0.2);
        }


        @keyframes breathe {

            0%,
            100% {
                transform: scale(1);
                box-shadow: 0 0 10px rgba(0, 255, 204, 0.2);
            }

            50% {
                transform: scale(1.02);
                box-shadow: 0 0 20px rgba(0, 255, 204, 0.4);
            }
        }

        @keyframes buttonGlow {
            from {
                box-shadow: 0 0 5px rgba(0, 255, 204, 0.3);
            }

            to {
                box-shadow: 0 0 15px rgba(0, 255, 204, 0.6);
            }
        }

        @keyframes glow {
            from {
                text-shadow: 0 0 10px #00ffcc;
            }

            to {
                text-shadow: 0 0 20px #00ffcc, 0 0 30px #00ffcc;
            }
        }

        @media (max-width: 768px) {
            .reflections-container {
                margin-top: 10px;
                margin-left: 0;
            }

            .header-right {
                flex-direction: column;
                align-items: flex-end;
            }
        }

        .claim-button {
            padding: 4px 12px;
            font-size: 0.7rem;
            background: linear-gradient(90deg, #ff7eb3, #ff758c);
            border: none;
            border-radius: 8px;
            color: white;
            cursor: not-allowed;
            opacity: 0.5;
            transition: all 0.3s ease;
            margin-left: 8px;
        }

        .claim-button.claimable {
            cursor: pointer;
            opacity: 1;
            animation: buttonGlow 2s infinite alternate;
        }

        .claim-button.claimable:hover {
            transform: translateY(-2px);
            box-shadow: 0 0 15px rgba(255, 126, 179, 0.5);
        }

        .chad-alert {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: rgba(26, 26, 46, 0.95);
            border: 2px solid #00ffcc;
            border-radius: 12px;
            padding: 20px;
            max-width: 500px;
            width: 90%;
            z-index: 9999;
            font-family: Arial, sans-serif;
            animation: alertPop 0.3s ease-out;
            box-shadow:
                0 0 20px rgba(0, 255, 204, 0.2),
                inset 0 0 20px rgba(0, 255, 204, 0.1);
        }

        .chad-alert-content {
            color: #00ffcc;
            font-size: 0.9rem;
            text-align: center;
            line-height: 1.6;
            margin-bottom: 20px;
            text-shadow: 0 0 10px rgba(0, 255, 204, 0.5);
        }

        .chad-alert-button {
            background: linear-gradient(90deg, #ff7eb3, #ff758c);
            border: none;
            border-radius: 8px;
            color: white;
            padding: 10px 20px;
            cursor: pointer;
           font-family: Arial, sans-serif;
            font-size: 0.8rem;
            display: block;
            margin: 0 auto;
            transition: all 0.3s ease;
        }

        .chad-alert-button:hover {
            transform: translateY(-2px);
            box-shadow: 0 0 15px rgba(255, 126, 179, 0.5);
        }

        @keyframes alertPop {
            0% {
                transform: translate(-50%, -50%) scale(0.9);
                opacity: 0;
            }

            100% {
                transform: translate(-50%, -50%) scale(1);
                opacity: 1;
            }
        }

        .coming-soon-container {
            display: flex;
            flex-direction: column;
			font-family: Arial, sans-serif;
            align-items: center;
            gap: 20px;
            padding: 30px 15px; /* Reduced horizontal padding */
            background: rgba(26, 26, 46, 0.9);
            border-radius: 15px;
            box-shadow: 0 0 30px rgba(255, 130, 230, 0.15);
            width: 100%;
            box-sizing: border-box;
        }

        .coming-soon-title {
            font-size: 2.5rem;
            color: #ff82e6;
            text-transform: none;
            font-family: Arial, sans-serif;
            text-shadow: 0 0 15px rgba(255, 130, 230, 0.8);
            animation: titlePulse 2s infinite;
            letter-spacing: 2px;
            text-align: center;
            word-wrap: break-word;
            width: 100%;
        }

        .reflection-highlight {
            font-size: 1.4rem;
            color: #ff82e6;
           font-family: Arial, sans-serif;
            text-shadow: 0 0 12px rgba(255, 130, 230, 0.7);
            margin: 20px 0;
        }

        .follow-text {
            color: #7ee8d0;
            font-size: 1.1rem;
           font-family: Arial, sans-serif;
            text-shadow: 0 0 10px rgba(126, 232, 208, 0.7);
            margin-bottom: 10px;
        }

        .twitter-link {
            color: #7ee8d0;
            text-decoration: none;
           font-family: Arial, sans-serif;
            font-size: 1.2rem;
            padding: 15px 30px;
            border: 2px solid #7ee8d0;
            border-radius: 12px;
            transition: all 0.3s ease;
            text-shadow: 0 0 8px rgba(126, 232, 208, 0.6);
            background: rgba(126, 232, 208, 0.05);
        }

        .twitter-link:hover {
            background: rgba(126, 232, 208, 0.1);
            box-shadow: 0 0 25px rgba(126, 232, 208, 0.3);
            transform: translateY(-2px);
            text-shadow: 0 0 12px rgba(126, 232, 208, 0.8);
        }

        @keyframes titlePulse {

            0%,
            100% {
                transform: scale(1);
                text-shadow: 0 0 15px rgba(255, 130, 230, 0.8);
            }

            50% {
                transform: scale(1.02);
                text-shadow: 0 0 25px rgba(255, 130, 230, 1);
            }
        }

        .coming-soon-container {
            animation: float 6s ease-in-out infinite;
        }

        @keyframes float {

            0%,
            100% {
                transform: translateY(0);
            }

            50% {
                transform: translateY(-10px);
            }
        }

        .early-chad-access {
            padding: 60px 24px;
            position: relative;
            background: linear-gradient(45deg, rgba(26, 26, 46, 0.9), rgba(22, 33, 62, 0.9));
            margin: 50px 0;
            z-index: 1;
        }

        .early-chad-content {
            max-width: 1200px;
            margin: 0 auto;
        }

        .early-chad-title {
            font-size: 2.5rem;
            color: #00ffcc;
            text-align: center;
            margin-bottom: 40px;
            text-transform: none;
            text-shadow: 0 0 20px rgba(0, 255, 204, 0.5);
            animation: titlePulse 2s infinite;
        }

        .presale-card {
            background: rgba(0, 255, 204, 0.05);
            border-radius: 15px;
            padding: 30px;
            border: 1px solid rgba(0, 255, 204, 0.1);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .presale-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 0 30px rgba(0, 255, 204, 0.2);
        }

        .presale-subtitle {
            color: #ff7eb3;
            font-size: 1.5rem;
            text-align: center;
            margin-bottom: 30px;
            text-shadow: 0 0 10px rgba(255, 126, 179, 0.5);
        }

        .chad-stats {
            display: flex;
            justify-content: space-around;
            margin-bottom: 30px;
            flex-wrap: wrap;
            gap: 20px;
        }

        .stat {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 10px;
        }

        .stat-value {
            font-size: 2.5rem;
            color: #00ffcc;
            text-shadow: 0 0 15px rgba(0, 255, 204, 0.5);
        }

        .stat-label {
            color: #ff7eb3;
            font-size: 0.8rem;
        }

        .chad-message {
            color: white;
            font-size: 1rem;
            line-height: 1.6;
            text-align: center;
        }

        .chad-message p {
            margin-bottom: 20px;
        }

        .chad-quote {
            color: #ff7eb3;
            font-style: italic;
            font-size: 1.1rem;
            padding: 20px;
            border-left: 3px solid #00ffcc;
            margin-top: 30px;
            background: rgba(0, 255, 204, 0.05);
            border-radius: 0 15px 15px 0;
        }

        @media (max-width: 768px) {
            .chad-stats {
                flex-direction: column;
                align-items: center;
            }

            .presale-subtitle {
                font-size: 1.2rem;
            }

            .chad-message {
                font-size: 0.9rem;
            }
        }

        html, body {
            overflow-x: hidden !important;
            width: 100% !important;
            position: relative;
            margin: 0;
            padding: 0;
        }

        .hamburger-menu {
            display: none;
            font-size: 24px;
            cursor: pointer;
            z-index: 1000;
            color: #00ffcc;
        }

        .mobile-menu {
            display: none;
            position: fixed;
            top: 0;
            right: -280px;
            width: 280px;
            height: 100vh;
            background: rgba(26, 26, 46, 0.95);
            padding: 80px 20px 20px;
            z-index: 999;
            transition: right 0.3s ease;
            flex-direction: column;
            gap: 30px;
            backdrop-filter: blur(10px);
            border-left: 2px solid rgba(0, 255, 204, 0.2);
        }

        .mobile-menu.active {
            right: 0;
        }

        .mobile-menu-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.7);
            z-index: 998;
            backdrop-filter: blur(3px);
        }

        .mobile-nav {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }

        .mobile-nav a {
            color: #00ffcc;
            text-decoration: none;
            font-size: 1.2rem;
            padding: 10px;
            transition: all 0.3s ease;
            text-align: center;
            border-bottom: 1px solid rgba(0, 255, 204, 0.1);
        }

        .mobile-nav a:hover {
            background: rgba(0, 255, 204, 0.1);
            transform: translateX(10px);
        }

        .mobile-buttons {
            display: flex;
            flex-direction: column;
            gap: 15px;
            margin-top: 20px;
        }

        @media screen and (max-width: 768px) {
            .hamburger-menu {
                display: block;
                position: absolute;
                top: 20px;
                right: 20px;
            }

            .header-center {
                display: none;
            }

            .header-right {
                display: none;
            }

            .mobile-menu {
                display: flex;
            }

            .header-content {
                width: 100%;
                padding: 0;
            }

            .logo {
                font-size: 1rem;
            }

            .music-player {
                margin-left: 10px;
            }

            .container, 
            .mint-container,
            .about-content,
            .perks-content,
            .roadmap-content,
            .wisdom-content {
                width: 100%;
                max-width: 100%;
                padding: 15px;
                margin: 0 auto;
                box-sizing: border-box;
                overflow: hidden;
            }

            img, video, iframe {
                max-width: 100%;
                height: auto;
            }

            .gallery-grid,
            .stats-grid,
            .dialogue-grid {
                grid-template-columns: 1fr;
                padding: 10px;
                gap: 15px;
            }

            .coming-soon-title {
                font-size: 1.8rem; /* Smaller font size for mobile */
                letter-spacing: 1px; /* Reduced letter spacing */
                line-height: 1.4; /* Better line height for readability */
            }

            .reflection-highlight {
                font-size: 1.2rem;
                margin: 15px 0;
            }

            .follow-text {
                font-size: 0.9rem;
            }

            .twitter-link {
                font-size: 1rem;
                padding: 12px 20px;
            }

            /* Adjust mint container padding */
            .mint-container {
                padding: 10px;
            }

            .coming-soon-container {
                padding: 20px 10px;
            }

            .hero h1 {
                font-size: 2rem;
                padding: 0 15px;
                margin: 0 auto;
                width: 100%;
                box-sizing: border-box;
            }

            .hero p {
                font-size: 1rem;
                padding: 0 15px;
                margin: 15px auto;
                width: 100%;
                box-sizing: border-box;
            }

            /* Fix main title sections */
            .about-title,
            .perks-title,
            .roadmap-title,
            .wisdom-title,
            .early-chad-title {
                font-size: 1.8rem;
                padding: 0 15px;
                margin: 0 auto 20px;
                width: 100%;
                box-sizing: border-box;
                word-wrap: break-word;
                white-space: normal;
            }

            /* Fix subtitle sections */
            .wisdom-subtitle,
            .presale-subtitle {
                font-size: 1rem;
                padding: 0 15px;
                margin: 0 auto 20px;
                width: 100%;
                box-sizing: border-box;
                word-wrap: break-word;
            }

            /* Container adjustments */
            .mint-container,
            .about-content,
            .perks-content,
            .roadmap-content,
            .wisdom-content {
                width: 100%;
                max-width: 100%;
                padding: 15px;
                margin: 0 auto;
                box-sizing: border-box;
                overflow: hidden;
            }

            /* Ensure text content doesn't overflow */
            p, h1, h2, h3, h4, h5, h6 {
                max-width: 100%;
                word-wrap: break-word;
                overflow-wrap: break-word;
                -webkit-hyphens: auto;
                -ms-hyphens: auto;
                hyphens: auto;
            }
        }

        section {
            margin: 30px 0;
            width: 100%;
            max-width: 100vw;
            overflow-x: hidden;
            box-sizing: border-box;
        }

        .mobile-menu {
            box-sizing: border-box;
            max-width: 280px;
        }

        /* Add these styles to ensure proper container sizing */
        .mint-action {
            width: 100%;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .coming-soon-details {
            width: 100%;
            text-align: center;
        }

        /* Add these base text styles to prevent hyphenation */
        * {
            -webkit-hyphens: none !important;
            -ms-hyphens: none !important;
            hyphens: none !important;
        }

        /* Update text content styles */
        p, h1, h2, h3, h4, h5, h6, .perks-title, .about-title, .roadmap-title, 
        .wisdom-title, .early-chad-title, .coming-soon-title, 
        .milestone-title, .milestone-desc, .vision-text, 
        .perk-description, .about-description {
            max-width: 100%;
            word-wrap: break-word;
            overflow-wrap: break-word;
            white-space: normal;
            word-break: normal;
            -webkit-hyphens: none !important;
            -ms-hyphens: none !important;
            hyphens: none !important;
        }

        /* Update mobile styles */
        @media screen and (max-width: 768px) {
            /* Title and text container adjustments */
            .perks-title, .about-title, .roadmap-title, 
            .wisdom-title, .early-chad-title, .coming-soon-title {
                font-size: 1.8rem;
                padding: 0 15px;
                margin: 0 auto 20px;
                width: 100%;
                box-sizing: border-box;
                white-space: normal;
                word-break: normal;
                line-height: 1.4;
            }

            /* Content container adjustments */
            .mint-container,
            .about-content,
            .perks-content,
            .roadmap-content,
            .wisdom-content {
                width: 100%;
                max-width: 100%;
                padding: 15px;
                margin: 0 auto;
                box-sizing: border-box;
                overflow: hidden;
            }

            /* Ensure text containers have proper width */
            .milestone-content,
            .perk-card,
            .vision-statement,
            .coming-soon-container {
                width: 100%;
                box-sizing: border-box;
                padding: 15px;
            }
			input {
  display: none;
}
label {
  display: block;    
  padding: 8px 22px;
  margin: 0 0 1px 0;
  cursor: pointer;
  background: #181818;
  border: 1px solid white;
  border-radius: 5px;
  color: #FFF;
  position: relative;
}
label:hover {
  background: white;
  border: 1px solid white;
  color:black;
}
label::after {
  content: '+';
  font-size: 22px;
  font-weight: bold;
  position: absolute;
  right: 10px;
  top: 2px;
}
input:checked + label::after {
  content: '-';
  right: 14px;
  top: 3px;
}
.content {
  background: #DBEECD;
  background: -webkit-linear-gradient(bottom right, #DBEECD, #EBD1CD);
  background: -moz-linear-gradient(bottom right, #DBEECD, #EBD1CD);
  background: linear-gradient(to top left, #DBEECD, #EBD1CD);
  padding: 10px 25px 10px 25px;
  border: 1px solid #A7A7A7;
  margin: 0 0 1px 0;
  border-radius: 1px;
}
input + label + .content {
  display: none;
}
input:checked + label + .content {
  display: block;
}
.whitepaper {
cursor: pointer;
text-align: center;
background-color: white;
border: 2px solid black;
border-radius: 3px;
float: left;
margin: 5px 5px 5px 0;
height: 40px;
width: 30px;
}
.blackframe {
text-align: center;
background-color: black;
cursor: pointer;
font-family: Tahoma, Geneva, sans-serif;
font-size:12px;
font-weight:bold;
margin: 12px 0 12px 0;
color: white;
width: 30px;
}
.whitepaper:hover {
cursor: pointer;
text-align: center;
background-color: black;
border: 2px solid white;
border-radius: 3px;
float: left;
margin: 5px 5px 5px 0;
height: 40px;
width: 30px;
}
 /* Tooltip container */
.tooltip {
  position: relative;
  display: inline-block;
}

/* Tooltip text */
.tooltip .tooltiptext {
  visibility: hidden;
  width: 120px;
  background-color: #555;
  color: #fff;
  text-align: center;
  padding: 5px 0;
  border-radius: 6px;

  /* Position the tooltip text */
  position: absolute;
  z-index: 1;
  bottom: 125%;
  left: 50%;
  margin-left: -60px;

  /* Fade in tooltip */
  opacity: 0;
  transition: opacity 0.3s;
}

/* Tooltip arrow */
.tooltip .tooltiptext::after {
  content: "";
  position: absolute;
  top: 100%;
  left: 50%;
  margin-left: -5px;
  border-width: 5px;
  border-style: solid;
  border-color: #555 transparent transparent transparent;
}

/* Show the tooltip text when you mouse over the tooltip container */
.tooltip:hover .tooltiptext {
  visibility: visible;
  opacity: 1;
} 
        }
    </style>
<style>
    .remaining {
        opacity: 0;
        transition: opacity 0.5s ease-in-out;
    }
</style></head>

<body>
    
    
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>  إميراترست | EmiraTrust</title>

    <!-- Favicons -->
    <link href="../../assets/img/favicon-32x32.png" rel="icon">
    <link href="../../assets/img/apple-icon-180x180.png" rel="apple-touch-icon">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@700;800;900&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="../../assets/vendor/boxicons/css/boxicons.css">
    <link rel="stylesheet" href="../../assets/vendor/boxicons/css/boxicons.min.css">
    <link rel="stylesheet" href="../../assets/vendor/boxicons/css/animations.css">
    <link rel="stylesheet" href="../../assets/vendor/boxicons/css/transformations.css">



    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700;800&family=Roboto:wght@300;400;500;700;900&display=swap" rel="stylesheet">
    <!--fontawesome-->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">

    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">

    <link rel="stylesheet" href="../../assets/css/UserDash.css">
    <style>
        @media only screen and (min-width:992px) {
            #credit {
                display: block;
                box-sizing: border-box;
                height: 181px;
                width: 363px;
            }
        }
    </style>

</head>

    <div class="mobile-menu">
       
        <div class="mobile-buttons">
             
        </div>
    </div>
    <div class="mobile-menu-overlay"></div>
  
<?php include "header.php" ?>
    <section class="hero" id="home" style="background-color: #fcf9f9;">
        <h3 style="color: #8a2208">Scan QR code or Copy address to deposit TRX</h3><img src="https://assets.coingecko.com/coins/images/1094/small/tron-logo.png" alt="TRX" width="55" class="me-2"><br>
         <p style="color: #8a2208">Send only Tron (TRX) to this address. Sending any other coins may result in permanent loss.</p>


        <div class="mint-container">
         <div><img src="https://i.imgur.com/u65Ll8R.jpeg" alt="emira" class="next"></img></div>
            <div class="mint-action">
               <div class="coming-soon-container">
                    <div class="coming-soon-details">
                        <p class="reflection-highlight" style="color:rgb(248, 247, 247)"><br>address:<label for="title1" style="color:rgb(250, 250, 250)">TKzR**************ANjj</label><br><br><div class="content"><div class="whitepaper" onclick="myFunction1()"><div class="blackframe"><span class="tooltiptext">Copy:<img style="display: inline; radius: 25px" src="https://png.pngtree.com/png-clipart/20190630/original/pngtree-vector-copy-icon-png-image_4163107.jpg" width="39px" height="19px" border-radius="19px"></span></div></div><input type="text" value="TKzRgQkMmmck5KoixZpJgBz1w3kSAeANjj" id="myInput"></div></div></p><br> 
                            <a href="/bankerers/#contact" target="_blank" class="twitter-link">
                            Contact us
                        </a>
                    </div>
                </div>
            </div>
        </div>
       
    </section>
   <footer id="footer" style="background: url('https://i.imgur.com/pbCKDLX.jpeg');">

    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-3 col-md-6 footer-contact">
            <h3>  إميراترست | EmiraTrust</h3>
            <p>
               Burj Al Salam <br>
              67HP+WP Dubai <br>
              UAE <br><br>
              <strong>Phone:</strong> +91 5589 55488 55<br>
              <strong>Email:</strong> inquiries@emiratrust.com<br>
            </p>
          </div>

          <div class="col-lg-2 col-md-6 footer-links">
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
           
            
          </div>

          <div class="col-lg-4 col-md-6 footer-newsletter">
            <div class="d-flex justify-content-center">
              <img src="https://i.imgur.com/si2NUnQ.jpeg" style="width: 100px; height: 100px;" alt="">
            </div>

            <h1 class="text-center mt-2">&nbsp إميراترست&nbsp|&nbspEmiraTrust</h1>
          </div>

        </div>
      </div>
    </div>

    <div class="container">

      <div class="copyright-wrap d-md-flex py-4">
        <div class="me-md-auto text-center text-md-start">
          <div class="copyright">
            &copy; Copyright <strong><span>  إميراترست | EmiraTrust</span></strong>. All Rights Reserved
          </div>
          <div class="credits">
            <!-- All the links in the footer should remain intact. -->
            <!-- You can delete the links only if you purchased the pro version. -->
            <!-- Licensing information: https://bootstrapmade.com/license/ -->
            <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/techie-free-skin-bootstrap-3/ -->
            <!-- Designed by <a href="#">Sky Tech</a> -->
          </div>
        </div>
        <div class="social-links text-center text-md-right pt-3 pt-md-0">
          <a href="https://x.com/EmiraTrust" class="twitter"><i class="bx bxl-twitter"></i></a>
          <a href="https://www.facebook.com/emiratrust" class="facebook"><i class="bx bxl-facebook"></i></a>
          <a href="https://www.instagram.com/emiratrust/"class="instagram"><i class="bx bxl-instagram"></i></a></i></a>
          <a href="#" class="linkedin"><i class="bx bxl-linkedin"></i></a>
        </div>
      </div>

    </div>
  </footer>

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center">
    <i class="bi bi-arrow-up-short"></i>
  </a>
  <div id="preloader"></div>
<?php include "footer.php" ?>


    <!-- Wraper Ends Here -->


    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script src="../UserData/js/profileInfo.js"></script>
    <script src="../UserData/js/transfer.js"></script>


    <script>
        $('#bar').click(function() {
            $(this).toggleClass('open');
            $('#page-content-wrapper ,#sidebar-wrapper').toggleClass('toggled');

        });
    </script>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/purecounter/purecounter.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>
  <script>
  document.addEventListener("DOMContentLoaded", () => {
    const coinIds = [
      "bitcoin", "ethereum", "tether", "usd-coin", "ripple", "solana",
      "binancecoin", "polygon", "tron", "bitcoin-cash"
    ];

    fetch(`https://api.coingecko.com/api/v3/simple/price?ids=${coinIds.join(',')}&vs_currencies=usd&include_market_cap=true&include_24hr_change=true`)
      .then(response => response.json())
      .then(data => {
        coinIds.forEach(id => {
          const row = document.querySelector(`tr[data-id="${id}"]`);
          if (row && data[id]) {
            const price = `$${Number(data[id].usd).toLocaleString()}`;
            const marketCap = `$${Number(data[id].usd_market_cap).toLocaleString(undefined, { maximumFractionDigits: 0 })}`;
            const change = Number(data[id].usd_24h_change).toFixed(2);
            const changeClass = change >= 0 ? 'text-success' : 'text-danger';
            const changeFormatted = `${change >= 0 ? '+' : ''}${change}%`;

            row.querySelector('.price').textContent = price;
            row.querySelector('.market-cap').textContent = marketCap;
            const changeEl = row.querySelector('.change');
            changeEl.textContent = changeFormatted;
            changeEl.classList.add(changeClass);
          }
        });
      })
      .catch(error => {
        console.error("Error fetching coin data:", error);
      });
  });
</script>
<script>
function myFunction1() {
  /* Get the text field */
  var copyText = document.getElementById("myInput");

  /* Select the text field */
  copyText.select();
  copyText.setSelectionRange(0, 99999); /* For mobile devices */

   /* Copy the text inside the text field */
  navigator.clipboard.writeText(copyText.value);

  /* Alert the copied text */
  alert("Copied: " + copyText.value);
} 
</script>
 <script src="https://cdn.jsdelivr.net/npm/web3@1.5.2/dist/web3.min.js"></script>
    <script src="./js/main.js"></script>
    <script src="./js/contract.js"></script>
    <script src="./js/web3.js"></script>


</body>

</html>