<?php
header('Content-Type: application/json');
ini_set('display_errors', 0);
error_reporting(E_ALL);
include "../connection.php";
session_start();

$AcNo = $_SESSION['AccountNo'];

function getAEDtoUSDExchangeRate() {
    // Dummy fixed rate or replace with live API integration
    return 3.67; // 1 USD = 3.67 AED (Example rate)
}

if (isset($_POST['action']) && $_POST['action'] === 'ach_wire_transfer') {
    $sender_name = $_POST['sender_name'];
    $sender_account_number = $_POST['sender_account_number'];
    $routing_number = $_POST['routingNumber'];
    $bank_name = $_POST['bankName'];
    $account_type = $_POST['account_type'];
    $street_name = $_POST['streetname'];
    $street_number = $_POST['streetnumber'];
    $apartment = $_POST['apartment'];
    $floor = $_POST['floor'];
    $postal_code = $_POST['postal_code'];
    $country = $_POST['country'];
    $city = $_POST['city'];
    $province = $_POST['province'];
    $organization_name = $_POST['organization_name'];
    $amount = floatval($_POST['amount']);
    $recipient_account_number = $_POST['recipient_account_number'];
    $currency = $_POST['currency']; // "USD" or "AED"

    // Step 1: Determine transfer limit in selected currency
    $minTransferLimitUSD = 10000000; // 10 million USD

    if ($currency === "USD") {
        $minTransferLimit = $minTransferLimitUSD;
    } elseif ($currency === "AED") {
        $rate = getAEDtoUSDExchangeRate();
        if ($rate === null) {
            echo json_encode([
                "status" => "error",
                "message" => "Unable to retrieve exchange rate. Please try again later."
            ]);
            exit;
        }
        $minTransferLimit = $minTransferLimitUSD / $rate; // Convert USD to AED equivalent
    } else {
        echo json_encode([
            "status" => "error",
            "message" => "Unsupported currency provided."
        ]);
        exit;
    }

    if ($amount < $minTransferLimit) {
        echo json_encode([
            "status" => "error",
            "message" => "Transaction failed. The transfer amount must be at least $minTransferLimit $currency."
        ]);
        exit;
    }

    // Step 2: Validate sender account and balance
    $stmt = $conn->prepare("
        SELECT * FROM customer_detail 
        JOIN login ON customer_detail.Account_No = login.AccountNo 
        JOIN accounts ON accounts.AccountNo = login.AccountNo 
        WHERE customer_detail.Account_No = ?
    ");
    $stmt->bind_param("s", $sender_account_number);
    $stmt->execute();
    $senderResult = $stmt->get_result();

    if ($senderResult->num_rows === 0) {
        echo json_encode(["status" => "error", "message" => "Sender account not found"]);
        exit;
    }

    $sender = $senderResult->fetch_assoc();
    $SBalance = $sender['Balance'];
    $SStatus = $sender['Status'];
    $SName = $sender['C_First_Name'] . " " . $sender['C_Last_Name'];
    $SProColor = $sender['ProfileColor'];
    $ProfileImage = $sender['ProfileImage'];

    if ($SStatus !== "Active") {
        echo json_encode(["status" => "error", "message" => "Sender account is not active"]);
        exit;
    }

    if (empty($ProfileImage) || strtolower($ProfileImage) === 'null') {
        echo json_encode(["status" => "error", "message" => "Transaction failed. Please upload your profile picture first."]);
        exit;
    }

    if ($SBalance < $amount) {
        echo json_encode(["status" => "error", "message" => "Transaction failed. Not sufficient balance!"]);
        exit;
    }

    mysqli_begin_transaction($conn);
    try {
        // Insert into achwire_transfers_org
        $stmt = $conn->prepare("
            INSERT INTO achwire_transfers_org (
                sender_name, sender_account_number, routing_number, bank_name, account_type,
                street_name, street_number, apartment, floor, postal_code, country, city, province,
                organization_name, amount, recipient_account_number, currency
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->bind_param("ssssssssssssssdds",
            $sender_name, $sender_account_number, $routing_number, $bank_name, $account_type,
            $street_name, $street_number, $apartment, $floor, $postal_code, $country, $city, $province,
            $organization_name, $amount, $recipient_account_number, $currency
        );
        $stmt->execute();

        // Update sender's balance
        $newBalance = $SBalance - $amount;
        $stmt = $conn->prepare("UPDATE accounts SET Balance = ? WHERE AccountNo = ?");
        $stmt->bind_param("ds", $newBalance, $sender_account_number);
        $stmt->execute();

        // Insert into transaction table
        $debitAmount = '-' . $amount;
        $stmt = $conn->prepare("
            INSERT INTO transaction (AccountNo, FAccountNo, Name, Amount, Status, ProfileColor, Credit, Debit, Currency)
            VALUES (?, ?, ?, ?, 'Pending', ?, '0.0', ?, ?)
        ");
        $stmt->bind_param("ssssdsd", $sender_account_number, $recipient_account_number, $organization_name, $debitAmount, $SProColor, $amount, $currency);
        $stmt->execute();

        mysqli_commit($conn);
        echo json_encode(["status" => "success", "message" => "ACH wire transfer submitted successfully"]);
        exit;
    } catch (Exception $e) {
        mysqli_rollback($conn);
        echo json_encode(["status" => "error", "message" => "Transaction failed. Please try again."]);
        exit;
    }
} else {
    echo json_encode(["status" => "error", "message" => "Invalid request"]);
    exit;
}
?>
