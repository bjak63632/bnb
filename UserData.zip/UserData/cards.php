<?php
include "../connection.php";

session_start();

if (!isset($_SESSION['username'])) {
    header("Location: ../login.php");
}
$username = $_SESSION['username'];
$AccountNo = $_SESSION['AccountNo'];
?>

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Cards   إميراترست | EmiraTrust</title>
    <!-- Favicons -->
    <link href="../../assets/img/favicon-32x32.png" rel="icon">
    <link href="../../assets/img/apple-icon-180x180.png" rel="apple-touch-icon">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../../assets/vendor/boxicons/css/boxicons.css">
    <link rel="stylesheet" href="../../assets/vendor/boxicons/css/boxicons.min.css">
    <link rel="stylesheet" href="../../assets/vendor/boxicons/css/animations.css">
    <link rel="stylesheet" href="../../assets/vendor/boxicons/css/transformations.css">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700;800&family=Roboto:wght@300;400;500;700;900&display=swap" rel="stylesheet">
    <!--fontawesome-->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined" rel="stylesheet">
    <link rel="stylesheet" href="../../assets/css/UserDash.css">
    <link rel="stylesheet" href="../UserData/css/cards.css">
    <style type="text/css">
footer {
    background-color: #5702f500;
}
</style>
</head>

<body>
    <?php include "header.php" ?>
    <!-- End of Topbar -->

    <!-- Begin Page Content -->
    <div class=" begin container-fluid px-lg-4">
        <div class="row">
            <div class="col-md-12 mt-4">
                <div class="d-sm-flex align-items-center justify-content-between mb-4">
                    <h1 class="h3 mb-0 text-gray-800">Cards</h1>
                    <!-- <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i>
                        Generate Report</a> -->
                </div>
            </div>
        </div>
        <?php
        $query = "SELECT * FROM cards WHERE AccountNo = '$AccountNo' ";
        $result = mysqli_query($conn, $query) or die(mysqli_error($conn));
        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                $Status = $row['Status'];
                $Verified = $row['Verified'];
                $DebitCardNo = $row['CardNo'];
                $Name = $row['Name'];
                $IssuDate = $row['IssuedDate'];
                $ExpiryDate = $row['ExpiryDate'];
                $cvv = $row['cvv'];
            }

            if ($Verified == "No") { ?>
                <div class="row mt-2 d-flex justify-content-center">
                    <div class="col-sm-8">
                        <div class="card">
                            <div class="d-flex justify-content-center">
                                <div class="noProfile" id="ProfileTag">
                                    <h2 class="nameTag" id="NameTag"></h2>
                                </div>
                            </div>
                            <div class="card-body">
                                <h1 class="text-center mb-4 text-success">Your application sent successfully</h1>
                                <p class="card-text pl-2 pr-2" style="text-transform: none">Dear   <?php echo $Name ?>, </p>
                                <p class="card-text pl-2 pr-2"> &emsp;You have successfully sent your debit card application to the bank. Your virtual debit card verification is in progress. The physical debit card will be available within two to three days. </p>
                                <p class="card-text pl-2 pr-2">Thank You, </p>
                                <p class="card-text mb-4 pl-2 pr-2">  إميراترست | EmiraTrust</p>
                            </div>
                        </div>
                    </div>
                </div>
            <?php
            } elseif ($Status == "Active") { ?>

                <div class="row mt-2">
                    <div class="col-sm-6">
                        <div class="card">
                            <div class="d-flex justify-content-center">
                                <div class="noProfile" id="ProfileTag">
                                    <h2 class="nameTag" id="NameTag"></h2>
                                </div>
                            </div>
                            <!-- Debit Card Body -->
                            <div class="card-body">
                                <h1 class="text-center">Your Debit Card</h1>
                                <div class="flip-card">
                                    <div class="flip-card-inner">
                                        <div class="flip-card-front">
                                            <div class="row mt-4 mb-4 d-flex justify-content-center">
                                                <div id="debitCard-col" class="col-sm-8 mt-4 ">
                                                    <div class="card dcard-back">
                                                        <div class="card-body">
                                                            <div class="d-flex justify-content-between">
                                                                <h5 class="text-light"> إميراترست | EmiraTrust</h5>
                                                            </div>
                                                            <div class="mt-2 mb-2  d-flex justify-content-start">
                                                                <img src="../UserData/assets/img/gold-card-chip.png" alt="">
                                                            </div>
                                                            <div class=" d-flex justify-content-start">
                                                                <h5 hidden id="DebitcardNo" class="text-light"><?php echo $DebitCardNo ?></h5>
                                                                <h4 id="NewDebitNo" class="text-light" style="font-family: 'Courier New', Courier, monospace;"></h4>
                                                            </div>
                                                            <div class="d-flex justify-content-between mt-3">
                                                                <h6 class="text-light" style="font-family: 'Courier New', Courier, monospace; text-transform: none"><?php echo $Name ?><br><?php echo $AccountNo ?></h6>
                                                                <h6 class="text-light" style="font-family: 'Courier New', Courier, monospace;">Exp <?php echo $ExpiryDate ?></h6>
                                                                <h5 class="text-light visa">Visa</h5>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="flip-card-back">
                                            <div id="debitCard-col" class="col-sm-8 mt-4 ">
                                                <div id="OnCardToggle" class="card dcard-back">
                                                    <div class="card-body" style="padding: 0px;">
                                                        <div style="padding-top: 10px;">
                                                            <p class="text-light dback-tittle">for customer service call +91 1940 88 7655</p>
                                                        </div>
                                                        <div class="strip">
                                                        </div>
                                                        <div>
                                                            <div class="strip2">
                                                                <p style="text-align: end; color:black; padding:4px"><?php echo $cvv ?></p>
                                                            </div>
                                                            <p class="description">This card issued by   إميراترست | EmiraTrust Bank pursuant to a license from Visa UAE,
                                                                Inc. Use ofthis card is subject to the agreement, as amended, This card isthe property ofthe issuer and must
                                                                be returned upon request and may be revoked without notice.</p>
                                                        </div>
                                                        <div class=" d-flex justify-content-start">
                                                            <h4 id="NewDebitNo" class="text-light" style="font-family: 'Courier New', Courier, monospace;"></h4>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- Debit Card Details -->
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="card">
                            <div class="card-body">
                                <h1 class="text-center mb-4 ">Your Debit Card Details</h1>
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <p>Account Number</p>
                                        <p>Debit Card Number</p>
                                        <p>Name</p>
                                        <p>CVV Number</p>
                                        <p>Issued Date</p>
                                        <p>Expiry Date</p>
                                        <p>Card Status</p>
                                        <p>Verification Status</p>
                                    </div>

                                    <div>
                                        <p>:</p>
                                        <p>:</p>
                                        <p>:</p>
                                        <p>:</p>
                                        <p>:</p>
                                        <p>:</p>
                                        <p>:</p>
                                        <p>:</p>
                                    </div>

                                    <div>
                                        <p><?php echo $AccountNo ?></p>
                                        <p><?php echo $DebitCardNo ?></p>
                                        <p><?php echo $Name ?></p>
                                        <p><?php echo $cvv ?></p>
                                        <p><?php echo $IssuDate ?></p>
                                        <p><?php echo $ExpiryDate ?></p>
                                        <p><?php echo $Status ?></p>
                                        <p><?php echo $Verified ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php
            } elseif ($Status == "Inactive") { ?>
                <h5 class="text-danger text-center text-size-10">Your Debit Card is Deactivated Please Call Bank To activate</h5>
            <?php }
        } else { ?>
            <div class="row mt-2 d-flex justify-content-center">
                <div class="col-sm-8">
                    <div class="card">
                        <div class="d-flex justify-content-center">
                            <div class="noProfile" id="ProfileTag">
                                <h2 class="nameTag" id="NameTag"></h2>
                            </div>
                        </div>
                        <div class="card-body">
                            <h1 class="text-center mb-4">Apply for Credit/debit card</h1>
                            <p class="card-text mb-4 p-2">EmiraTrust Bank Credit and Debit Cards are designed for seamless, secure transactions - whether you're shopping online, in-store, or abroad.
                                                   We offer both Mastercard and Visa options to give you global access and flexibility, with support for contactless payments, e-commerce, and in-person purchases across the UAE and around the world..</p>
                            <div class="d-flex justify-content-center">
                                <button type="button" id="SendAppBtn" class="btn btn-outline-primary mb-2">Send Application</button>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        <?php }
        mysqli_close($conn);
        ?>
    </div>
    </div>
    <!-- End of Page Content -->
    <?php include "footer.php" ?>
    <!-- Wraper Ends Here -->
    </div>
    <!-- ======= Footer ======= -->
  <footer id="footer" style="background: url('https://i.imgur.com/pbCKDLX.jpeg');">
    <div class="footer-top">
      <div class="container">
        <div class="row">
          <div class="col-lg-3 col-md-6 footer-contact">
            <h3>  إميراترست | EmiraTrust</h3>
            <p>
               Burj Al Salam <br>
              67HP+WP Dubai <br>
              UAE <br><br>
              <strong>Phone:</strong> +91 5589 55488 55<br>
              <strong>Email:</strong> inquiries@emiratrust.com<br>
            </p>
          </div>
          <div class="col-lg-2 col-md-6 footer-links">
          </div>
          <div class="col-lg-3 col-md-6 footer-links">
          </div>
          <div class="col-lg-4 col-md-6 footer-newsletter">
            <div class="d-flex justify-content-center">
              <img src="https://i.imgur.com/si2NUnQ.jpeg" style="width: 100px; height: 100px;" alt="">
            </div>
            <h1 class="text-center mt-2">&nbsp إميراترست&nbsp|&nbspEmiraTrust</h1>
          </div>
        </div>
      </div>
    </div>

    <div class="container">
      <div class="copyright-wrap d-md-flex py-4">
        <div class="me-md-auto text-center text-md-start">
          <div class="copyright">
            &copy; Copyright <strong><span>  إميراترست | EmiraTrust</span></strong>. All Rights Reserved
          </div>
          <div class="credits">
            <!-- All the links in the footer should remain intact. -->
            <!-- You can delete the links only if you purchased the pro version. -->
            <!-- Licensing information: https://bootstrapmade.com/license/ -->
            <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/techie-free-skin-bootstrap-3/ -->
            <!-- Designed by <a href="#">Sky Tech</a> -->
          </div>
        </div>
        <div class="social-links text-center text-md-right pt-3 pt-md-0">
          <a href="https://x.com/EmiraTrust" class="twitter"><i class="bx bxl-twitter"></i></a>
          <a href="https://www.facebook.com/emiratrust" class="facebook"><i class="bx bxl-facebook"></i></a>
          <a href="https://www.instagram.com/emiratrust/"class="instagram"><i class="bx bxl-instagram"></i></a></i></a>
          <a href="#" class="linkedin"><i class="bx bxl-linkedin"></i></a>
        </div>
      </div>
    </div>
  </footer>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="../UserData/js/profileInfo.js"></script>
    <script src="../UserData/js/cards.js"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        $('#bar').click(function() {
            $(this).toggleClass('open');
            $('#page-content-wrapper ,#sidebar-wrapper').toggleClass('toggled');
            $("#debitCard-col").toggleClass("col-sm-10");
            $("#OnCardToggle").toggleClass("onfip-posion-toogle");

        });

        $("#Cards").addClass("active");

        $("#bankBrand").addClass("mt-4");

        $("#close").click(function(e) {

            $("#EditProfileModal").modal('hide');
            e.preventDefault();

        });
    </script>

    <script>
        if (window.history.replaceState) {
            window.history.replaceState(null, null, window.location.href);
        }
    </script>
</body>
</html>