<?php
header('Content-Type: application/json');
ini_set('display_errors', 0);
error_reporting(E_ALL);
include "../connection.php";
include "../mail/TransactionMail.php";
session_start();

$username = $_SESSION['username'];
$AcNo = $_SESSION['AccountNo'];

function getAEDtoUSDExchangeRate() {
    // Use any reliable exchange rate API
    $url = "https://open.er-api.com/v6/latest/AED"; // Sample free API (replace if needed)
    $response = file_get_contents($url);
    if ($response !== false) {
        $data = json_decode($response, true);
        if (isset($data['rates']['USD'])) {
            return floatval($data['rates']['USD']);
        }
    }
    return null; // fallback
}

if (isset($_POST['action']) && $_POST['action'] === 'wire_transfer') {
    $username = $_POST['username'];
    $sender_name = $_POST['sender_name'];
    $sender_account_number = $_POST['sender_account_number'];
    $sender_address = $_POST['sender_address'];
    $sender_city = $_POST['sender_city'];
    $sender_country = $_POST['sender_country'];
    $currency = $_POST['currency'];
    $amount = floatval($_POST['amount']);
    $beneficiary_swift_code = $_POST['beneficiary_swift_code'];
    $beneficiary_bank_name = $_POST['beneficiary_bank_name'];
    $beneficiary_bank_address = $_POST['beneficiary_bank_address'];
    $beneficiary_bank_city = $_POST['beneficiary_bank_city'];
    $beneficiary_bank_country = $_POST['beneficiary_bank_country'];
    $beneficiary_account_number = $_POST['beneficiary_account_number'];
    $beneficiary_name = $_POST['beneficiary_name'];
    $beneficiary_address = $_POST['beneficiary_address'];
    $beneficiary_city = $_POST['beneficiary_city'];
    $beneficiary_country = $_POST['beneficiary_country'];
    $purpose = $_POST['purpose'];

    // Determine the minimum transfer limit based on currency
    $minTransferLimitUSD = 1000000;
    if ($currency === "USD") {
        $minTransferLimit = $minTransferLimitUSD;
    } elseif ($currency === "AED") {
        $rate = getAEDtoUSDExchangeRate();
        if ($rate === null) {
            echo json_encode([
                "status" => "error",
                "message" => "Unable to retrieve exchange rate. Please try again later."
            ]);
            exit;
        }
        $minTransferLimit = $minTransferLimitUSD / $rate; // Convert USD to AED equivalent
    } else {
        echo json_encode([
            "status" => "error",
            "message" => "Unsupported currency provided."
        ]);
        exit;
    }

    // Check if the amount is below the minimum transfer limit
    if ($amount < $minTransferLimit) {
        echo json_encode([
            "status" => "error",
            "message" => "Transaction failed. The transfer amount must be at least $minTransferLimit."
        ]);
        exit;
    }

    $stmt = $conn->prepare("
        SELECT * FROM customer_detail 
        JOIN login ON customer_detail.Account_No = login.AccountNo 
        JOIN accounts ON accounts.AccountNo = login.AccountNo 
        WHERE customer_detail.Account_No = ?
    ");
    $stmt->bind_param("s", $sender_account_number);
    $stmt->execute();
    $senderResult = $stmt->get_result();

    if ($senderResult->num_rows > 0) {
        $sender = $senderResult->fetch_assoc();
        $SBalance = $sender['Balance'];
        $SStatus = $sender['Status'];
        $SName = $sender['C_First_Name'] . " " . $sender['C_Last_Name'];
        $SProColor = $sender['ProfileColor'];
        $SEmail = $sender['C_Email'];
        $ProfileImage = trim($sender['ProfileImage']);

        if (empty($ProfileImage)) {
            echo json_encode([
                "status" => "error",
                "message" => "Please upload your profile picture before making a wire transfer."
            ]);
            exit;
        }

        if ($SStatus !== "Active") {
            echo json_encode(["status" => "error", "message" => "Sender account is not active"]);
            exit;
        }

        if ($SBalance < $amount) {
            echo json_encode(["status" => "error", "message" => "Transaction failed. Not sufficient balance!"]);
            exit;
        }

        mysqli_begin_transaction($conn);
        try {
            $stmt = $conn->prepare("
                INSERT INTO wire_transfers (
                    username, sender_name, sender_account_number, sender_address, sender_city, sender_country,
                    currency, amount, beneficiary_swift_code, beneficiary_bank_name, beneficiary_bank_address,
                    beneficiary_bank_city, beneficiary_bank_country, beneficiary_account_number, beneficiary_name,
                    beneficiary_address, beneficiary_city, beneficiary_country, purpose
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->bind_param("sssssssssssssssssss",
                $username, $sender_name, $sender_account_number, $sender_address, $sender_city, $sender_country,
                $currency, $amount, $beneficiary_swift_code, $beneficiary_bank_name, $beneficiary_bank_address,
                $beneficiary_bank_city, $beneficiary_bank_country, $beneficiary_account_number, $beneficiary_name,
                $beneficiary_address, $beneficiary_city, $beneficiary_country, $purpose
            );
            $stmt->execute();

            $newBalance = $SBalance - $amount;
            $stmt = $conn->prepare("UPDATE accounts SET Balance = ? WHERE AccountNo = ?");
            $stmt->bind_param("ds", $newBalance, $sender_account_number);
            $stmt->execute();

            $debitAmount = '-' . $amount;
            $stmt = $conn->prepare("
                INSERT INTO transaction (AccountNo, FAccountNo, Name, Amount, Status, ProfileColor, Credit, Debit)
                VALUES (?, ?, ?, ?, 'Pending', ?, '0.0', ?)
            ");
            $stmt->bind_param("ssssss", $sender_account_number, $beneficiary_account_number, $beneficiary_name, $debitAmount, $SProColor, $amount);
            $stmt->execute();

            mysqli_commit($conn);

            echo json_encode(["status" => "success", "message" => "Wire transfer initiated successfully"]);
            exit;
        } catch (Exception $e) {
            mysqli_rollback($conn);
            echo json_encode(["status" => "error", "message" => "Transaction failed. Please try again."]);
            exit;
        }
    } else {
        echo json_encode(["status" => "error", "message" => "Sender account not found"]);
        exit;
    }
} else {
    echo json_encode(["status" => "error", "message" => "Invalid request"]);
    exit;
}
