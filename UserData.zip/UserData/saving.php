<?php
include "../connection.php";

session_start();

if (!isset($_SESSION['username'])) {
    header("Location: ../login.php");
}
$username = $_SESSION['username'];
$AccountNo = $_SESSION['AccountNo'];


?>
<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>Saving   إميراترست | EmiraTrust</title>

    <!-- Favicons -->
    <link href="../../assets/img/favicon-32x32.png" rel="icon">
    <link href="../../assets/img/apple-icon-180x180.png" rel="apple-touch-icon">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@700;800;900&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="../../assets/vendor/boxicons/css/boxicons.css">
    <link rel="stylesheet" href="../../assets/vendor/boxicons/css/boxicons.min.css">
    <link rel="stylesheet" href="../../assets/vendor/boxicons/css/animations.css">
    <link rel="stylesheet" href="../../assets/vendor/boxicons/css/transformations.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />


    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700;800&family=Roboto:wght@300;400;500;700;900&display=swap" rel="stylesheet">
    <!--fontawesome-->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="../../assets/css/UserDash.css">
    <style>
        #counter {
            position: absolute;
            left: 44%;
            right: auto;
            top: 47%;
            font-size: 2rem;
            color: #006CFA;
        }

        .gradient-target {
            background-color: #f3ec78;
            background-image: radial-gradient(#FF0026 15%, #FF0026 60%);
            background-size: 100%;
            -webkit-background-clip: text;
            -moz-background-clip: text;
            -webkit-text-fill-color: transparent;
            -moz-text-fill-color: transparent;
            font-size: 100px;
        }

        .transfer-icon {
            background-color: #f3ec78;
            background-image: linear-gradient(#21c8ff, #003dc7);
            background-size: 100%;
            -webkit-background-clip: text;
            -moz-background-clip: text;
            -webkit-text-fill-color: transparent;
            -moz-text-fill-color: transparent;
            font-size: 100px;
        }

        .piggybank {
            font-size: 100px;
            background-color: #f3ec78;
            background-image: radial-gradient(#FF0026 -160%, pink 80%);
            background-size: 100%;
            -webkit-background-clip: text;
            -moz-background-clip: text;
            -webkit-text-fill-color: transparent;
            -moz-text-fill-color: transparent;
            font-size: 100px;

        }

        .btn-success {
            background-color: #24AB1D;
        }
    </style>


</head>

<body>
    <?php include "header.php" ?>
    <!-- End of Topbar -->

    <!-- Begin Page Content -->
    <div class="container-fluid px-lg-4">
        <div class="row">
            <div class="col-md-12 mt-4">
                <div class="d-sm-flex align-items-center justify-content-between mb-4">
                    <h1 class="h3 mb-0 text-gray-800">Saving</h1>
                    <!-- <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i>
                        Generate Report</a> -->
                </div>
                <div class="row">
                    <div class="col-md-4">

                        <!-- Add Money Class -->
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title mb-4 " style="color: #8a2208">Add Money for Saving</h5>
                                <h1 id="CreditDisplay" class="display-5 mt-1 mb-3 text-success"></h1>

                                <div class="d-flex justify-content-center">
                                    <i class="fas fa-piggy-bank piggybank fa-flip-horizontal"></i>
                                </div>

                                <div class="d-flex justify-content-center mt-5">
                                    <button id="AddMoneyBtn" class="btn btn-primary" type="button" style="background: #8a2208"> &nbsp; &nbsp;<i class="fas fa-plus-circle"></i> &nbsp; Add Money &nbsp; &nbsp;</button>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title mb-4 " style="color: #8a2208">Total Saving Balance</h5>
                                <h1 id="SavingDisplay" class="display-5 mt-1 mb-3 text-success"></h1>
                                <div class="mb-1">
                                    <span id="CreditLastM" class="text-success"> <i class="mdi mdi-arrow-bottom-right"></i></span>
                                    <span class="text-muted" style="color: #8a2208">Your Total Saving Balance</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title mb-4 " style="color: #8a2208">Target Progress</h5>
                                <h1 id="CreditDisplay" class="display-5 mt-1 mb-3 text-success"></h1>
                                <div class="mb-1 d-flex justify-content-center">



                                    <div id="circle" style="color: #8a2208"> <strong id="counter">100%</strong></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-sm-4">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title mb-4 " style="color: #8a2208">Set Saving Amount</h5>
                                <h1 class="display-5 mt-1 mb-3 text-success" style="color: #8a2208"></h1>


                                <div class="d-flex justify-content-center">
                                    <img style="height: 100px;" src="../UserData/assets/img/target.svg" alt="">
                                </div>

                                <div class="d-flex justify-content-center mt-5">
                                    <button id="SetTarget" class="btn btn-success setAmountbtn " style="background: #8a2208"> <img style="height: 18px;" src="../UserData/assets/img/targetBtn.svg" alt=""> Set Target Amount</button>
                                </div>


                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title mb-4 " style="color: #8a2208">Target Amount</h5>
                                <h1 id="TargetDisplay" class="display-5 mt-1 mb-3 text-primary"></h1>
                                <div class="mb-1">


                                    <span id="CreditLastM" class="text-success"> <i class="mdi mdi-arrow-bottom-right"></i></span>
                                    <span class="text-muted" style="color: #8a2208">Any Time You can Change Your Target</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title mb-4 " style="color: #8a2208">Transfer Money to Main Account</h5>
                                <h1 id="CreditDisplay" class="display-5 mt-1 mb-3 text-success"></h1>

                                <div class="d-flex justify-content-center">
                                    <i class="fas fa-exchange-alt transfer-icon"></i>
                                </div>
                                <div class="d-flex justify-content-center mt-5">
                                    <button id="TransferBtn" class="btn btn-primary" type="button" style="background: #8a2208"> &nbsp; &nbsp;<i class="fas fa-wallet"></i> &nbsp; Transfer Saving &nbsp; &nbsp;</button>
                                </div>
                                <div class="mb-1">


                                    <span id="CreditLastM" class="text-success"> <i class="mdi mdi-arrow-bottom-right"></i></span>
                                    <span class="text-muted"></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <footer id="footer" style="background: url('https://i.imgur.com/pbCKDLX.jpeg');">

    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-3 col-md-6 footer-contact">
            <h3>  إميراترست | EmiraTrust</h3>
            <p>
               Burj Al Salam <br>
              67HP+WP Dubai <br>
              UAE <br><br>
              <strong>Phone:</strong> +91 5589 55488 55<br>
              <strong>Email:</strong> inquiries@emiratrust.com<br>
            </p>
          </div>

          <div class="col-lg-2 col-md-6 footer-links">
           
           
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
           
            
          </div>

          <div class="col-lg-4 col-md-6 footer-newsletter">
            <div class="d-flex justify-content-center">
              <img src="https://i.imgur.com/si2NUnQ.jpeg" style="width: 100px; height: 100px;" alt="">
            </div>

            <h1 class="text-center mt-2">&nbsp إميراترست&nbsp|&nbspEmiraTrust</h1>
          </div>

        </div>
      </div>
    </div>

    <div class="container">

      <div class="copyright-wrap d-md-flex py-4">
        <div class="me-md-auto text-center text-md-start">
          <div class="copyright">
            &copy; Copyright <strong><span>  إميراترست | EmiraTrust</span></strong>. All Rights Reserved
          </div>
          <div class="credits">
            <!-- All the links in the footer should remain intact. -->
            <!-- You can delete the links only if you purchased the pro version. -->
            <!-- Licensing information: https://bootstrapmade.com/license/ -->
            <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/techie-free-skin-bootstrap-3/ -->
            <!-- Designed by <a href="#">Sky Tech</a> -->
          </div>
        </div>
        <div class="social-links text-center text-md-right pt-3 pt-md-0">
          <a href="https://x.com/EmiraTrust" class="twitter"><i class="bx bxl-twitter"></i></a>
          <a href="https://www.facebook.com/emiratrust" class="facebook"><i class="bx bxl-facebook"></i></a>
          <a href="https://www.instagram.com/emiratrust/"class="instagram"><i class="bx bxl-instagram"></i></a></i></a>
          <a href="#" class="linkedin"><i class="bx bxl-linkedin"></i></a>
        </div>
      </div>

    </div>
  </footer>




    </div>
    <!-- End of Page Content -->

    <?php include "footer.php" ?>
    <!-- Wraper Ends Here -->


    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
    <script src="../UserData/assets/jquery-circle-progress-master/dist/circle-progress.min.js"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="../UserData/js/profileInfo.js"></script>
    <script src="../UserData/js/saving.js"></script>

    <script>
        $('#bar').click(function() {
            $(this).toggleClass('open');
            $('#page-content-wrapper ,#sidebar-wrapper').toggleClass('toggled');


        });
        
        console.log("hello");
        $("#Saving").addClass("active");
    </script>
   

</body>

</html>