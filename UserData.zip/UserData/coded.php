<?php
header('Content-Type: application/json');
ini_set('display_errors', 0);
error_reporting(E_ALL);
include "../connection.php";
include "../mail/TransactionMail.php";
session_start();

$username = $_SESSION['username'];
// echo $username;
$AcNo = $_SESSION['AccountNo'];

if (isset($_POST['BalanceCheck'])) {
    $response = [];

    // Your DB connection and username setup
    // Example: $username = $_SESSION['username'];
    // $conn = mysqli_connect(...);

    $query = "SELECT * FROM customer_detail 
              JOIN login ON customer_detail.Account_No = login.AccountNo 
              JOIN accounts ON accounts.AccountNo = login.AccountNo 
              WHERE login.Username = '$username'";

    $result = mysqli_query($conn, $query);

    if ($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $Balance = $row['Balance'];
        $Saving = $row['SavingBalance'];
        $AccountNo = $row['AccountNo'];
        $currencyPreference = $row['Currency_Preference'];

        // Credit last month
        $CreditTotal = 0;
        $CreditQuery = "SELECT Amount FROM transaction 
                        WHERE month(Date) = month(now()) - 1 
                        AND Status = 'Credited' 
                        AND AccountNo = '$AccountNo'";
        $CreditResult = mysqli_query($conn, $CreditQuery);
        if ($CreditResult) {
            while ($row = mysqli_fetch_assoc($CreditResult)) {
                $CreditTotal += $row['Amount'];
            }
        }

        // Debit last month
        $DebitTotal = 0;
        $DebitQuery = "SELECT Amount FROM transaction 
                       WHERE month(Date) = month(now()) - 1 
                       AND Status = 'Debited' 
                       AND AccountNo = '$AccountNo'";
        $DebitResult = mysqli_query($conn, $DebitQuery);
        if ($DebitResult) {
            while ($row = mysqli_fetch_assoc($DebitResult)) {
                $DebitTotal += $row['Amount'];
            }
        }

        // Credit this month
        $CreditThisMonthTotal = 0;
        $CreditThisMonthQuery = "SELECT Amount FROM transaction 
                                 WHERE Date >= (LAST_DAY(NOW()) + INTERVAL 1 DAY - INTERVAL 1 MONTH) 
                                 AND Date < (LAST_DAY(NOW()) + INTERVAL 1 DAY) 
                                 AND AccountNo = '$AccountNo' 
                                 AND Status = 'Credited'";
        $CreditThisMonthResult = mysqli_query($conn, $CreditThisMonthQuery);
        if ($CreditThisMonthResult) {
            while ($row = mysqli_fetch_assoc($CreditThisMonthResult)) {
                $CreditThisMonthTotal += $row['Amount'];
            }
        }

        // Debit this month
        $DebitThisMonthTotal = 0;
        $DebitThisMonthQuery = "SELECT Amount FROM transaction 
                                WHERE Date >= (LAST_DAY(NOW()) + INTERVAL 1 DAY - INTERVAL 1 MONTH) 
                                AND Date < (LAST_DAY(NOW()) + INTERVAL 1 DAY) 
                                AND AccountNo = '$AccountNo' 
                                AND Status = 'Debited'";
        $DebitThisMonthResult = mysqli_query($conn, $DebitThisMonthQuery);
        if ($DebitThisMonthResult) {
            while ($row = mysqli_fetch_assoc($DebitThisMonthResult)) {
                $DebitThisMonthTotal += $row['Amount'];
            }
        }

        // Send response
        $response = [
            'Balance' => number_format($Balance, 2),
            'Saving' => number_format($Saving, 2),
            'AccountNo' => $AccountNo,
            'Currency' => $currencyPreference,
            'CreditTotal' => number_format($CreditTotal, 2),
            'DebitTotal' => number_format($DebitTotal, 2),
            'CreditThisMonth' => number_format($CreditThisMonthTotal, 2),
            'DebitThisMonth' => number_format($DebitThisMonthTotal, 2),
            'status' => 'success'
        ];

    } else {
        // No account found
        $response = [
            'status' => 'error',
            'message' => 'No matching account found'
        ];
    }

    echo json_encode($response);
    exit;
} else {
    echo json_encode([
        'status' => 'error',
        'message' => 'Invalid request'
    ]);
    exit;
}
