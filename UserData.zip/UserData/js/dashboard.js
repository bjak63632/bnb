$(document).ready(function () {

    console.log("hello");
    $("#Dashboard").addClass("active");

    let balanceChecker = 1;
    $.ajax({
        type: "POST",
        url: "coded.php",
        data: { BalanceCheck: balanceChecker },
        dataType: "json",
        success: function (response) {
            // Determine the correct symbol
            let currencySymbol = response['Currency'] === "AED" ? "AED" : "$";

            $("#BalanceDisplay").text(currencySymbol + " " + response['Balance']);
            $("#SavingDisplay").text(currencySymbol + " " + response['Saving']);

            $("#CreditDisplay").text(currencySymbol + " " + response['CreditThisMonth']);
            $("#DebitDisplay").text(currencySymbol + " " + response['DebitThisMonth']);

            $("#DebitLastM").text(currencySymbol + " " + response['DebitTotal']);
            $("#CreditLastM").text(currencySymbol + " " + response['CreditTotal']);

            console.log("Currency: " + response['Currency']);
        }
    });

});
