$(document).ready(function () {
    console.log("Wire transfer ready");

    $("#achwireTransferForm").on("submit", function (e) {
        e.preventDefault();

        let formData = {
            action: "ach_wire_transfer",
            sender_name: $("#sender_name").val(),
            sender_account_number: $("#sender_account_number").val(),
            routingNumber: $("#routingNumber").val(),
            bankName: $("#bank_name").val(),
            account_type: $("#account_type").val(),
            recipient_name: $("#recipient_name").val(),  // Added recipient name
            amount: $("#amount").val(),  // Added amount
            currency: $("#currency").val(),
            recipient_account_number: $("#recipient_account_number").val(),
            streetname: $("#streetname").val(),
            streetnumber: $("#streetnumber").val(),
            apartment: $("#apartment").val(),
            floor: $("#floor").val(),
            postal_code: $("#postal_code").val(),
            country: $("#country").val(),
            city: $("#city").val(),
            province: $("#province").val()
        };

        swal({
            title: "Confirm Wire Transfer",
            text: `Send $${formData.amount} to ${formData.recipient_name}?`,
            icon: "warning",
            buttons: true,
            dangerMode: true,
        }).then((confirmed) => {
            if (confirmed) {
                $.ajax({
                    type: "POST",
                    url: "achwire.php",  // Update this URL if needed
                    data: formData,
                    dataType: "json",
                    beforeSend: function () {
                        $(".modal").modal("show");
                    },
                    complete: function () {
                        $(".modal").modal("hide");
                    },
                    success: function (response) {
                        if (response.status === "success") {
                            swal("Transfer Successful!", {
                                icon: "success",
                                buttons: false,
                            });
                            setTimeout(() => {
                                location.reload();
                            }, 2000);
                        } else {
                            swal("Transfer Failed", response.message || "Please try again.", "error");
                        }
                    },
                    error: function () {
                        swal("Server Error", "Please try again later.", "error");
                    }
                });
            }
        });
    });
});
