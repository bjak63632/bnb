$(document).ready(function () {
    console.log("Wire transfer ready");

    $("#wireTransferForm").on("submit", function (e) {
        e.preventDefault();

        let formData = {
            action: "wire_transfer",
            username: $("#username").val(),
            sender_name: $("#sender_name").val(),
            sender_account_number: $("#sender_account_number").val(),
            sender_address: $("#sender_address").val(),
            sender_city: $("#sender_city").val(), 
            sender_country: $("#sender_country").val(),
            currency: $("#currency").val(),
            amount: $("#amount").val(),
            beneficiary_swift_code: $("#beneficiary_swift_code").val(),
            beneficiary_bank_name: $("#beneficiary_bank_name").val(),
            beneficiary_bank_address: $("#beneficiary_bank_address").val(),
            beneficiary_bank_city: $("#beneficiary_bank_city").val(),
            beneficiary_bank_country: $("#beneficiary_bank_country").val(),
            beneficiary_account_number: $("#beneficiary_account_number").val(),
            beneficiary_name: $("#beneficiary_name").val(),
            beneficiary_address: $("#beneficiary_address").val(),
            beneficiary_city: $("#beneficiary_city").val(),
            beneficiary_country: $("#beneficiary_country").val(),
            purpose: $("#purpose").val() 
        };

        swal({
            title: "Confirm Wire Transfer",
            text: `Send $${formData.amount} to ${formData.beneficiary_name}?`,
            icon: "warning",
            buttons: true,
            dangerMode: true,
        }).then((confirmed) => {
            if (confirmed) {
                $.ajax({
                    type: "POST",
                    url: "codeTransfer.php",
                    data: formData,
                    dataType: "json",
                    beforeSend: function () {
                        $(".modal").modal("show");
                    },
                    complete: function () {
                        $(".modal").modal("hide");
                    },
                    success: function (response) {
                        if (response.status === "success") {
                            swal("Transfer Successful!", {
                                icon: "success",
                                buttons: false,
                            });
                            setTimeout(() => {
                                location.reload();
                            }, 2000);
                        } else {
                            swal("Transfer Failed", response.message || "Please try again.", "error");
                        }
                    },
                    error: function () {
                        swal("Server Error", "Please try again later.", "error");
                    }
                });
            }
        });
    });
});
