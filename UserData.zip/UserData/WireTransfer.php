<?php
include "../connection.php";
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: ../login.php");
    exit();
}

$username = $_SESSION['username'];

if (!isset($_SESSION['account_number'])) {
    $stmt = $conn->prepare("SELECT AccountNo FROM login WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->bind_result($accountNoFromDb);
    if ($stmt->fetch()) {
        $_SESSION['account_number'] = $accountNoFromDb;
    } else {
        echo "Error: Account number not found.";
        exit();
    }
    $stmt->close();
}

$sender_account = $_SESSION['account_number'];
$sender_name = "";
$sender_address = "";
$sender_city = "";
$sender_country = "";

$detailsStmt = $conn->prepare("SELECT C_First_Name, Street_name, City, Country FROM customer_detail WHERE Account_No = ?");
$detailsStmt->bind_param("s", $sender_account);
$detailsStmt->execute();
$detailsStmt->bind_result($sender_name, $sender_address, $sender_city, $sender_country);
$detailsStmt->fetch();
$detailsStmt->close();

$currency_preference = "USD"; // Default fallback

$currencyStmt = $conn->prepare("SELECT Currency_Preference FROM accounts WHERE AccountNo = ?");
$currencyStmt->bind_param("s", $sender_account);
$currencyStmt->execute();
$currencyStmt->bind_result($currency_preference);
$currencyStmt->fetch();
$currencyStmt->close();



?>

<!-- HTML form section continues from here... -->




<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>Transfer   إميراترست | EmiraTrust</title>

    <!-- Favicons -->
    <link href="../../assets/img/favicon-32x32.png" rel="icon">
    <link href="../../assets/img/apple-icon-180x180.png" rel="apple-touch-icon">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@700;800;900&display=swap" rel="stylesheet">
    

    <link rel="stylesheet" href="../../assets/vendor/boxicons/css/boxicons.css">
    <link rel="stylesheet" href="../../assets/vendor/boxicons/css/boxicons.min.css">
    <link rel="stylesheet" href="../../assets/vendor/boxicons/css/animations.css">
    <link rel="stylesheet" href="../../assets/vendor/boxicons/css/transformations.css">


    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700;800&family=Roboto:wght@300;400;500;700;900&display=swap" rel="stylesheet">
    <!--fontawesome-->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="../../assets/css/UserDash.css">

    <style>
        .btn-pay {
            background-image: linear-gradient(to right, #43e97b 0%, #38f9d7 100%);
            color: #fdfdfd;
            font-weight: bold;
            box-shadow: 0 0 0.875rem 0 rgb(33 37 41 / 5%);
            border-radius: 30px;
        }

        .btn-pay:hover {
            background-image: linear-gradient(to right, #42c16d 0%, #33e6c7 100%);



        }

        .card {
            background: #8a2208;
        }
        .card label {
                color: #fff;
            }
            .card h1, .card h2, .card h3, .card h4, .card h5, .card h6 {
                color: #fff;
            }

         /* The Modal (background) */
         .customodal {
            display: none;
            /* Hidden by default */
            position: fixed;
            /* Stay in place */
            z-index: 1;
            /* Sit on top */
            padding-top: 100px;
            /* Location of the box */
            left: 0;
            top: 0;
            width: 100%;
            /* Full width */
            height: 100%;
            /* Full height */
            overflow: auto;
            /* Enable scroll if needed */
            background-color: rgb(0, 0, 0);
            /* Fallback color */
            background-color: rgba(0, 0, 0, 0.9);
            /* Black w/ opacity */
        }

        /* Modal Content (Image) */
        .customodal-content {
            margin: auto;
            display: block;
            width: 80%;
            max-width: 700px;
        }

        /* Caption of Modal Image (Image Text) - Same Width as the Image */
        #caption {
            margin: auto;
            display: block;
            width: 80%;
            max-width: 700px;
            text-align: center;
            color: #ccc;
            padding: 10px 0;
            height: 150px;
        }

        /* Add Animation - Zoom in the Modal */
        .customodal-content,
        #caption {
            animation-name: zoom;
            animation-duration: 0.6s;
        }

        @keyframes zoom {
            from {
                transform: scale(0)
            }

            to {
                transform: scale(1)
            }
        }

        /* The Close Button */
        .closebtn {
            position: absolute;
            top: 15px;
            right: 35px;
            color: #f1f1f1;
            font-size: 40px;
            font-weight: bold;
            transition: 0.3s;
        }

        .closebtn:hover,
        .closebtn:focus {
            color: #bbb;
            text-decoration: none;
            cursor: pointer;
        }

        /* 100% Image Width on Smaller Screens */
        @media only screen and (max-width: 700px) {
            .modal-content {
                width: 100%;
            }
        }

        .loadingModal {
            display: flex;
            justify-content: center;
            align-items: center;
            margin-top: 20%;
        }
    </style>


</head>

<body>
    <?php include "header.php" ?>
    <!-- End of Topbar -->

    <!-- Begin Page Content -->
    <div class="container-fluid px-lg-4 dark_bg light">
        <div class="row">
            <div class="col-md-12 mt-lg-4 mt-4">
                <!-- Page Heading -->
                <div class="d-sm-flex align-items-center mb-4" style="justify-content:center;">
                    <h1 class="h3 mb-0 light" style="text-align: center; color: #8a2208" >Wire Transfer Money</h1>
                </div>


            </div>

            <div class="col-md-12">
                <div class="row">
                    <div class="col-sm-2"></div>
                    <div class="col-sm-8">
                        <div class="card" >
                           <!-- wireTransfer.php -->
                                <div class="container mt-4">
                                    <h4 class="mb-3">Wire Transfer Form</h4>
                                    <form id="wireTransferForm">
                                        <h5 class="mt-4">Sender Information</h5>
                                        <div class="form-group">
                                            <label for="sender_name">Sender Name</label>
                                            <input type="text" class="form-control" value="<?php echo htmlspecialchars($sender_name); ?>" id="sender_name" name="sender_name" readonly>
                                        </div>
                                        <div class="form-group">
                                            <label for="sender_account_number">Sender Account Number</label>
                                            <input type="text" class="form-control" value="<?php echo htmlspecialchars($sender_account); ?>" id="sender_account_number" name="sender_account_number" readonly>
                                        </div>
                                        <div class="form-group">
                                            <label for="sender_address">Sender Address</label>
                                            <input type="text" class="form-control" value="<?php echo htmlspecialchars($sender_address); ?>" id="sender_address" name="sender_address" readonly>
                                        </div>
                                        <div class="form-row">
                                            <div class="form-group col-md-6">
                                                <label for="sender_city">City</label>
                                                <input type="text" class="form-control" value="<?php echo htmlspecialchars($sender_city); ?>" id="sender_city" name="sender_city" readonly>
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label for="sender_country">Country</label>
                                                <input type="text" class="form-control" value="<?php echo htmlspecialchars($sender_country); ?>" id="sender_country" name="sender_country" readonly>
                                            </div>
                                        </div>

                                        <h5 class="mt-4">Transfer Details</h5>
                                        <div class="form-row">
                                            <div class="form-group col-md-6">
                                                <label for="currency">Currency</label>
                                                <input type="text" class="form-control" id="currency" name="currency" value="<?php echo $currency_preference; ?>" readonly>
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label for="amount">Amount</label>
                                                <input type="number" step="0.01" class="form-control" id="amount" name="amount" required>
                                            </div>
                                        </div>

                                        <h5 class="mt-4">Beneficiary Bank Information</h5>
                                        <div class="form-group">
                                            <label for="beneficiary_swift_code">SWIFT Code</label>
                                            <input type="text" class="form-control" id="beneficiary_swift_code" name="beneficiary_swift_code" required>
                                        </div>
                                        <div class="form-group">
                                            <label for="beneficiary_bank_name">Bank Name</label>
                                            <input type="text" class="form-control" id="beneficiary_bank_name" name="beneficiary_bank_name" required>
                                        </div>
                                        <div class="form-group">
                                            <label for="beneficiary_bank_address">Bank Address</label>
                                            <input type="text" class="form-control" id="beneficiary_bank_address" name="beneficiary_bank_address" required>
                                        </div>
                                        <div class="form-row">
                                            <div class="form-group col-md-6">
                                                <label for="beneficiary_bank_city">Bank City</label>
                                                <input type="text" class="form-control" id="beneficiary_bank_city" name="beneficiary_bank_city" required>
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label for="beneficiary_bank_country">Bank Country</label>
                                                <input type="text" class="form-control" id="beneficiary_bank_country" name="beneficiary_bank_country" required>
                                            </div>
                                        </div>

                                        <h5 class="mt-4">Beneficiary Information</h5>
                                        <div class="form-group">
                                            <label for="beneficiary_account_number">Beneficiary Account Number</label>
                                            <input type="text" class="form-control" id="beneficiary_account_number" name="beneficiary_account_number" required>
                                        </div>
                                        <div class="form-group">
                                            <label for="beneficiary_name">Beneficiary Name</label>
                                            <input type="text" class="form-control" id="beneficiary_name" name="beneficiary_name" required>
                                        </div>
                                        <div class="form-group">
                                            <label for="beneficiary_address">Beneficiary Address</label>
                                            <input type="text" class="form-control" id="beneficiary_address" name="beneficiary_address" required>
                                        </div>
                                        <div class="form-row">
                                            <div class="form-group col-md-6">
                                                <label for="beneficiary_city">City</label>
                                                <input type="text" class="form-control" id="beneficiary_city" name="beneficiary_city" required>
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label for="beneficiary_country">Country</label>
                                                <input type="text" class="form-control" id="beneficiary_country" name="beneficiary_country" required>
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label for="purpose">Purpose of Transfer</label>
                                            <textarea class="form-control" id="purpose" name="purpose" rows="3" required></textarea>
                                        </div>

                                        <button type="submit" class="btn btn-primary"  style="color: #8a2208">Initiate Wire Transfer</button>
                                    </form>
                                </div>

                        </div>
                    </div>
                    <div class="col-sm-2"></div>



                </div>


            </div>

        </div>

        <div class="modal fade bd-example-modal-lg" data-backdrop="static" data-keyboard="false" tabindex="-1">
            <div class="modal-dialog loadingModal modal-lg">
                <div class="modal-content" style="width: 50px; height:50px; background: transparent;">
                    <span class="fas fa-spinner fa-pulse fa-3x" style="color:white"></span>
                </div>
            </div>
        </div>

    </div>
    <!-- End of Page Content -->

    <?php include "footer.php" ?>


    <!-- Wraper Ends Here -->


    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
     
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script src="../UserData/js/profileInfo.js"></script>
    <script src="../UserData/js/wireTransfer.js"></script>
    


    <script>
        $('#bar').click(function() {
            $(this).toggleClass('open');
            $('#page-content-wrapper ,#sidebar-wrapper').toggleClass('toggled');

        });
    </script>
        <script>
        document.querySelector("form").addEventListener("submit", function(e) {
            e.preventDefault();

            const formData = new FormData(this);

            fetch('processWireTransfer.php', {
                method: 'POST',
                body: formData
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    swal("Success", data.message, "success").then(() => {
                        location.reload(); // Optionally reload to reflect new balance
                    });
                } else {
                    swal("Error", data.message, "error");
                }
            })
            .catch(err => {
                console.error("Error:", err);
                swal("Error", "Something went wrong", "error");
            });
        });
        </script>


</body>

</html>