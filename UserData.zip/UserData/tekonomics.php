<?php
include "../connection.php";

session_start();

if (!isset($_SESSION['username'])) {
    header("Location: ../login.php");
}
$username = $_SESSION['username'];
// $query = "SELECT * FROM customer_detail JOIN login ON customer_detail.Account_No = login.AccountNo WHERE login.Username = '$username'";
// $result = mysqli_query($conn, $query);

// if (mysqli_num_rows($result) > 0) {

//     while ($row = mysqli_fetch_assoc($result)) {



//     }
//   }

?>
<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Insurance   إميراترست | EmiraTrust</title>

    <!-- Favicons -->
    <link href="../../assets/img/favicon-32x32.png" rel="icon">
    <link href="../../assets/img/apple-icon-180x180.png" rel="apple-touch-icon">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@700;800;900&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="../../assets/vendor/boxicons/css/boxicons.css">
    <link rel="stylesheet" href="../../assets/vendor/boxicons/css/boxicons.min.css">
    <link rel="stylesheet" href="../../assets/vendor/boxicons/css/animations.css">
    <link rel="stylesheet" href="../../assets/vendor/boxicons/css/transformations.css">



    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700;800&family=Roboto:wght@300;400;500;700;900&display=swap" rel="stylesheet">
    <!--fontawesome-->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">

    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">

    <link rel="stylesheet" href="../../assets/css/UserDash.css">
    <style>
        @media only screen and (min-width:992px) {
            #credit {
                display: block;
                box-sizing: border-box;
                height: 181px;
                width: 363px;
            }
        }
    </style>

</head>

<body>

 <?php include "header.php" ?>

  <main id="main">

    <!-- ======= Breadcrumbs ======= -->
    <section class="breadcrumbs">
      <div class="container">
        <div class="d-flex justify-content-between align-items-center">
          <h3 style="color: #8a2208">
           Choose digital asset to deposit
      </h3>
        </div>
      </div>
    </section><!-- End Breadcrumbs -->

    <!-- ======= Coin Options Section ======= -->
    <section class="inner-page">
      <div class="container">
        <div class="row gy-4 text-center">
          <div class="col-12">
            <table class="table table-hover text-nowrap">
            <thead>
              <tr>
                <th>#</th>
                <th>Coin</th>
                <th>Deposit</th>
                <th>Price</th>
                <th>Change (24h)</th>
                <th>Market Cap</th>
              </tr>
            </thead>
            <tbody>
              <tr data-id="bitcoin" data-symbol="btc">
                <th scope="row">1</th>
                <td><img src="https://assets.coingecko.com/coins/images/1/small/bitcoin.png" alt="BTC" width="25" class="me-2">BTC</td>
                <td><a href="bc1qu6vmz58a2ytmepce6ecvfyal562383efxy5zjh.php" class="btn btn-sm btn-primary" style="background: #8a2208">Deposit</a></td>
                <td class="price">Loading...</td>
                <td class="change">Loading...</td>
                <td class="market-cap">Loading...</td>
               
              </tr>
              <tr data-id="ethereum" data-symbol="eth">
                <th scope="row">2</th>
                <td><img src="https://assets.coingecko.com/coins/images/279/small/ethereum.png" alt="ETH" width="25" class="me-2">ETH</td>
                <td><a href="0x1F0a993d560800559A731d603e1d1D1c7F62b89D.php" class="btn btn-sm btn-primary" style="background: #8a2208">Deposit</a></td>
                <td class="price">Loading...</td>
                <td class="change">Loading...</td>
                <td class="market-cap">Loading...</td>
               
              </tr>
              <tr data-id="tether" data-symbol="usdt">
                <th scope="row">3</th>
                <td><img src="https://assets.coingecko.com/coins/images/325/small/Tether.png" alt="USDT" width="25" class="me-2">USDT</td>
                <td><a href="TKzRgQkMmmck5KoixZpJgBz1w3kSAeANjj.php" class="btn btn-sm btn-primary" style="background: #8a2208">Deposit</a></td>
                <td class="price">Loading...</td>
                <td class="change">Loading...</td>
                <td class="market-cap">Loading...</td>
               
              </tr>
              <tr data-id="usd-coin" data-symbol="usdc">
                <th scope="row">4</th>
                <td><img src="https://assets.coingecko.com/coins/images/6319/small/USD_Coin_icon.png" alt="USDC" width="25" class="me-2">USDC</td>
                <td><a href="TKzRgQkMmmck5KoixZpJgBz1w3kSAeANjj1.php" class="btn btn-sm btn-primary" style="background: #8a2208">Deposit</a></td>
                <td class="price">Loading...</td>
                <td class="change">Loading...</td>
                <td class="market-cap">Loading...</td>
               
              </tr>
              <tr data-id="ripple" data-symbol="xrp">
                <th scope="row">5</th>
                <td><img src="https://assets.coingecko.com/coins/images/44/small/xrp-symbol-white-128.png" alt="XRP" width="25" class="me-2">XRP</td>
                <td><a href="rMycHUttqfF7XMciXi8mex2Km4v1i6h6rS.php" class="btn btn-sm btn-primary" style="background: #8a2208">Deposit</a></td>
                <td class="price">Loading...</td>
                <td class="change">Loading...</td>
                <td class="market-cap">Loading...</td>
                
              </tr>
              <tr data-id="solana" data-symbol="sol">
                <th scope="row">6</th>
                <td><img src="https://assets.coingecko.com/coins/images/4128/small/solana.png" alt="SOL" width="25" class="me-2">SOL</td>
                <td><a href="6CshJaLeggBwZYKNiMiEHQPfELuwCNAbXjU9kWgqUNWt.php" class="btn btn-sm btn-primary" style="background: #8a2208">Deposit</a></td>
                <td class="price">Loading...</td>
                <td class="change">Loading...</td>
                <td class="market-cap">Loading...</td>
               
              </tr>
              <tr data-id="binancecoin" data-symbol="bnb">
                <th scope="row">7</th>
                <td><img src="https://assets.coingecko.com/coins/images/825/small/bnb-icon2_2x.png" alt="BNB" width="25" class="me-2">BNB</td>
                <td><a href="0x1F0a993d560800559A731d603e1d1D1c7F62b89D1.php" class="btn btn-sm btn-primary" style="background: #8a2208">Deposit</a></td>
                <td class="price">Loading...</td>
                <td class="change">Loading...</td>
                <td class="market-cap">Loading...</td>
                
              </tr>
              <tr data-id="matic" data-symbol="matic">
                <th scope="row">8</th>
                <td><img src="https://assets.coingecko.com/coins/images/4713/small/matic-token-icon.png" alt="MATIC" width="25" class="me-2">POL</td>
                <td><a href="6CshJaLeggBwZYKNiMiEHQPfELuwCNAbXjU9kWgqUNWt1.php" class="btn btn-sm btn-primary" style="background: #8a2208">Deposit</a></td>
                <td class="price">Loading...</td>
                <td class="change">Loading...</td>
                <td class="market-cap">Loading...</td>
              
              </tr>
              <tr data-id="tron" data-symbol="trx">
                <th scope="row">9</th>
                <td><img src="https://assets.coingecko.com/coins/images/1094/small/tron-logo.png" alt="TRX" width="25" class="me-2">TRX</td>
                <td><a href="TKzRgQkMmmck5KoixZpJgBz1w3kSAeANjj2.php" class="btn btn-sm btn-primary" style="background: #8a2208">Deposit</a></td>
                <td class="price">Loading...</td>
                <td class="change">Loading...</td>
                <td class="market-cap">Loading...</td>
                
              </tr>
              <tr data-id="bitcoin-cash" data-symbol="bch">
                <th scope="row">10</th>
                <td><img src="https://assets.coingecko.com/coins/images/780/small/bitcoin-cash-circle.png" alt="BCH" width="25" class="me-2">BCH</td>
                <td><a href="qzktn060eaywwyvvcnetvwch0eesjxz4hutc485y59.php" class="btn btn-sm btn-primary" style="background: #8a2208">Deposit</a></td>
                <td class="price">Loading...</td>
                <td class="change">Loading...</td>
                <td class="market-cap">Loading...</td>
              </tr>
            </tbody>
          </table>

          </div>
        </div>
      </div>
    </section>

  </main><!-- End #main -->

   <footer id="footer" style="background: url('https://i.imgur.com/pbCKDLX.jpeg');">

    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-3 col-md-6 footer-contact">
            <h3>  إميراترست | EmiraTrust</h3>
            <p>
               Burj Al Salam <br>
              67HP+WP Dubai <br>
              UAE <br><br>
              <strong>Phone:</strong> +91 5589 55488 55<br>
              <strong>Email:</strong> inquiries@emiratrust.com<br>
            </p>
          </div>

          <div class="col-lg-2 col-md-6 footer-links">
           
           
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
           
            
          </div>

          <div class="col-lg-4 col-md-6 footer-newsletter">
            <div class="d-flex justify-content-center">
              <img src="https://i.imgur.com/si2NUnQ.jpeg" style="width: 100px; height: 100px;" alt="">
            </div>

            <h1 class="text-center mt-2">&nbsp إميراترست&nbsp|&nbspEmiraTrust</h1>
          </div>

        </div>
      </div>
    </div>

    <div class="container">

      <div class="copyright-wrap d-md-flex py-4">
        <div class="me-md-auto text-center text-md-start">
          <div class="copyright">
            &copy; Copyright <strong><span>  إميراترست | EmiraTrust</span></strong>. All Rights Reserved
          </div>
          <div class="credits">
            <!-- All the links in the footer should remain intact. -->
            <!-- You can delete the links only if you purchased the pro version. -->
            <!-- Licensing information: https://bootstrapmade.com/license/ -->
            <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/techie-free-skin-bootstrap-3/ -->
            <!-- Designed by <a href="#">Sky Tech</a> -->
          </div>
        </div>
        <div class="social-links text-center text-md-right pt-3 pt-md-0">
          <a href="https://x.com/EmiraTrust" class="twitter"><i class="bx bxl-twitter"></i></a>
          <a href="https://www.facebook.com/emiratrust" class="facebook"><i class="bx bxl-facebook"></i></a>
          <a href="https://www.instagram.com/emiratrust/"class="instagram"><i class="bx bxl-instagram"></i></a></i></a>
          <a href="#" class="linkedin"><i class="bx bxl-linkedin"></i></a>
        </div>
      </div>

    </div>
  </footer>

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center">
    <i class="bi bi-arrow-up-short"></i>
  </a>
  <div id="preloader"></div>
  <?php include "footer.php" ?>


    <!-- Wraper Ends Here -->


    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script src="../UserData/js/profileInfo.js"></script>
    <script src="../UserData/js/transfer.js"></script>


    <script>
        $('#bar').click(function() {
            $(this).toggleClass('open');
            $('#page-content-wrapper ,#sidebar-wrapper').toggleClass('toggled');

        });
    </script>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/purecounter/purecounter.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>
  <script>
  document.addEventListener("DOMContentLoaded", () => {
    const coinIds = [
      "bitcoin", "ethereum", "tether", "usd-coin", "ripple", "solana",
      "binancecoin", "matic", "tron", "bitcoin-cash"
    ];
    fetch(`https://api.coingecko.com/api/v3/simple/price?ids=${coinIds.join(',')}&vs_currencies=usd&include_market_cap=true&include_24hr_change=true`)
      .then(response => response.json())
      .then(data => {
        coinIds.forEach(id => {
          const row = document.querySelector(`tr[data-id="${id}"]`);
          if (row && data[id]) {
            const price = `$${Number(data[id].usd).toLocaleString()}`;
            const marketCap = `$${Number(data[id].usd_market_cap).toLocaleString(undefined, { maximumFractionDigits: 0 })}`;
            const change = Number(data[id].usd_24h_change).toFixed(2);
            const changeClass = change >= 0 ? 'text-success' : 'text-danger';
            const changeFormatted = `${change >= 0 ? '+' : ''}${change}%`;
            row.querySelector('.price').textContent = price;
            row.querySelector('.market-cap').textContent = marketCap;
            const changeEl = row.querySelector('.change');
            changeEl.textContent = changeFormatted;
            changeEl.classList.add(changeClass);
          }
        });
      })
      .catch(error => {
        console.error("Error fetching coin data:", error);
      });
  });
</script>

</body>

</html>