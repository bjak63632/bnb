<?php
  session_start();
  unset($_SESSION['accountNo']);
  include 'security.php';

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>EmiraTrust</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon-32x32.png" rel="icon">
  <link href="assets/img/apple-icon-180x180.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Roboto:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
  <link href="assets/css/Index.css" rel="stylesheet">
</head>



  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top ">
    <div class="container d-flex align-items-center justify-content-between">

      <!-- Uncomment below if you prefer to use an image logo -->
      <a href="index.php" class="logo" style ="text-transform: none;"><img src="assets/img/Logo3.png" alt="" class="img-fluid"> &nbsp إميراترست&nbsp|&nbspEmiraTrust</a>
      <!-- <h1 class="logo"><a href="index.html">  إميراترست | EmiraTrust</a></h1> -->

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto active" href="#hero">Home</a></li>
          <li><a class="nav-link scrollto " href="#info">Net Banking</a></li>
          <li><a class="nav-link scrollto" href="#services">Services</a></li>
          <!-- <li><a class="nav-link scrollto" href="#team">Blog</a></li> -->
          <li><a class="nav-link scrollto" href="about.html">About</a></li>
          <li><a class="nav-link scrollto" href="#contact">Contact</a></li>
          <li><a class="getstarted scrollto" href="user/login.php">&nbsp;Login&nbsp;</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header -->
<section id="hero" class="d-flex align-items-center">
  
  <div class="container-fluid" data-aos="fade-up">
    <div class="row justify-content-center">
      <!-- Left Content -->
      <div class="col-xl-5 col-lg-6 pt-3 pt-lg-0 order-2 order-lg-1 d-flex flex-column justify-content-center">
        <h1 style="color:rgb(238, 209, 202)">Make your banking experience wonderful.</h1>
        <h2 style="color:rgb(230, 217, 214)">Let’s Begin this beautiful journey </h2>
        <div class="heroBtn">
          <div><a href="user/CreateAccount.php" class="btn-get-started scrollto">Get Started</a></div>
          <div><a href="user/login.php" class="btn-get-started scrollto">&nbsp;&nbsp;&nbsp;Login&nbsp;&nbsp;&nbsp;</a></div>
        </div>
      </div>

      <!-- Right Content: Image Carousel -->
    <div class="col-xl-4 col-lg-6 col-md-12 col-12 order-1 order-lg-2 hero-img" data-aos="zoom-in" data-aos-delay="10">
  <div id="heroCarousel" class="carousel slide" data-bs-ride="carousel">
    <div class="carousel-inner">

      <!-- Slide 1 -->
      <div class="carousel-item active">
        <img src="https://i.imgur.com/a0ApnQB.jpeg" class="img-fluid d-block w-100" alt="Slide 1">
        <div class="carousel-caption d-block text-center p-2 rounded" style="background-color: rgba(14, 3, 3, 0.38);">
          <h5 class="text-white"><b>Savings</b></h5>
          <p>Grow with Confidence. Save with Purpose.</P>
          <p><a href="saving.html" class="btn btn-sm scrollto" style="background: #8a2208; color: white;">Get Started</a></p>
        </div>
      </div>

      <!-- Slide 2 -->
      <div class="carousel-item">
        <img src="https://i.imgur.com/gMP9hnd.jpeg" class="img-fluid d-block w-100" alt="Slide 2">
        <div class="carousel-caption d-block text-center p-2 rounded" style="background-color: rgba(14, 3, 3, 0.38);">
          <h5 class="text-white"><b>Accounts</b></h5>
          <p>Each class is uniquely structured to offer deposit flexibility, transaction limits, and tailored privileges </p>
          <p><a href="service24x7.html" class="btn btn-sm scrollto" style="background: #8a2208; color: white;">Get Started</a></p>
        </div>
      </div>

      <!-- Slide 3 -->
      <div class="carousel-item">
        <img src="https://i.imgur.com/T3ycARP.jpeg" class="img-fluid d-block w-100" alt="Slide 3">
        <div class="carousel-caption d-block text-center p-2 rounded" style="background-color: rgba(14, 3, 3, 0.38);">
          <h5 class="text-white"><b>Finance</b></h5>
          <p>We understand that your financial needs evolve</P>
          <p><a href="finance.html" class="btn btn-sm scrollto" style="background: #8a2208; color: white;">Get Started</a></p>
        </div>
      </div>

      <!-- Slide 4 -->
      <div class="carousel-item">
        <img src="https://i.imgur.com/mkuw3bu.jpeg" class="img-fluid d-block w-100" alt="Slide 4">
        <div class="carousel-caption d-block text-center p-2 rounded" style="background-color: rgba(14, 3, 3, 0.38);">
          <h5 class="text-white"><b>Cards</b></h5>
          <p>EmiraTrust Bank Credit and Debit Cards are designed for seamless, secure transactions. whether you're shopping online...</p>
          <p><a href="/bankerers/user/login.php" class="btn btn-sm scrollto" style="background: #8a2208; color: white;">Get Started</a></p>
        </div>
      </div>

      <!-- Slide 5 -->
      <div class="carousel-item">
        <img src="https://i.imgur.com/oD7A8Qs.jpeg" class="img-fluid d-block w-100" alt="Slide 5">
        <div class="carousel-caption d-block text-center p-2 rounded" style="background-color: rgba(14, 3, 3, 0.38);">
          <h5 class="text-white"><b>Priority Banking</b></h5>
          <p>Personalized banking with prestige, convenience, and global-class care.</p>
          <p><a href="prioritybanking.html" class="btn btn-sm scrollto" style="background: #8a2208; color: white;">Get Started</a></p>
        </div>
      </div>

      <!-- Slide 6 -->
      <div class="carousel-item">
        <img src="https://i.imgur.com/hYxa2HU.jpeg" class="img-fluid d-block w-100" alt="Slide 6">
        <div class="carousel-caption d-block text-center p-2 rounded" style="background-color: rgba(14, 3, 3, 0.38);">
          <h5 class="text-white"><b>Private Banking</b></h5>
          <p>Where exclusive wealth meets exceptional service.</p>
          <p><a href="privatebanking.html" class="btn btn-sm scrollto" style="background: #8a2208; color: white;">Get Started</a></p>
        </div>
      </div>

      <!-- Slide 7 -->
      <div class="carousel-item">
        <img src="https://i.imgur.com/e7aHA3p.jpeg" class="img-fluid d-block w-100" alt="Slide 7">
        <div class="carousel-caption d-block text-center p-2 rounded" style="background-color: rgba(14, 3, 3, 0.38);">
          <h5 class="text-white"><b>Business Banking</b></h5>
          <p>Empowering your business with the banking tools it deserves.</p>
          <p><a href="businessbanking.html" class="btn btn-sm scrollto" style="background: #8a2208; color: white;">Get Started</a></p>
        </div>
      </div>

      <!-- Slide 8 -->
      <div class="carousel-item">
        <img src="https://i.imgur.com/dG6enH5.jpeg" class="img-fluid d-block w-100" alt="Slide 8">
        <div class="carousel-caption d-block text-center p-2 rounded" style="background-color: rgba(14, 3, 3, 0.38);">
          <h5 class="text-white" ><b>Financial Literacy</b></h5>
          <p>Empowering decisions. Building a financially smart future.</p>
          <p><a href="financialliteracy.html" class="btn btn-sm scrollto" style="background: #8a2208; color: white;">Get Started</a></p>
        </div>
      </div>

      <!-- Slide 9 -->
      <div class="carousel-item">
        <img src="https://i.imgur.com/Ye3Gicg.jpeg" class="img-fluid d-block w-100" alt="Slide 9">
        <div class="carousel-caption d-block text-center p-2 rounded" style="background-color: rgba(14, 3, 3, 0.38);">
          <h5 class="text-white"><b>Smart Pass</b></h5>
          <p>Smarter, Safer Banking - One Approval at a Time</p>
          <p><a href="smartpass.html" class="btn btn-sm scrollto" style="background: #8a2208; color: white;">Get Started</a></p>
        </div>
      </div>

      <!-- Slide 10 -->
      <div class="carousel-item">
        <img src="https://i.imgur.com/4Ojwl73.jpeg" class="img-fluid d-block w-100" alt="Slide 10">
        <div class="carousel-caption d-block text-center p-2 rounded" style="background-color: rgba(14, 3, 3, 0.38);">
          <h5 class="text-white"><b>Corporate Banking</b></h5>
          <p>Strategic banking solutions for visionary enterprises.</p>
          <p><a href="corperatebanking.html" class="btn btn-sm scrollto" style="background: #8a2208; color: white;">Get Started</a></p>
        </div>
      </div>

      <!-- Slide 11 -->
      <div class="carousel-item">
        <img src="https://i.imgur.com/ZaJBDh2.jpeg" class="img-fluid d-block w-100" alt="Slide 11">
        <div class="carousel-caption d-block text-center p-2 rounded" style="background-color: rgba(14, 3, 3, 0.38);">
          <h5 class="text-white"><b>Security</b></h5>
          <p>Security isn’t an add-on at EmiraTrust Bank - it’s at the core of your entire banking experience.</p>
          <p><a href="security.html" class="btn btn-sm scrollto" style="background: #8a2208; color: white;">Get Started</a></p>
        </div>
      </div>

      <!-- Slide 12 -->
      <div class="carousel-item">
        <img src="https://i.imgur.com/GLWf6DO.jpeg" class="img-fluid d-block w-100" alt="Slide 12">
        <div class="carousel-caption d-block text-center p-2 rounded" style="background-color: rgba(14, 3, 3, 0.38);">
          <h5 class="text-white"><b>Real Estate</b></h5>
          <p>Invest smart. Settle strong. Expand confidently.</p>
          <p><a href="realestate.html" class="btn btn-sm scrollto" style="background: #8a2208; color: white;">Get Started</a></p>
        </div>
      </div>

    </div>

    <!-- Carousel Controls -->
    <button class="carousel-control-prev" type="button" data-bs-target="#heroCarousel" data-bs-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#heroCarousel" data-bs-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Next</span>
    </button>
  </div>
</div>

      
    </div>
    
  </div>
  
 

</section><!-- End Hero -->
    <!-- ======= Account Open Information Section ======= -->
    <section id="info" class="Info">
      <div class="container">

        <div class="row">
          <div class="col-lg-6 order-1 order-lg-2" data-aos="zoom-in" data-aos-delay="150">
            <img src="assets/img/about.jpg" class="img-fluid" alt="">
          </div>
          <div class="col-lg-6 pt-4 pt-lg-0 order-2 order-lg-1 content" data-aos="fade-right">
            <h3>Move money between accounts or banks globally.</h3>
            <p class="font-italic">
             Transfer money online — quickly and easily, anytime, anywhere
            </p>
            <ul>
              <li><i class="bi bi-check-circle"></i> Wire Transfer (domestic and international transfer).</li>
              <li><i class="bi bi-check-circle"></i> ACH transfer (domestic and Cross-border transfer).</li>
              <li><i class="bi bi-check-circle"></i> Between your accounts (internal Transfers).</li>
            </ul>
            <a href="user/UserData/Dashboard.php" class="read-more">Make a Transfer<i class="bi bi-long-arrow-right"></i></a>
          </div>
        </div>
      </div>
    </section><!-- End About Section -->

    <!-- ======= Counts Section ======= -->
    <section id="counts" class="counts">
      <div class="container">

        <div class="row counters">

          <div class="col-lg-3 col-6 text-center">
            <span data-purecounter-start="0" data-purecounter-end="55285" data-purecounter-duration="1" class="purecounter"></span>
            <p>Customers</p>
          </div>

          <div class="col-lg-3 col-6 text-center">
            <span data-purecounter-start="0" data-purecounter-end="37" data-purecounter-duration="1" class="purecounter"></span>
            <p>Services</p>
          </div>

          <div class="col-lg-3 col-6 text-center">
            <span data-purecounter-start="0" data-purecounter-end="23" data-purecounter-duration="1" class="purecounter"></span>
            <p>Branches</p>
          </div>

          <div class="col-lg-3 col-6 text-center">
            <span data-purecounter-start="0" data-purecounter-end="1055" data-purecounter-duration="1" class="purecounter"></span>
            <p>Employees</p>
          </div>

        </div>

      </div>
    </section><!-- End Counts Section -->

    <!-- ======= Services Section ======= -->
    <section id="services" class="services section-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Services</h2>
          <p>We Provide Worlds Best Banking Services to our Customer. We use the secure and powerful server for safe banking, we provide fastest and secure bank to bank transaction service</p>
        </div>
         

        <div class="row gy-4">
          
          <div class="col-lg-4 col-md-6 d-flex align-items-stretch" data-aos="zoom-in" data-aos-delay="200">
            <div class="icon-box iconbox-red">
              <div class="icon">
                <svg width="100" height="100" viewBox="0 0 600 600" xmlns="http://www.w3.org/2000/svg">
                  <path stroke="none" stroke-width="0" fill="#f5f5f5" d="M300,532.3542879108572C369.38199826031484,532.3153073249985,429.10787420159085,491.63046689027357,474.5244479745417,439.17860296908856C522.8885846962883,383.3225815378663,569.1668002868075,314.3205725914397,550.7432151929288,242.7694973846089C532.6665558377875,172.5657663291529,456.2379748765914,142.6223662098291,390.3689995646985,112.34683881706744C326.66090330228417,83.06452184765237,258.84405631176094,53.51806209861945,193.32584062364296,78.48882559362697C121.61183558270385,105.82097193414197,62.805066853699245,167.19869350419734,48.57481801355237,242.6138429142374C34.843463184063346,315.3850353017275,76.69343916112496,383.4422959591041,125.22947124332185,439.3748458443577C170.7312796277747,491.8107796887764,230.57421082200815,532.3932930995766,300,532.3542879108572">
                  </path>
                </svg>
                <i class="bx bxs-time-five"></i>
              </div>
              <h4>Accounts</h4>
              <p>EmiraTrust Bank’s Digital Asset Banking Solutions is a specialized division within our Private Banking framework, created to meet the growing demand for secure, compliant, and seamless digital asset...

              <p><a href="service24x7.html">For more --> </a></p1>

            </div>
          </div>

          <div class="col-lg-4 col-md-6 d-flex align-items-stretch" data-aos="zoom-in" data-aos-delay="200">
            <div class="icon-box iconbox-blue ">
              <div class="icon">
                <svg width="100" height="100" viewBox="0 0 600 600" xmlns="http://www.w3.org/2000/svg">
                  <path stroke="none" stroke-width="0" fill="#f5f5f5" d="M300,582.0697525312426C382.5290701553225,586.8405444964366,449.9789794690241,525.3245884688669,502.5850820975895,461.55621195738473C556.606425686781,396.0723002908107,615.8543463187945,314.28637112970534,586.6730223649479,234.56875336149918C558.9533121215079,158.8439757836574,454.9685369536778,164.00468322053177,381.49747125262974,130.76875717737553C312.15926192815925,99.40240125094834,248.97055460311594,18.661163978235184,179.8680185752513,50.54337015887873C110.5421016452524,82.52863877960104,119.82277516462835,180.83849132639028,109.12597500060166,256.43424936330496C100.08760227029461,320.3096726198365,92.17705696193138,384.0621239912766,124.79988738764834,439.7174275375508C164.83382741302287,508.01625554203684,220.96474134820875,577.5009287672846,300,582.0697525312426">
                  </path>
                </svg>
                <i class="bx bxs-credit-card"></i>
              </div>
              <h4>Credit & Debit Cards</a></h4>
               <p>Designed for seamless, secure transactions - whether you're shopping online, in-store, or abroad.
                  We offer both Mastercard and Visa options to give you global access and flexibility, with support for contactless payments, e-commerce, and in-person purchases across the UAE and around the world...</p>
              <p><a href="/bankerers/user/UserData/cards.php">Get started now -- ></a></p>
             
            </div>
          </div>

          
          <div class="col-lg-4 col-md-6 d-flex align-items-stretch" data-aos="zoom-in" data-aos-delay="300">
            <div class="icon-box iconbox-teal">
              <div class="icon">
                <svg width="100" height="100" viewBox="0 0 600 600" xmlns="http://www.w3.org/2000/svg">
                  <path stroke="none" stroke-width="0" fill="#f5f5f5" d="M300,566.797414625762C385.7384707136149,576.1784315230908,478.7894351017131,552.8928747891023,531.9192734346935,484.94944893311C584.6109503024035,417.5663521118492,582.489472248146,322.67544863468447,553.9536738515405,242.03673114598146C529.1557734026468,171.96086150256528,465.24506316201064,127.66468636344209,395.9583748389544,100.7403814666027C334.2173773831606,76.7482773500951,269.4350130405921,84.62216499799875,207.1952322260088,107.2889140133804C132.92018162631612,134.33871894543012,41.79353780512637,160.00259165414826,22.644507872594943,236.69541883565114C3.319112789854554,314.0945973066697,72.72355303640163,379.243833228382,124.04198916343866,440.3218312028393C172.9286146004772,498.5055451809895,224.45579914871206,558.5317968840102,300,566.797414625762">
                  </path>
                </svg>
                <i class="bx bxs-coin-stack"></i>
              </div>
              <h4>Loans</h4>
               <p>Turn your financial dreams into a reality. Our loan solutions are tailor made to meet your personal needs.Loans approved with the digital documents and digital signature.</p>
              <p><a href="loans.html">For more -- ></a></p>
            </div>
          </div>
          <div class="col-lg-4 col-md-6 d-flex align-items-stretch" data-aos="zoom-in" data-aos-delay="100">
            <div class="icon-box iconbox-yellow">
              <div class="icon">
                <svg width="100" height="100" viewBox="0 0 600 600" xmlns="http://www.w3.org/2000/svg">
                  <path stroke="none" stroke-width="0" fill="#f5f5f5" d="M300,503.46388370962813C374.79870501325706,506.71871716319447,464.8034551963731,527.1746412648533,510.4981551193396,467.86667711651364C555.9287308511215,408.9015244558933,512.6030010748507,327.5744911775523,490.211057578863,256.5855673507754C471.097692560561,195.9906835881958,447.69079081568157,138.11976852964426,395.19560036434837,102.3242989838813C329.3053358748298,57.3949838291264,248.02791733380457,8.279543830951368,175.87071277845988,42.242879143198664C103.41431057327972,76.34704239035025,93.79494320519305,170.9812938413882,81.28167332365135,250.07896920659033C70.17666984294237,320.27484674793965,64.84698225790005,396.69656628748305,111.28512138212992,450.4950937839243C156.20124167950087,502.5303643271138,231.32542653798444,500.4755392045468,300,503.46388370962813">
                  </path>
                </svg>
                <i class="bx bxs-dollar-circle"></i>
              </div>
              <h4>Insurance</h4>
              <p>When you take out insurance with us, you can be sure the people you love and the things you care about will be taken care of. Whether you're looking for home, car or life insurance, we can help you find the right cover.</p>
              <p><a href="blockchain.html">For more -- > </a></p>
            </div>
          </div>

         <div class="col-lg-4 col-md-6 d-flex align-items-stretch" data-aos="zoom-in" data-aos-delay="100">
            <div class="icon-box iconbox-green">
              <div class="icon">
                <svg width="100" height="100" viewBox="0 0 600 600" xmlns="http://www.w3.org/2000/svg">
                  <path stroke="none" stroke-width="0" fill="#f5f5f5" d="M300,521.0016835830174C376.1290562159157,517.8887921683347,466.0731472004068,529.7835943286574,510.70327084640275,468.03025145048787C554.3714126377745,407.6079735673963,508.03601936045806,328.9844924480964,491.2728898941984,256.3432110539036C474.5976632858925,184.082847569629,479.9380746630129,96.60480741107993,416.23090153303,58.64404602377083C348.86323505073057,18.502131276798302,261.93793281208167,40.57373210992963,193.5410806939664,78.93577620505333C130.42746243093433,114.334589627462,98.30271207620316,179.96522072025542,76.75703585869454,249.04625023123273C51.97151888228291,328.5150500222984,13.704378332031375,421.85034740162234,66.52175969318436,486.19268352777647C119.04800174914682,550.1803526380478,217.28368757567262,524.383925680826,300,521.0016835830174">
                  </path>
                </svg>
                <i class="bx bxs-check-shield"></i>
              </div>
              <h4>Secure Payment</h4>
              <p>Whether you're managing a checking account, savings portfolio, or digital assets through our private banking division, ETB is built to protect your financial journey every step of the way.</p>
              <p><a href="safety.html">For more -- ></a></p>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 d-flex align-items-stretch" data-aos="zoom-in" data-aos-delay="300">
            <div class="icon-box iconbox-pink">
              <div class="icon">
                <svg width="100" height="100" viewBox="0 0 600 600" xmlns="http://www.w3.org/2000/svg">
                  <path stroke="none" stroke-width="0" fill="#f5f5f5" d="M300,541.5067337569781C382.14930387511276,545.0595476570109,479.8736841581634,548.3450877840088,526.4010558755058,480.5488172755941C571.5218469581645,414.80211281144784,517.5187510058486,332.0715597781072,496.52539010469104,255.14436215662573C477.37192572678356,184.95920475031193,473.57363656557914,105.61284051026155,413.0603344069578,65.22779650032875C343.27470386102294,18.654635553484475,251.2091493199835,5.337323636656869,175.0934190732945,40.62881213300186C97.87086631185822,76.43348514350839,51.98124368387456,156.15599469081315,36.44837278890362,239.84606092416172C21.716077023791087,319.22268207091537,43.775223500013084,401.1760424656574,96.891909868211,461.97329694683043C147.22146801428983,519.5804099606455,223.5754009179313,538.201503339737,300,541.5067337569781">
                  </path>
                </svg>
                <i class="bx bxs-bank"></i>
              </div>
              <h4>Asset management</h4>
              <p>Our Bank allows there customer to access their account 24/7 without having to visit a physical branch with the help of online banking </p>
               <p><a href="insurance.html">For more -- ></a></p>
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Services Section -->

    <!-- ======= Features Section ======= -->
    <section id="features" class="features">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Features</h2>
          <p></p>
        </div>

        <div class="row">
          <div class="col-lg-6 order-2 order-lg-1 d-flex flex-column align-items-lg-center">
            <div class="icon-box mt-5 mt-lg-0" data-aos="fade-up" data-aos-delay="100">
              <i class="bx bx-shield"></i>
              <h4>Secure Pay</h4>
              <p>We provide the feature of End to end encrypted details while the ongoing payment.</p>
            </div>
            <div class="icon-box mt-5" data-aos="fade-up" data-aos-delay="200">
              <i class="bi bi-graph-up"></i>
              <h4>Graphical Dashboard</h4>
              <p>We provide easy to use and flexible dashboard to our customer with visualize graphs</p>
            </div>
            <div class="icon-box mt-5" data-aos="fade-up" data-aos-delay="300">
              <i class="bi bi-check-all"></i>
              <h4>2 Step Verification</h4>
              <p>We add an extra layer of security to your account in case your password is stolen</p>
            </div>
            <div class="icon-box mt-5" data-aos="fade-up" data-aos-delay="400">
              <i class="bx bx-message-detail"></i>
              <h4>Instant Alert</h4>
              <p>We Provide an instant payment alert message after every transaction perfrom with your account</p>
            </div>
          </div>
          <div class="image col-lg-6 order-1 order-lg-2 " data-aos="zoom-in" data-aos-delay="100">
            <img src="assets/img/features.svg" alt="" class="img-fluid">
          </div>
        </div>

      </div>
    </section><!-- End Features Section -->

    <!-- ======= Testimonials Section ======= -->
    <section id="testimonials" class="testimonials section-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Testimonials</h2>
          <p>The Wonderful reviews of our clients about our bank</p>
        </div>

        <div class="testimonials-slider swiper-container" data-aos="fade-up" data-aos-delay="100">
          <div class="swiper-wrapper">

            <div class="swiper-slide">
              <div class="testimonial-item">
                <p>
                  <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                 The staff is always friendly, professional, and helpful. They explain everything clearly and treat me with respect. Deposits, transfers, and bill payments are fast and smooth — I’ve never had any issues with delays. The fees are reasonable, and they offered me a competitive rate on my loan
                  <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                </p>
                <img src="assets/img/testimonials/testimonials-1.jpg" class="testimonial-img" alt="">
                <h3>Johan Doe</h3>
                <h4>Customer</h4>
              </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
              <div class="testimonial-item">
                <p>
                  <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                  Sure! Here's the grammatically corrected version of your text:

---

"Fees were not clearly communicated during the crypto-to-fiat conversion. I lost more than expected due to the exchange rate.
That said, I really appreciate the multi-currency wallet support. Holding BTC, ETH, and USDC in one place with real-time tracking is a game-changer.
I also love how fast transactions are processed—my Bitcoin withdrawal to an external wallet took less than 5 minutes. That's rare in crypto banking!"

---

Let me know if you want a more formal or more casual version.

                  <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                </p>
                <img src="assets/img/testimonials/testimonials-2.jpg" class="testimonial-img" alt="">
                <h3>Shweta Sharma</h3>
                <h4>Customer</h4>
              </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
              <div class="testimonial-item">
                <p>
                  <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                  This is the wonderful bank i ever seen. You can esily create account in just 10 minutes
                  and start your online banking. Thank You   إميراترست | EmiraTrust!
                  <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                </p>
                <img src="assets/img/testimonials/testimonials-3.jpg" class="testimonial-img" alt="">
                <h3>Smita Patel</h3>
                <h4>Customer</h4>
              </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
              <div class="testimonial-item">
                <p>
                  <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                  This Bank Gives instant alert after every transaction. Personnaly I like the UI of
                  dashboard and profile section.
                  <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                </p>
                <img src="assets/img/testimonials/testimonials-4.jpg" class="testimonial-img" alt="">
                <h3>Manoj Gupta</h3>
                <h4>Customer</h4>
              </div>
            </div><!-- End testimonial item -->

            <!-- <div class="swiper-slide">
              <div class="testimonial-item">
                <p>
                  <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                  Quis quorum aliqua sint quem legam fore sunt eram irure aliqua veniam tempor noster veniam enim culpa
                  labore duis sunt culpa nulla illum cillum fugiat legam esse veniam culpa.
                  <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                </p>
                <img src="assets/img/testimonials/testimonials-5.jpg" class="testimonial-img" alt="">
                <h3>John Larson</h3>
                <h4>Entrepreneur</h4>
              </div>
            </div>End testimonial item -->

          </div>
          <div class="swiper-pagination"></div>
        </div>

      </div>
    </section><!-- End Testimonials Section -->

    <!-- ======= Portfolio Section ======= -->
    <!-- <section id="portfolio" class="portfolio">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Portfolio</h2>
          <p>Magnam dolores commodi suscipit. Necessitatibus eius consequatur ex aliquid fuga eum quidem. Sit sint
            consectetur velit. Quisquam quos quisquam cupiditate. Et nemo qui impedit suscipit alias ea. Quia fugiat sit
            in iste officiis commodi quidem hic quas.</p>
        </div>

        <div class="row">
          <div class="col-lg-12 d-flex justify-content-center">
            <ul id="portfolio-flters">
              <li data-filter="*" class="filter-active">All</li>
              <li data-filter=".filter-app">App</li>
              <li data-filter=".filter-card">Card</li>
              <li data-filter=".filter-web">Web</li>
            </ul>
          </div>
        </div>

        <div class="row portfolio-container">

          <div class="col-lg-4 col-md-6 portfolio-item filter-app">
            <div class="portfolio-wrap">
              <img src="assets/img/portfolio/portfolio-1.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h4>App 1</h4>
                <p>App</p>
              </div>
              <div class="portfolio-links">
                <a href="assets/img/portfolio/portfolio-1.jpg" data-gallery="portfolioGallery"
                  class="portfolio-lightbox" title="App 1"><i class="bx bx-plus"></i></a>
                <a href="portfolio-details.html" title="More Details"><i class="bx bx-link"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-web">
            <div class="portfolio-wrap">
              <img src="assets/img/portfolio/portfolio-2.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h4>Web 3</h4>
                <p>Web</p>
              </div>
              <div class="portfolio-links">
                <a href="assets/img/portfolio/portfolio-2.jpg" data-gallery="portfolioGallery"
                  class="portfolio-lightbox" title="Web 3"><i class="bx bx-plus"></i></a>
                <a href="portfolio-details.html" title="More Details"><i class="bx bx-link"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-app">
            <div class="portfolio-wrap">
              <img src="assets/img/portfolio/portfolio-3.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h4>App 2</h4>
                <p>App</p>
              </div>
              <div class="portfolio-links">
                <a href="assets/img/portfolio/portfolio-3.jpg" data-gallery="portfolioGallery"
                  class="portfolio-lightbox" title="App 2"><i class="bx bx-plus"></i></a>
                <a href="portfolio-details.html" title="More Details"><i class="bx bx-link"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-card">
            <div class="portfolio-wrap">
              <img src="assets/img/portfolio/portfolio-4.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h4>Card 2</h4>
                <p>Card</p>
              </div>
              <div class="portfolio-links">
                <a href="assets/img/portfolio/portfolio-4.jpg" data-gallery="portfolioGallery"
                  class="portfolio-lightbox" title="Card 2"><i class="bx bx-plus"></i></a>
                <a href="portfolio-details.html" title="More Details"><i class="bx bx-link"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-web">
            <div class="portfolio-wrap">
              <img src="assets/img/portfolio/portfolio-5.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h4>Web 2</h4>
                <p>Web</p>
              </div>
              <div class="portfolio-links">
                <a href="assets/img/portfolio/portfolio-5.jpg" data-gallery="portfolioGallery"
                  class="portfolio-lightbox" title="Web 2"><i class="bx bx-plus"></i></a>
                <a href="portfolio-details.html" title="More Details"><i class="bx bx-link"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-app">
            <div class="portfolio-wrap">
              <img src="assets/img/portfolio/portfolio-6.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h4>App 3</h4>
                <p>App</p>
              </div>
              <div class="portfolio-links">
                <a href="assets/img/portfolio/portfolio-6.jpg" data-gallery="portfolioGallery"
                  class="portfolio-lightbox" title="App 3"><i class="bx bx-plus"></i></a>
                <a href="portfolio-details.html" title="More Details"><i class="bx bx-link"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-card">
            <div class="portfolio-wrap">
              <img src="assets/img/portfolio/portfolio-7.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h4>Card 1</h4>
                <p>Card</p>
              </div>
              <div class="portfolio-links">
                <a href="assets/img/portfolio/portfolio-7.jpg" data-gallery="portfolioGallery"
                  class="portfolio-lightbox" title="Card 1"><i class="bx bx-plus"></i></a>
                <a href="portfolio-details.html" title="More Details"><i class="bx bx-link"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-card">
            <div class="portfolio-wrap">
              <img src="assets/img/portfolio/portfolio-8.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h4>Card 3</h4>
                <p>Card</p>
              </div>
              <div class="portfolio-links">
                <a href="assets/img/portfolio/portfolio-8.jpg" data-gallery="portfolioGallery"
                  class="portfolio-lightbox" title="Card 3"><i class="bx bx-plus"></i></a>
                <a href="portfolio-details.html" title="More Details"><i class="bx bx-link"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-web">
            <div class="portfolio-wrap">
              <img src="assets/img/portfolio/portfolio-9.jpg" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h4>Web 3</h4>
                <p>Web</p>
              </div>
              <div class="portfolio-links">
                <a href="assets/img/portfolio/portfolio-9.jpg" data-gallery="portfolioGallery"
                  class="portfolio-lightbox" title="Web 3"><i class="bx bx-plus"></i></a>
                <a href="portfolio-details.html" title="More Details"><i class="bx bx-link"></i></a>
              </div>
            </div>
          </div>

        </div>

      </div>
    </section> End Portfolio Section -->

    <!-- ======= Pricing Section ======= -->
    <!-- <section id="pricing" class="pricing section-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Pricing</h2>
          <p>Magnam dolores commodi suscipit. Necessitatibus eius consequatur ex aliquid fuga eum quidem. Sit sint
            consectetur velit. Quisquam quos quisquam cupiditate. Et nemo qui impedit suscipit alias ea. Quia fugiat sit
            in iste officiis commodi quidem hic quas.</p>
        </div>

        <div class="row">

          <div class="col-lg-3 col-md-6" data-aos="fade-up" data-aos-delay="100">
            <div class="box">
              <h3>Free</h3>
              <h4><sup>$</sup>0<span> / month</span></h4>
              <ul>
                <li>Aida dere</li>
                <li>Nec feugiat nisl</li>
                <li>Nulla at volutpat dola</li>
                <li class="na">Pharetra massa</li>
                <li class="na">Massa ultricies mi</li>
              </ul>
              <div class="btn-wrap">
                <a href="#" class="btn-buy">Buy Now</a>
              </div>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 mt-4 mt-md-0" data-aos="fade-up" data-aos-delay="200">
            <div class="box featured">
              <h3>Business</h3>
              <h4><sup>$</sup>19<span> / month</span></h4>
              <ul>
                <li>Aida dere</li>
                <li>Nec feugiat nisl</li>
                <li>Nulla at volutpat dola</li>
                <li>Pharetra massa</li>
                <li class="na">Massa ultricies mi</li>
              </ul>
              <div class="btn-wrap">
                <a href="#" class="btn-buy">Buy Now</a>
              </div>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="300">
            <div class="box">
              <h3>Developer</h3>
              <h4><sup>$</sup>29<span> / month</span></h4>
              <ul>
                <li>Aida dere</li>
                <li>Nec feugiat nisl</li>
                <li>Nulla at volutpat dola</li>
                <li>Pharetra massa</li>
                <li>Massa ultricies mi</li>
              </ul>
              <div class="btn-wrap">
                <a href="#" class="btn-buy">Buy Now</a>
              </div>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="400">
            <div class="box">
              <span class="advanced">Advanced</span>
              <h3>Ultimate</h3>
              <h4><sup>$</sup>49<span> / month</span></h4>
              <ul>
                <li>Aida dere</li>
                <li>Nec feugiat nisl</li>
                <li>Nulla at volutpat dola</li>
                <li>Pharetra massa</li>
                <li>Massa ultricies mi</li>
              </ul>
              <div class="btn-wrap">
                <a href="#" class="btn-buy">Buy Now</a>
              </div>
            </div>
          </div>

        </div>

      </div>
    </section>End Pricing Section -->

    <!-- ======= Frequently Asked Questions Section ======= -->
    <section id="faq" class="faq">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Frequently Asked Questions</h2>
          <p></p>
        </div>

        <div class="faq-list">
          <ul>
            <li data-aos="fade-up" data-aos="fade-up" data-aos-delay="100">
              <i class="bx bx-help-circle icon-help"></i> <a data-bs-toggle="collapse" class="collapse" data-bs-target="#faq-list-1">What documents are required for KYC? <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
              <div id="faq-list-1" class="collapse show" data-bs-parent=".faq-list">
                <p>
                  To complete your KYC with EmiraTrust Bank, you’ll need: <br>

                  1 A valid Emirates ID (mandatory) <br>
                  2 Passport (for non-citizens) <br>
                  3 Visa page or residency proof (for expatriates) <br>
                  4 Proof of address (such as a utility bill or tenancy contract, if requested) <br>
                 All documents can be uploaded securely through our app or website during registration.<br>


                </p>
              </div>
            </li>

            <li data-aos="fade-up" data-aos-delay="200">
              <i class="bx bx-help-circle icon-help"></i> <a data-bs-toggle="collapse" data-bs-target="#faq-list-2" class="collapsed">How do I register with EmiraTrust Bank? <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
              <div id="faq-list-2" class="collapse" data-bs-parent=".faq-list">
                <p>
                 You can register with EmiraTrust Bank in just a few steps through our website. Simply click <b>Open an Account</b>, complete the digital onboarding process, and verify your identity — all online, with no branch visit required.
                </p>
              </div>
            </li>

            <li data-aos="fade-up" data-aos-delay="300">
              <i class="bx bx-help-circle icon-help"></i> <a data-bs-toggle="collapse" data-bs-target="#faq-list-3" class="collapsed">How to view the transaction history ?<i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
              <div id="faq-list-3" class="collapse" data-bs-parent=".faq-list">
                <p>
                 To View Transaction History follow the steps given below : <br>
                 You can view your full transaction history by logging into your EmiraTrust Bank account through our website.
                 Go to the <b>Accounts</b> section and select <b>Transaction History</b>. You can also click <b>View More</b> on the dashboard for quick access to recent transactions.


                </p>
              </div>
            </li>

            <li data-aos="fade-up" data-aos-delay="400">
              <i class="bx bx-help-circle icon-help"></i> <a data-bs-toggle="collapse" data-bs-target="#faq-list-4" class="collapsed">How to apply for credit card and debit card ? <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
              <div id="faq-list-4" class="collapse" data-bs-parent=".faq-list">
                <p>
                 You can apply for a credit or debit card directly through the EmiraTrust Bank website.
                 Simply log in, navigate to the <b>Cards</b> section, choose the card type you prefer, and click <b>Apply Now</b>
                 Once approved, your card will be delivered to your registered address within 2–3 business days.


                </p>
              </div>
            </li>

            <li data-aos="fade-up" data-aos-delay="500">
              <i class="bx bx-help-circle icon-help"></i> <a data-bs-toggle="collapse" data-bs-target="#faq-list-5" class="collapsed">How much time does verification process takes?<i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
              <div id="faq-list-5" class="collapse" data-bs-parent=".faq-list">
                <p>
                 The verification process usually takes just a few minutes. In some cases, it may take up to 3 working days, depending on the accuracy of your submitted documents.
                  We’ll notify you by email as soon as your verification is complete.


                </p>
              </div>
            </li>
            <li data-aos="fade-up" data-aos-delay="600">
              <i class="bx bx-help-circle icon-help"></i> <a data-bs-toggle="collapse" data-bs-target="#faq-list-5" class="collapsed">Which digital assets can be deposited into my EmiraTrust Bank account?<i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
              <div id="faq-list-5" class="collapse" data-bs-parent=".faq-list">
                <p>
               Currently, EmiraTrust Bank supports deposits in the following cryptocurrencies:
               Bitcoin (BTC), Ethereum (ETH), USDT, USDC, XRP, Solana (SOL), BNB, MATIC, TRX, and Bitcoin Cash (BCH).

               Our list of supported assets is continuously expanding. Additional tokens may be considered upon request, although no binding or public acceptance list is published at this time.

                </p>
              </div>
            </li>
            <li data-aos="fade-up" data-aos-delay="700">
              <i class="bx bx-help-circle icon-help"></i> <a data-bs-toggle="collapse" data-bs-target="#faq-list-5" class="collapsed">Does EmiraTrust Bank accept digital asset deposits from crypto exchanges?<i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
              <div id="faq-list-5" class="collapse" data-bs-parent=".faq-list">
                <p>
                Yes, EmiraTrust Bank accepts digital asset deposits from verified crypto exchanges.
                However, all incoming transactions are subject to a basic AML (Anti-Money Laundering) check to ensure the assets originate from clean and compliant sources.
                Supporting documentation may be required.


                </p>
              </div>
            </li>
            <li data-aos="fade-up" data-aos-delay="800">
              <i class="bx bx-help-circle icon-help"></i> <a data-bs-toggle="collapse" data-bs-target="#faq-list-5" class="collapsed">Can a crypto or blockchain company open an account with EmiraTrust Bank?<i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
              <div id="faq-list-5" class="collapse" data-bs-parent=".faq-list">
                <p>
                Yes, crypto and blockchain companies can open accounts with EmiraTrust Bank.
                However, account approval is subject to enhanced due diligence and compliance with our relevant terms and conditions, similar to those applied to individual customers.


                </p>
              </div>
            </li>

          </ul>
        </div>

      </div>
    </section><!-- End Frequently Asked Questions Section -->

    <!-- ======= Contact Section ======= -->
    <section id="contact" class="contact section-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Contact</h2>
          <p>For any queries related to banking with EmiraTrust or opening an account, please contact us. We are committed to supporting you every step of the way.</p>
        </div>

        <div class="row">
          <div class="col-lg-6">
            <div class="info-box mb-4">
              <i class="bx bx-map"></i>
              <h3>Our Address</h3>
              <p>67HP+WP Dubai </p>
            </div>
          </div>

          <div class="col-lg-3 col-md-6">
            <div class="info-box  mb-4">
              <i class="bx bx-envelope"></i>
              <h3>Email Us</h3>
              <p>inquiries@emiratrust.com</p>
            </div>
          </div>

          <div class="col-lg-3 col-md-6">
            <div class="info-box  mb-4">
              <i class="bx bx-phone-call"></i>
              <h3>Call Us</h3>
              <p>+1 5589 55488 55</p>
            </div>
          </div>

        </div>

        <div class="row">
          <div class="col-lg-6"> 
              <a href="https://www.google.com/maps/@23.5127645,54.3127221,9.37z?entry=ttu&g_ep=EgoyMDI1MDYxMS4wIKXMDSoASAFQAw%3D%3D" target="_blank">
                  <img src="https://i.imgur.com/s7HG9yT.jpeg" class="d-block w-100" alt="Slide 1">
              </a>
          </div>

          <div class="col-lg-6">
            <form action="/bankerers/contact.php" method="POST">
              <div class="row">
                <div class="col-md-6 form-group">
                  <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" required>
                </div>
                <div class="col-md-6 form-group mt-3 mt-md-0">
                  <input type="email" class="form-control" name="email" id="email" placeholder="Your Email" required>
                </div>
              </div>
              <div class="form-group mt-3">
                <input type="text" class="form-control" name="subject" id="subject" placeholder="Subject" required>
              </div>
              <div class="form-group mt-3">
                <textarea class="form-control" id="message" name="message" rows="5" placeholder="Message" required></textarea>
              </div>
              <div hidden id="status"></div>
              <div hidden id="error-message" class="alert alert-danger mt-3"></div>
              <div hidden id="success-message" class="alert alert-success mt-3"></div>
              <div class="text-center"><button class="btn-custo mt-3" id="submit" name="submit">Send Message <i class='bx bxs-send'></i></button></div>
            </form>
          </div>

        </div>

      </div>
    </section><!-- End Contact Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer">

    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-3 col-md-6 footer-contact">
            <h3>  إميراترست | EmiraTrust</h3>
            <p>
               Burj Al Salam <br>
              67HP+WP Dubai <br>
              UAE <br><br>
              <strong>Phone:</strong> +91 5589 55488 55<br>
              <strong>Email:</strong> inquiries@emiratrust.com<br>
            </p>
          </div>

          <div class="col-lg-2 col-md-6 footer-links">
            <h4>Useful Links</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="index.php">Home</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="about.html">About us</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="/bankerers/#services">Services</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="terms.html">Terms of service</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="privacypolicy.html">Privacy policy</a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Our Services</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="user/UserData/Transfer.php">Money Transfer</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="safety.html">Online Banking</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="user/UserData/Dashboard.php">Check Balance</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="user/CreateAccount.php">Create Account</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="user/login.php">Login</a></li>
            </ul>
          </div>

          <div class="col-lg-4 col-md-6 footer-newsletter">
            <div class="d-flex justify-content-center">
              <img src="assets/img/Logo.png" style="width: 100px; height: 100px;" alt="">
            </div>

            <h1 class="text-center mt-2">&nbsp إميراترست&nbsp|&nbspEmiraTrust</h1>
          </div>

        </div>
      </div>
    </div>

    <div class="container">

      <div class="copyright-wrap d-md-flex py-4">
        <div class="me-md-auto text-center text-md-start">
          <div class="copyright">
            &copy; Copyright <strong><span>  إميراترست | EmiraTrust</span></strong>. All Rights Reserved
          </div>
          <div class="credits">
            <!-- All the links in the footer should remain intact. -->
            <!-- You can delete the links only if you purchased the pro version. -->
            <!-- Licensing information: https://bootstrapmade.com/license/ -->
            <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/techie-free-skin-bootstrap-3/ -->
            <!-- Designed by <a href="#">Sky Tech</a> -->
          </div>
        </div>
        <div class="social-links text-center text-md-right pt-3 pt-md-0">
          <a href="https://x.com/EmiraTrust" class="twitter"><i class="bx bxl-twitter"></i></a>
          <a href="https://www.facebook.com/emiratrust" class="facebook"><i class="bx bxl-facebook"></i></a>
          <a href="https://www.instagram.com/emiratrust/"class="instagram"><i class="bx bxl-instagram"></i></a>
          <a href="#" class="google-plus"><i class="bx bxl-skype"></i></a>
          <a href="#" class="linkedin"><i class="bx bxl-linkedin"></i></a>
        </div>
      </div>
    </div>
    
  </footer>
  <!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>
  <div id="preloader"></div>


<script>
let currentOffset = 0;
const wrapper = document.getElementById('image-wrapper');
const imageWidth = 120; // 100px + 20px gap
const totalImages = wrapper.children.length;
const interval = 3000;

setInterval(() => {
  currentOffset += imageWidth;
  if (currentOffset >= imageWidth * totalImages) {
    currentOffset = 0;
  }
  wrapper.style.transform = `translateX(-${currentOffset}px)`;
}, interval);
</script>

<script>
document.querySelector("form").addEventListener("submit", function (e) {
    e.preventDefault();

    const form = e.target;
    const formData = new FormData(form);
    const submitButton = document.getElementById('submit');
    const successMessage = document.getElementById('success-message');
    const errorMessage = document.getElementById('error-message');

    // Reset messages
    successMessage.hidden = true;
    errorMessage.hidden = true;

    submitButton.disabled = true;
    submitButton.textContent = "Sending...";

    fetch("/bankerers/contact.php", {
        method: "POST",
        body: formData,
    })
    .then(response => response.json())
    .then(data => {
        submitButton.disabled = false;
        submitButton.textContent = "Send Message";

        if (data.status === "success") {
            successMessage.innerText = data.message;
            successMessage.hidden = false;
            form.reset(); // ✅ Clear form
        } else {
            errorMessage.innerText = data.message;
            errorMessage.hidden = false;
        }
    })
    .catch(error => {
        submitButton.disabled = false;
        submitButton.textContent = "Send Message";
        errorMessage.innerText = "Something went wrong. Please try again.";
        errorMessage.hidden = false;
    });
});
</script>

  <!-- Vendor JS Files -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/purecounter/purecounter.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>
  

</body>

</html>