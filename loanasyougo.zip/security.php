<?php

// security.php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$ip = $_SERVER['REMOTE_ADDR'];
$now = time();

if (!isset($_SESSION['rate'])) {
    $_SESSION['rate'] = [];
}

if (!isset($_SESSION['rate'][$ip])) {
    $_SESSION['rate'][$ip] = ['count' => 1, 'start' => $now];
} else {
    if ($now - $_SESSION['rate'][$ip]['start'] < 60) {
        $_SESSION['rate'][$ip]['count']++;
        if ($_SESSION['rate'][$ip]['count'] > 100) {
            http_response_code(429);
            echo "Rate limit exceeded. Try again later.";
            exit;
        }
    } else {
        $_SESSION['rate'][$ip] = ['count' => 1, 'start' => $now];
    }
}

?>