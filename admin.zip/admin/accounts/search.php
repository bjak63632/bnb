<?php
session_start();
include "../connection.php";

if (isset($_POST['AccountNumber'])) {
    $AccountNo = mysqli_real_escape_string($conn, $_POST['AccountNumber']); // sanitize input

    $query = "SELECT * FROM customer_detail WHERE Account_No = '$AccountNo'";

    $result = mysqli_query($conn, $query) or die("Query failed");

    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);

        $_SESSION["EditAccountNo"] = $AccountNo;

        $data = array(
            'id' => $row['C_No'],
            'Ac' => $row['Account_No'],
            'Fname' => $row['C_First_Name'],
            'Lname' => $row['C_Last_Name'],
            'ResidencyStatus' => $row['Residency_Status'],
            'CurrencyPreference' => $row['Currency_Preference'],
            'ProfileImagee' => ltrim($row['ProfileImage'], './')
        );

        echo json_encode($data);
    } else {
        // Optional: return empty JSON or error message if not found
        echo json_encode(array('error' => 'No record found'));
    }
}
?>
