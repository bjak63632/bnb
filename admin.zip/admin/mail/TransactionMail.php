<?php 

require 'PHPMailerAutoload.php';
require 'class.smtp.php';
require __DIR__ . '/../../vendor/autoload.php'; 

function debitMoneyMail($customerMail, $name, $amount, $totalAmount, $date, $AccountNo) {
    $mail = new PHPMailer;
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->Port = 587;
    $mail->SMTPAuth = true;
    $mail->SMTPSecure = 'tls';

    $mail->Username = '002ericanthony@gmail.com';
    $mail->Password = 'zdlecvwkbktwvduk';

    $templatePath = '../mail/DebitMailTemp.php';
    if (!file_exists($templatePath)) {
        return false;
    }

    $content = file_get_contents($templatePath);
    $mail->setFrom('002ericanthony@gmail.com', '  إميراترست | EmiraTrust');
    $mail->addAddress($customerMail);
    $mail->addReplyTo('002ericanthony@gmail.com');

    $mail->isHTML(true);
    $mail->Subject = "Your account '$AccountNo' has been debited";

    $swap_var = [
        "{Name}" => $name,
        "{AccountNo}" => $AccountNo,
        "{Amount}" => $amount,
        "{Date}" => $date,
        "{totalAmount}" => $totalAmount
    ];

    foreach ($swap_var as $key => $value) {
        $content = str_replace($key, $value, $content);
    }

    $mail->Body = $content;

    // Uncomment to send the mail
    // return $mail->send();
}

function creditMoneyMail($customerMail, $name, $amount, $totalAmount, $date, $AccountNo) {
    $mail = new PHPMailer;
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->Port = 587;
    $mail->SMTPAuth = true;
    $mail->SMTPSecure = 'tls';

    $mail->Username = '002ericanthony@gmail.com';
    $mail->Password = 'zdlecvwkbktwvduk';

    $templatePath = '../mail/CreditMailTemp.php';
    if (!file_exists($templatePath)) {
        return false;
    }

    $content = file_get_contents($templatePath);
    $mail->setFrom('002ericanthony@gmail.com', '  إميراترست | EmiraTrust');
    $mail->addAddress($customerMail);
    $mail->addReplyTo('002ericanthony@gmail.com');

    $mail->isHTML(true);
    $mail->Subject = "Your account '$AccountNo' has been credited";

    $swap_var = [
        "{Name}" => $name,
        "{AccountNo}" => $AccountNo,
        "{Amount}" => $amount,
        "{Date}" => $date,
        "{totalAmount}" => $totalAmount
    ];

    foreach ($swap_var as $key => $value) {
        $content = str_replace($key, $value, $content);
    }

    $mail->Body = $content;

    // Uncomment to send the mail
    // return $mail->send();
}
?>
