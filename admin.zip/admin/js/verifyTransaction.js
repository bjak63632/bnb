$(document).ready(function () {

    // Handle verify button click
    $(document).on('click', '.verify_data', function () {
        let AccountNo = $(this).attr("id");

        swal({
            title: "Are you sure?",
            text: "Once verified, the transaction will be marked as approved.",
            icon: "info",
            buttons: true,
            dangerMode: false,
        }).then((confirm) => { 
            if (confirm) {
                $.ajax({
                    type: "POST",
                    url: "code.php",
                    data: { verify_transaction: AccountNo },
                    success: function (response) {
                        if (response.trim() === "Success") {
                            swal("Transaction Approved!", {
                                icon: "success",
                                buttons: false,
                            });
                            setTimeout(function () {
                                location.reload();
                            }, 1000);
                        } else {
                            swal("Error", "Transaction could not be approved. Try again.", "error");
                        }
                    }
                });
            } else {
                swal("Transaction not verified.");
            }
        });
    });

    // Handle reject button click
    $(document).on('click', '.reject_data', function () {
        let AccountNo = $(this).attr("id");

        swal({
            title: "Are you sure?",
            text: "Once rejected, the transaction will be canceled.",
            icon: "warning",
            buttons: true,
            dangerMode: true,
        }).then((confirm) => {
            if (confirm) {
                $.ajax({
                    type: "POST",
                    url: "code.php",
                    data: { reject_transaction: AccountNo },
                    success: function (response) {
                        if (response.trim() === "Success") {
                            swal("Transaction Rejected!", {
                                icon: "success",
                                buttons: false,
                            });
                            setTimeout(function () {
                                location.reload();
                            }, 1000);
                        } else {
                            swal("Error", "Transaction could not be rejected. Try again.", "error");
                        }
                    }
                });
            } else {
                swal("Transaction not rejected.");
            }
        });
    });
});
