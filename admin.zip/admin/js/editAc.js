$(document).ready(function () {
    $("#search").click(function () { 
        let AccountNo = $("#SearchText").val().trim();

        if(AccountNo.length === 12){
            $.ajax({
                type: "POST",
                url: "search.php",
                data: { AccountNumber: AccountNo },
                dataType: 'json',
                success: function (response) {
                    if (response && !response.error) {

                        // Hide main table, show search result table
                        $("#EditTable").attr('hidden', true);
                        $("#SearchTable").attr('hidden', false);

                        // Fill in all relevant table cells
                        $("#id").text(response['id']);
                        $("#AccountNo").text(response['Ac']);
                        $("#Fname").text(response['Fname']);
                        $("#Lname").text(response['Lname']);
                        $("#ResidencyStatus").text(response['ResidencyStatus']);
                        $("#CurrencyPreference").text(response['CurrencyPreference']);
                        
                        // Update Profile Pic (assumes ProfileImage is a relative path)
                       let profileImg = response['ProfileImagee'] ? response['ProfileImagee'].replace(/^\.\/+/, '') : '';
                        let profileImgPath = profileImg ? "../../user/" + profileImg : "default-profile.png";
                        $("#ProfilePicc").attr('src', profileImgPath);

                        // Update hidden input inside the edit form so form submits correct account number
                        $("#edit_id_input").val(response['Ac']);

                    } else {
                        alert("No account found or error in response");
                        // Show main table, hide search table
                        $("#EditTable").attr('hidden', false);
                        $("#SearchTable").attr('hidden', true);
                    }
                },
                error: function() {
                    console.log("AJAX call failed");
                }
            });
        } else {
            alert("Please enter a 12-digit Account Number");
        }
    });
});

function reload(){
    location.reload();
}
