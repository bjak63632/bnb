console.log('Hello');

// This is the best methd to perfrom crud operation multiple varibles
$(document).ready(function () {

    $(document).on('click', '.view_data', function () {

        let AccountNo = $(this).attr("id");

        $.ajax({
            type: "POST",
            url: "code.php",
            data: {
                CAccountNo: AccountNo
            },
            dataType: 'json',
            success: function (response) {

                // Existing fields
                $("#Fname").text(response['Fname']);
                $("#Lname").text(response['Lname']);
                $("#Bdate").text(response['Bdate']);
                $("#AdharNo").text(response['AdharNo']); 
                $("#PanNo").text(response['PanNo']);
                $("#MobileNo").text(response['MobileNo']);
                $("#Pincode").text(response['Pincode']);
                $("#Email").text(response['Email']);

                // New fields
                $("#Residency_Status").text(response['Residency_Status']);
                $("#Currency_Preference").text(response['Currency_Preference']);

                let wealthDocPath = response['Source_Of_Wealth_Doc'];
                let bankStatementPath = response['Bank_Statement_Doc'];

                $("#WealthDoc").attr("src", "../user/" + wealthDocPath);
                $("#BankStatementDoc").attr("src", "../user/" + bankStatementPath);

                // Existing images National & Tax
                $("#AdharImg").attr("src", "../user/" + response['AdharDoc']);
                $("#PanImg").attr("src", "../user/" + response['PanDoc']);
            }
        });
    });


    $(document).on('click', '.verify_data', function () {
        let AccountNo = $(this).attr("id");
        console.log(AccountNo);

        swal({
            title: "Are you sure?",
            text: "Once Verified, This Account Should Be Activated ",
            icon: "info",
            buttons: true,
            dangerMode: false,
        }).then((value) => {
            if (value) {

                $.ajax({
                    type: "POST",
                    url: "code.php",
                    data: { VerifyAc: AccountNo },
                    success: function (response) {

                        if (response == "Success") {
                            swal("Account Activated Sucessfully!", {
                                icon: "success",
                                buttons: [false]
                            });
                            setTimeout(function () {

                                location.reload();

                            }, 1000);
                            console.log(response);
                        }
                        else {
                            swal({
                                title: "Account Not Activated !",
                                text: "Please Check Connection or after some time!",
                                icon: "error",
                                buttons: true,
                                // value:true
                            }).then((value) => {
                                location.reload();
                            });

                        }
                    }
                });
            }
            else {
                swal("The Account is not Activated !");
            }

        });

    });
    $(document).on('click', '.reject_data', function () {
        let AccountNo = $(this).attr("id");
        console.log(AccountNo);

        swal({
            title: "Are you sure?",
            text: "Once Rejected, This Account Should Not Be Recover ",
            icon: "warning",
            buttons: true,
            dangerMode: true,
        }).then((willDelete) => {
            if (willDelete) {
                $.ajax({
                    type: "POST",
                    url: "code.php",
                    data: { RejectAc: AccountNo },
                    success: function (response) {

                        if (response == "Success") {
                            swal("Account Activated Sucessfully!", {
                                icon: "success",
                                buttons: [false]
                            });

                            $.ajax({
                                type: "POST",
                                url: "code.php",
                                data: {done: "done"},
                                success: function (response) {
                                    
                                }
                            });
                            setTimeout(function () {

                                location.reload();

                            }, 1000);
                            console.log(response);
                        }
                        else {
                            swal({
                                title: "Account Not Activated !",
                                text: "Please Check Connection or after some time!",
                                icon: "error",
                                buttons: true,
                                // value:true
                            }).then((value) => {
                                location.reload();
                            });

                        }
                    }
                });
            }
            else {
                swal("The Account is not Activated !");
            }

        });

    });
});