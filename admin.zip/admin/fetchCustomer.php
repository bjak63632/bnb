<?php
include "../admin/connection.php";

if (isset($_POST['accountNo'])) {
    // Ensure the correct input key is being accessed
    $accountNo = mysqli_real_escape_string($conn, $_POST['accountNo']);
    
    // Using prepared statements to prevent SQL injection
    $query = "SELECT * FROM customer_detail WHERE Account_No = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, 's', $accountNo); // 's' for string (assuming accountNo is a string type)
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($row = mysqli_fetch_assoc($result)) {
        echo json_encode([
            "FirstName" => $row['C_First_Name'],
            "LastName" => $row['C_Last_Name'],
            "BirthDate" => $row['C_Birth_Date'],
            "AdharNo" => $row['C_Adhar_No'],
            "PanNo" => $row['C_Pan_No'],
            "MobileNo" => $row['C_Mobile_No'],
            "Email" => $row['C_Email'],
            "Pincode" => $row['C_Pincode'],
            "AdharImg" => $row['C_Adhar_Doc'], // Assuming this is the correct column name
            "PanImg" => $row['C_Pan_Doc']      // Assuming this is the correct column name
        ]);
    } else {
        echo json_encode(["error" => "Customer not found"]);
    }

    // Close prepared statement
    mysqli_stmt_close($stmt);
}
?>
